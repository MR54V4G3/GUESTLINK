#!/bin/sh
set -eu

DIR="${REQUEST_MANAGER_DIR:-/root/guest-portal-requests}"
ACCOUNTING_DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
QUEUE="${REQUEST_TEST_QUEUE:-$DIR/pending.tsv}"
META_DIR="$DIR/metadata"
umask 077

[ "$#" -eq 9 ] || [ "$#" -eq 12 ] || [ "$#" -eq 13 ] || {
    echo "Expected 9, 12 or 13 arguments." >&2
    exit 2
}

TOKEN="$1"
NAME="$2"
MOBILE="$3"
CUSTOM="$4"
SESSION="$5"
UP_RATE="$6"
DOWN_RATE="$7"
UP_QUOTA="$8"
DOWN_QUOTA="$9"

CLIENT_IP="${10:-}"
CLIENT_MAC="${11:-}"
USER_AGENT="${12:-}"
CLIENT_HID="${13:-}"

[ "${#TOKEN}" -eq 64 ] || { echo "Invalid request hash length." >&2; exit 1; }
printf '%s' "$TOKEN" | grep -Eq '^[a-fA-F0-9]{64}$' || {
    echo "Invalid request hash." >&2
    exit 1
}

printf '%s' "$NAME" | grep -Eq '^[A-Za-z0-9 .-]{1,80}$' || {
    echo "Name contains unsupported characters." >&2
    exit 1
}
printf '%s' "$MOBILE" | grep -Eq '^[0-9+ ()-]{1,30}$' || {
    echo "Mobile number contains unsupported characters." >&2
    exit 1
}
printf '%s' "$MOBILE" | grep -q '[0-9]' || {
    echo "Mobile number must contain digits." >&2
    exit 1
}
printf '%s' "$CUSTOM" | grep -Eq '^[A-Za-z0-9+/=]+$' || {
    echo "Invalid encoded custom data." >&2
    exit 1
}

if [ "$#" -eq 13 ]; then
    [ "${#CLIENT_HID}" -eq 64 ] || {
        echo "Invalid openNDS HID length." >&2
        exit 1
    }
    printf '%s' "$CLIENT_HID" | grep -Eq '^[a-fA-F0-9]{64}$' || {
        echo "Invalid openNDS HID." >&2
        exit 1
    }
else
    CLIENT_HID="Unknown"
fi

for value in "$SESSION" "$UP_RATE" "$DOWN_RATE" "$UP_QUOTA" "$DOWN_QUOTA"; do
    case "$value" in
        ''|*[!0-9]*) echo "Session/rate/quota values must be non-negative integers." >&2; exit 1 ;;
    esac
done

MAC="Unknown"
if printf '%s' "$CLIENT_MAC" | grep -Eq '^([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}$'; then
    MAC="$(printf '%s' "$CLIENT_MAC" | tr 'A-F' 'a-f')"
fi

case "$CLIENT_IP" in
    *[!0-9.]*|.*|*..*|*.) CLIENT_IP="Unknown" ;;
    *)
        [ "$(printf '%s' "$CLIENT_IP" | awk -F. 'NF == 4 {print "ok"}')" = "ok" ] || CLIENT_IP="Unknown"
        ;;
esac

DEVICE_HINT="$(printf '%s' "$USER_AGENT" |
    tr '\011\012\015' '   ' |
    sed 's/[^A-Za-z0-9 ._()\/;:+,-]/?/g' |
    cut -c1-160)"
[ -n "$DEVICE_HINT" ] || DEVICE_HINT="Unknown"

mkdir -p "$(dirname "$QUEUE")"
chmod 700 "$DIR"
[ -e "$QUEUE" ] || : > "$QUEUE"
chmod 600 "$QUEUE"

exec 9>"$QUEUE.lock"
flock -x 9

if awk -F '\t' -v token="$TOKEN" \
    '$3 == token && $12 == "PENDING" { found=1 } END { exit !found }' "$QUEUE"; then
    echo "A pending request already exists for this request hash." >&2
    exit 1
fi

CREATED="$(date +%s)"
ID="REQ-$CREATED-$$"

printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\tPENDING\n' \
    "$ID" "$CREATED" "$TOKEN" "$NAME" "$MOBILE" "$CUSTOM" \
    "$SESSION" "$UP_RATE" "$DOWN_RATE" "$UP_QUOTA" "$DOWN_QUOTA" >> "$QUEUE"
chmod 600 "$QUEUE"

if [ "$QUEUE" = "$DIR/pending.tsv" ]; then
    mkdir -p "$META_DIR"
    chmod 700 "$META_DIR"
    META_TMP="$META_DIR/.$ID.tmp"
    META_FILE="$META_DIR/$ID.tsv"

    if printf '%s\t%s\t%s\t%s\n' \
        "$MAC" "$CLIENT_IP" "$DEVICE_HINT" "$CLIENT_HID" > "$META_TMP"; then
        chmod 600 "$META_TMP"
        mv "$META_TMP" "$META_FILE"
    else
        rm -f "$META_TMP"
    fi
fi

echo "Request queued: $ID"
# Release the submission lock before calling live-manager: it takes the same
# lock while changing the request status. Keeping it here would deadlock.
flock -u 9 || true
exec 9>&-
# Apply automatic approval/authentication policy only to the live queue, never test queues.
if [ "$QUEUE" = "$DIR/pending.tsv" ] && [ -x "$DIR/live-manager.sh" ]; then
    AUTO_RESULT="$(QUOTA_DIR="$ACCOUNTING_DIR" "$DIR/live-manager.sh" auto-process "$ID" 2>&1)" || {
        logger -t guest-request "auto_process_failed id=$ID detail=$AUTO_RESULT"
        echo "AUTO_PROCESS_ERROR: request was safely left for administrator review."
        exit 0
    }
    [ -z "$AUTO_RESULT" ] || printf '%s\n' "$AUTO_RESULT"
fi
