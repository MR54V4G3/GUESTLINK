#!/bin/sh
set -eu
umask 077

BASE_DIR="${REQUEST_MANAGER_DIR:-/root/guest-portal-requests}"
QUEUE="${REQUEST_MANAGER_QUEUE:-$BASE_DIR/pending.tsv}"
QDIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
QM="${QUOTA_MANAGER:-$QDIR/quota-manager.sh}"
LOCK="$QUEUE.lock"

die() {
    echo "ERROR: $*" >&2
    exit 1
}

ACTION="${1:-}"
ID="${2:-}"


# Explicit administrator disconnect: record a return-auth deny marker before
# deauthenticating so the optional background watcher cannot immediately undo it.
if [ "$ACTION" = deny-device ]; then
    [ "$#" -eq 2 ] || die "Usage: $0 deny-device CLIENT_MAC"
    MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid device MAC"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    command -v ndsctl >/dev/null 2>&1 || die "ndsctl is unavailable; the device was not marked disconnected"
    command -v jsonfilter >/dev/null 2>&1 || die "jsonfilter is unavailable; the device was not marked disconnected"
    exec 8>"$QDIR/packages.lock"
    flock -x 8
    policy_return_auth_mark_denied "$MAC" manual_disconnect || die "Could not record administrator disconnect; device was not deauthenticated"
    if CLIENT_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS remained busy after retries; device was blocked from returning, but current session state could not be checked"
        [ "$NDS_RC" -eq 126 ] || [ "$NDS_RC" -eq 127 ] && die "ndsctl could not be executed; device session state was not assumed"
        CLIENT_JSON=""
    fi
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    case "$CLIENT_STATE" in
        Authenticated)
            if NDS_DEAUTH_OUT="$(policy_ndsctl deauth "$MAC" 2>&1)"; then
                :
            else
                NDS_DEAUTH_RC=$?
                die "Device is blocked from automatic return, but authenticated-session deauthentication failed (ndsctl exit $NDS_DEAUTH_RC): ${NDS_DEAUTH_OUT:-no error output}"
            fi
            ;;
        Preauthenticated)
            # Already unauthenticated. openNDS documents ndsctl deauth for
            # currently authenticated clients only; do not deauth twice.
            ;;
    esac
    echo "Guest device $MAC disconnected. Automatic returning-device authentication is suppressed until an administrator approves/authenticates or assigns a package again."
    exit 0
fi

# Show the portal-owned administrator return-auth block list. This is
# separate from nlbwmon, AdGuard Home and other service data.
if [ "$ACTION" = list-return-blocks ]; then
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    DENY_FILE="$(policy_return_auth_deny_file)"
    [ -e "$DENY_FILE" ] || exit 0
    [ -f "$DENY_FILE" ] && [ ! -L "$DENY_FILE" ] || die "Return-auth block list is not a regular file"
    while IFS="$(printf '\t')" read -r BLOCK_MAC BLOCK_TIME BLOCK_REASON; do
        BLOCK_MAC="$(printf '%s' "$BLOCK_MAC" | tr 'A-F' 'a-f')"
        case "$BLOCK_MAC" in
            [0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]) ;;
            *) continue ;;
        esac
        case "$BLOCK_TIME" in ''|*[!0-9]*) continue ;; esac
        case "$BLOCK_REASON" in ''|*[!A-Za-z0-9_-]*) BLOCK_REASON=unknown ;; esac
        printf '%s\t%s\t%s\n' "$BLOCK_MAC" "$BLOCK_TIME" "$BLOCK_REASON"
    done < "$DENY_FILE"
    exit 0
fi

# Clear an administrator block but preserve account/package/usage data.
# REVOKED requests must use restore-device so queue status and the block stay in sync.
if [ "$ACTION" = clear-return-block ]; then
    [ "$#" -eq 2 ] || die "Usage: $0 clear-return-block CLIENT_MAC"
    MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid device MAC"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    [ -f "$QUEUE" ] && [ ! -L "$QUEUE" ] || die "Request queue is missing or invalid"
    [ -d "$BASE_DIR/metadata" ] && [ ! -L "$BASE_DIR/metadata" ] || die "Request metadata directory is missing or invalid"
    exec 8>"$QDIR/packages.lock"
    flock -x 8
    for META in "$BASE_DIR"/metadata/REQ-*.tsv; do
        [ -f "$META" ] && [ ! -L "$META" ] || continue
        META_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META")"
        [ "$META_MAC" = "$MAC" ] || continue
        META_ID="${META##*/}"; META_ID="${META_ID%.tsv}"
        META_STATUS="$(awk -F '\t' -v id="$META_ID" '$1==id {print $12; exit}' "$QUEUE")"
        [ "$META_STATUS" != REVOKED ] || die "This device has a revoked approval. Use Restore approval so its request status and block are restored together."
    done
    policy_return_auth_clear_denied "$MAC" || die "Could not clear the administrator block"
    policy_return_auth_clear_attempt "$MAC" || die "Block was cleared, but the portal retry-cache entry could not be removed"
    echo "Cleared the OpenNDS portal block for $MAC. Existing account/package data and usage history were preserved. The saved account may now use its normal portal policy again."
    exit 0
fi

# Revoke approval while retaining every account, package, quota, usage,
# session and request-history record. All approved request IDs linked to this
# MAC are moved to REVOKED so an older duplicate request cannot restore access.
if [ "$ACTION" = revoke-device ]; then
    [ "$#" -eq 3 ] || die "Usage: $0 revoke-device APPROVED_REQUEST_ID CLIENT_MAC"
    REQUEST_ID="$2"
    MAC="$(printf '%s' "$3" | tr 'A-F' 'a-f')"
    printf '%s\n' "$REQUEST_ID" | grep -Eq '^REQ-[0-9]+-[0-9]+$' || die "Invalid request ID"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid device MAC"
    [ -f "$QUEUE" ] && [ ! -L "$QUEUE" ] || die "Request queue is missing or invalid"
    [ -d "$BASE_DIR/metadata" ] && [ ! -L "$BASE_DIR/metadata" ] || die "Request metadata directory is missing or invalid"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    command -v ndsctl >/dev/null 2>&1 || die "ndsctl is unavailable; revocation was not applied"
    command -v jsonfilter >/dev/null 2>&1 || die "jsonfilter is unavailable; revocation was not applied"

    exec 9>"$LOCK"
    flock -x 9
    awk -F '\t' -v id="$REQUEST_ID" '$1==id && $12=="APPROVED" {found=1} END {exit !found}' "$QUEUE" || die "Request is not currently approved; no records were changed"
    HISTORY="$BASE_DIR/history.tsv"
    [ ! -L "$HISTORY" ] || die "Refusing to append to symlinked request history"
    META_FILE="$BASE_DIR/metadata/$REQUEST_ID.tsv"
    [ -f "$META_FILE" ] && [ ! -L "$META_FILE" ] || die "Approved request metadata is missing; cannot verify its device"
    META_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META_FILE")"
    [ "$META_MAC" = "$MAC" ] || die "Request ID does not belong to the supplied MAC address"

    exec 8>"$QDIR/packages.lock"
    flock -x 8
    policy_return_auth_mark_denied "$MAC" approval_revoked || die "Could not block automatic returning authentication; approval was not revoked"

    if CLIENT_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS remained busy after retries. The return-auth block is in place, but revocation could not be verified; no request status was changed."
        [ "$NDS_RC" -eq 126 ] || [ "$NDS_RC" -eq 127 ] && die "ndsctl could not be executed; revocation was not completed"
        CLIENT_JSON=""
    fi
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    case "$CLIENT_STATE" in
        Authenticated)
            if NDS_DEAUTH_OUT="$(policy_ndsctl deauth "$MAC" 2>&1)"; then
                :
            else
                NDS_DEAUTH_RC=$?
                die "Return-auth is blocked, but authenticated-session deauthentication failed (ndsctl exit $NDS_DEAUTH_RC): ${NDS_DEAUTH_OUT:-no error output}; request status was not changed"
            fi
            ;;
        Preauthenticated)
            # No active session exists, so ndsctl deauth is not applicable.
            ;;
    esac

    PREP="$(mktemp -d "$BASE_DIR/revoke-device.XXXXXX")" || die "Could not create a safe revocation workspace"
    chmod 700 "$PREP"
    trap 'rm -rf "$PREP"' EXIT HUP INT TERM
    IDS_FILE="$PREP/request-ids"
    TRANSITIONS="$PREP/transitions.tsv"
    : > "$IDS_FILE"
    for META in "$BASE_DIR"/metadata/REQ-*.tsv; do
        [ -f "$META" ] && [ ! -L "$META" ] || continue
        OTHER_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META")"
        if [ "$OTHER_MAC" = "$MAC" ]; then
            OTHER_ID="${META##*/}"; OTHER_ID="${OTHER_ID%.tsv}"
            printf '%s\n' "$OTHER_ID" >> "$IDS_FILE"
        fi
    done
    grep -Fxq "$REQUEST_ID" "$IDS_FILE" || die "Could not find the verified request in the device metadata set"
    TMP="$QUEUE.tmp.$$"
    awk -F '\t' -v OFS='\t' -v ids="$IDS_FILE" -v transitions="$TRANSITIONS" '
        BEGIN { while ((getline line < ids) > 0) linked[line]=1; close(ids) }
        {
            if (linked[$1] && $12=="APPROVED") {
                print $1,$4,$5 > transitions
                $12="REVOKED"
                changed++
            }
            print
        }
        END { close(transitions); if (!changed) exit 1 }
    ' "$QUEUE" > "$TMP" || { rm -f "$TMP"; die "Could not stage approval revocation"; }
    chmod 600 "$TMP" && mv "$TMP" "$QUEUE" || { rm -f "$TMP"; die "Could not commit approval revocation"; }
    touch "$HISTORY" || die "Could not open portal decision history"
    chmod 600 "$HISTORY"
    while IFS="$(printf '\t')" read -r EVENT_ID EVENT_NAME EVENT_MOBILE; do
        [ -n "$EVENT_ID" ] || continue
        printf '%s\t%s\t%s\t%s\tACCESS_REVOKED\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" "$EVENT_ID" "$EVENT_NAME" "$EVENT_MOBILE" >> "$HISTORY"
    done < "$TRANSITIONS"
    echo "Revoked access for $MAC. All linked approved requests are now REVOKED. The account, package, quota usage, session records and history were preserved. Restore approval or assign a package to allow access again."
    exit 0
fi

# Restore a previously revoked device. The queue status is updated while the
# tombstone remains in place; only after that commit succeeds is the block
# removed, so the returning-auth watcher cannot race an uncommitted restore.
if [ "$ACTION" = restore-device ]; then
    [ "$#" -eq 3 ] || die "Usage: $0 restore-device REVOKED_REQUEST_ID CLIENT_MAC"
    REQUEST_ID="$2"
    MAC="$(printf '%s' "$3" | tr 'A-F' 'a-f')"
    printf '%s\n' "$REQUEST_ID" | grep -Eq '^REQ-[0-9]+-[0-9]+$' || die "Invalid request ID"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid device MAC"
    [ -f "$QUEUE" ] && [ ! -L "$QUEUE" ] || die "Request queue is missing or invalid"
    [ -d "$BASE_DIR/metadata" ] && [ ! -L "$BASE_DIR/metadata" ] || die "Request metadata directory is missing or invalid"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"

    exec 9>"$LOCK"
    flock -x 9
    awk -F '\t' -v id="$REQUEST_ID" '$1==id && $12=="REVOKED" {found=1} END {exit !found}' "$QUEUE" || die "Request is not currently revoked"
    HISTORY="$BASE_DIR/history.tsv"
    [ ! -L "$HISTORY" ] || die "Refusing to append to symlinked request history"
    META_FILE="$BASE_DIR/metadata/$REQUEST_ID.tsv"
    [ -f "$META_FILE" ] && [ ! -L "$META_FILE" ] || die "Revoked request metadata is missing; cannot verify its device"
    META_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META_FILE")"
    [ "$META_MAC" = "$MAC" ] || die "Request ID does not belong to the supplied MAC address"

    exec 8>"$QDIR/packages.lock"
    flock -x 8
    PREP="$(mktemp -d "$BASE_DIR/restore-device.XXXXXX")" || die "Could not create a safe restore workspace"
    chmod 700 "$PREP"
    trap 'rm -rf "$PREP"' EXIT HUP INT TERM
    IDS_FILE="$PREP/request-ids"
    TRANSITIONS="$PREP/transitions.tsv"
    : > "$IDS_FILE"
    for META in "$BASE_DIR"/metadata/REQ-*.tsv; do
        [ -f "$META" ] && [ ! -L "$META" ] || continue
        OTHER_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META")"
        if [ "$OTHER_MAC" = "$MAC" ]; then
            OTHER_ID="${META##*/}"; OTHER_ID="${OTHER_ID%.tsv}"
            printf '%s\n' "$OTHER_ID" >> "$IDS_FILE"
        fi
    done
    grep -Fxq "$REQUEST_ID" "$IDS_FILE" || die "Could not find the verified request in the device metadata set"
    TMP="$QUEUE.tmp.$$"
    cp -p "$QUEUE" "$PREP/queue.old" || die "Could not stage a rollback copy of the request queue"
    awk -F '\t' -v OFS='\t' -v ids="$IDS_FILE" -v transitions="$TRANSITIONS" '
        BEGIN { while ((getline line < ids) > 0) linked[line]=1; close(ids) }
        {
            if (linked[$1] && $12=="REVOKED") {
                print $1,$4,$5 > transitions
                $12="APPROVED"
                changed++
            }
            print
        }
        END { close(transitions); if (!changed) exit 1 }
    ' "$QUEUE" > "$TMP" || { rm -f "$TMP"; die "Could not stage approval restoration"; }
    chmod 600 "$TMP" && mv "$TMP" "$QUEUE" || { rm -f "$TMP"; die "Could not commit approval restoration"; }
    if ! policy_return_auth_clear_denied "$MAC"; then
        cp -p "$PREP/queue.old" "$TMP.rollback" && mv "$TMP.rollback" "$QUEUE" || :
        die "Could not clear the return-auth block; the request status was rolled back where possible"
    fi
    touch "$HISTORY" || die "Could not open portal decision history"
    chmod 600 "$HISTORY"
    while IFS="$(printf '\t')" read -r EVENT_ID EVENT_NAME EVENT_MOBILE; do
        [ -n "$EVENT_ID" ] || continue
        printf '%s\t%s\t%s\t%s\tACCESS_RESTORED\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" "$EVENT_ID" "$EVENT_NAME" "$EVENT_MOBILE" >> "$HISTORY"
    done < "$TRANSITIONS"
    echo "Restored approval for $MAC. Existing account, package, quota usage and history were preserved. Normal guest portal authentication policy can now apply."
    exit 0
fi

# Permanently remove a guest and portal-owned records. delete-device remains
# anchored to an APPROVED/REVOKED request; forget-device accepts a MAC from the
# blocked-devices list, including legacy blocks with no surviving request row.
# No external monitoring or network-service data is in scope.
if [ "$ACTION" = delete-device ] || [ "$ACTION" = forget-device ]; then
    REQUEST_ID=""
    if [ "$ACTION" = delete-device ]; then
        [ "$#" -eq 3 ] || die "Usage: $0 delete-device APPROVED_OR_REVOKED_REQUEST_ID CLIENT_MAC"
        REQUEST_ID="$2"
        MAC="$(printf '%s' "$3" | tr 'A-F' 'a-f')"
        printf '%s\n' "$REQUEST_ID" | grep -Eq '^REQ-[0-9]+-[0-9]+$' || die "Invalid approved request ID"
    else
        [ "$#" -eq 2 ] || die "Usage: $0 forget-device CLIENT_MAC"
        MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    fi
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid device MAC"
    [ -f "$QUEUE" ] && [ ! -L "$QUEUE" ] || die "Request queue is missing or invalid"
    [ -d "$BASE_DIR/metadata" ] && [ ! -L "$BASE_DIR/metadata" ] || die "Request metadata directory is missing or invalid"
    [ -f "$QDIR/packages.tsv" ] && [ ! -L "$QDIR/packages.tsv" ] || die "Package table is missing or invalid"
    [ -f "$QDIR/accounts.tsv" ] && [ ! -L "$QDIR/accounts.tsv" ] || die "Account table is missing or invalid"

    exec 9>"$LOCK"
    flock -x 9
    if [ "$ACTION" = delete-device ]; then
        APPROVED_ROW="$(awk -F '\t' -v id="$REQUEST_ID" '$1==id && ($12=="APPROVED" || $12=="REVOKED") {print; found=1; exit} END {if (!found) exit 1}' "$QUEUE")" || die "Request is not currently approved or revoked; no data was deleted"
        META_FILE="$BASE_DIR/metadata/$REQUEST_ID.tsv"
        [ -f "$META_FILE" ] && [ ! -L "$META_FILE" ] || die "Approved request metadata is missing; cannot verify its device"
        META_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META_FILE")"
        [ "$META_MAC" = "$MAC" ] || die "Approved request ID does not belong to the supplied MAC address"
    fi
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"

    PREP="$(mktemp -d "$BASE_DIR/delete-device.XXXXXX")" || die "Could not create a safe deletion workspace"
    chmod 700 "$PREP"
    cleanup_delete() { [ -z "${PREP:-}" ] || rm -rf "$PREP"; }
    trap cleanup_delete EXIT HUP INT TERM
    IDS_FILE="$PREP/request-ids"
    : > "$IDS_FILE"
    [ -z "$REQUEST_ID" ] || printf '%s\n' "$REQUEST_ID" >> "$IDS_FILE"

    # Collect every surviving request ID and history entry linked by metadata.
    for META in "$BASE_DIR"/metadata/REQ-*.tsv; do
        [ -f "$META" ] && [ ! -L "$META" ] || continue
        OTHER_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META")"
        if [ "$OTHER_MAC" = "$MAC" ]; then
            OTHER_ID="${META##*/}"
            OTHER_ID="${OTHER_ID%.tsv}"
            printf '%s\n' "$OTHER_ID" >> "$IDS_FILE"
        fi
    done
    if [ "$ACTION" = delete-device ]; then
        grep -Fxq "$REQUEST_ID" "$IDS_FILE" || die "Could not verify the approved request in the device metadata set"
    fi

    # Revoke an active openNDS session before touching accounting.lock: BinAuth
    # may call session-end.sh, which needs that same lock to record final usage.
    command -v ndsctl >/dev/null 2>&1 || die "ndsctl is unavailable; cannot safely verify the guest session"
    command -v jsonfilter >/dev/null 2>&1 || die "jsonfilter is unavailable; cannot safely verify the guest session"
    # Package operations take packages.lock before return-auth-deny.lock.
    # Keep the same ordering here to avoid a package/delete lock inversion.
    exec 8>"$QDIR/packages.lock"
    flock -x 8
    policy_return_auth_mark_denied "$MAC" deleted_guest || die "Could not protect the deleted MAC from automatic re-enrollment; no data was deleted"
    if CLIENT_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS remained busy after retries; no account records were deleted (the deleted_guest return-auth block is in place)"
        [ "$NDS_RC" -eq 126 ] || [ "$NDS_RC" -eq 127 ] && die "ndsctl could not be executed; no account records were deleted"
        CLIENT_JSON=""
    fi
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    case "$CLIENT_STATE" in
        Authenticated)
            if NDS_DEAUTH_OUT="$(policy_ndsctl deauth "$MAC" 2>&1)"; then
                :
            else
                NDS_DEAUTH_RC=$?
                die "Could not deauthenticate the authenticated guest (ndsctl exit $NDS_DEAUTH_RC): ${NDS_DEAUTH_OUT:-no error output}; no records were deleted. The deleted_guest block remains in place."
            fi
            ;;
        Preauthenticated)
            # The guest already has no authenticated session or internet
            # access. ndsctl deauth is only valid for authenticated clients.
            ;;
        '')
            # No openNDS client entry: there is no session to disconnect.
            ;;
        *)
            die "Unexpected openNDS client state '$CLIENT_STATE'; no records were deleted"
            ;;
    esac

    # packages.lock is already held; take accounting.lock next, matching
    # package-manager.sh and quota-manager.sh lock ordering.
    if [ -x "$QDIR/package-shaper.sh" ]; then
        QUOTA_DIR="$QDIR" "$QDIR/package-shaper.sh" clear "$MAC" >/dev/null 2>&1 || die "Could not clear this guest's SQM package-shaper entry; no records were deleted"
    fi
    exec 7>"$QDIR/accounting.lock"
    flock -x 7

    mkdir -p "$PREP/accounting-old" "$PREP/accounting-new" "$PREP/request-old" "$PREP/request-new"
    : > "$PREP/committed"

    stage_mac_file() {
        FILE_NAME="$1" FIELD_NO="$2"
        SOURCE_FILE="$QDIR/$FILE_NAME"
        [ -f "$SOURCE_FILE" ] || return 0
        [ ! -L "$SOURCE_FILE" ] || die "Refusing to modify symlinked accounting file: $FILE_NAME"
        cp -p "$SOURCE_FILE" "$PREP/accounting-old/$FILE_NAME" || die "Could not stage backup for $FILE_NAME"
        awk -F '\t' -v m="$MAC" -v f="$FIELD_NO" '$f != m {print}' "$SOURCE_FILE" > "$PREP/accounting-new/$FILE_NAME" || die "Could not prepare deletion for $FILE_NAME"
        chmod 600 "$PREP/accounting-new/$FILE_NAME"
    }

    stage_mac_file packages.tsv 1
    stage_mac_file accounts.tsv 1
    stage_mac_file daily-usage.tsv 2
    stage_mac_file session-state.tsv 1
    stage_mac_file session-events.tsv 2

    cp -p "$QUEUE" "$PREP/request-old/pending.tsv" || die "Could not stage request queue"
    awk -F '\t' -v ids="$IDS_FILE" '
        BEGIN { while ((getline line < ids) > 0) keep_out[line]=1; close(ids) }
        !($1 in keep_out) {print}
    ' "$QUEUE" > "$PREP/request-new/pending.tsv" || die "Could not prepare request queue deletion"
    chmod 600 "$PREP/request-new/pending.tsv"

    HISTORY="$BASE_DIR/history.tsv"
    if [ -f "$HISTORY" ] && [ ! -L "$HISTORY" ]; then
        cp -p "$HISTORY" "$PREP/request-old/history.tsv" || die "Could not stage decision history"
        awk -F '\t' -v ids="$IDS_FILE" '
            BEGIN { while ((getline line < ids) > 0) remove_id[line]=1; close(ids) }
            !($2 in remove_id) {print}
        ' "$HISTORY" > "$PREP/request-new/history.tsv" || die "Could not prepare decision history deletion"
        chmod 600 "$PREP/request-new/history.tsv"
    fi

    commit_file() {
        SOURCE_FILE="$1" NEW_FILE="$2" OLD_FILE="$3"
        [ -f "$NEW_FILE" ] || return 0
        if ! mv "$NEW_FILE" "$SOURCE_FILE"; then
            # Restore every file already switched if a later rename fails.
            while IFS="$(printf '\t')" read -r R_SOURCE R_BACKUP; do
                [ -n "$R_SOURCE" ] && [ -f "$R_BACKUP" ] && cp -p "$R_BACKUP" "$R_SOURCE" || :
            done < "$PREP/committed"
            die "Could not commit guest deletion; previously switched files were restored where possible"
        fi
        printf '%s\t%s\n' "$SOURCE_FILE" "$OLD_FILE" >> "$PREP/committed"
    }

    commit_file "$QDIR/packages.tsv" "$PREP/accounting-new/packages.tsv" "$PREP/accounting-old/packages.tsv"
    commit_file "$QDIR/accounts.tsv" "$PREP/accounting-new/accounts.tsv" "$PREP/accounting-old/accounts.tsv"
    for FILE_NAME in daily-usage.tsv session-state.tsv session-events.tsv; do
        commit_file "$QDIR/$FILE_NAME" "$PREP/accounting-new/$FILE_NAME" "$PREP/accounting-old/$FILE_NAME"
    done
    commit_file "$QUEUE" "$PREP/request-new/pending.tsv" "$PREP/request-old/pending.tsv"
    if [ -f "$PREP/request-new/history.tsv" ]; then
        commit_file "$HISTORY" "$PREP/request-new/history.tsv" "$PREP/request-old/history.tsv"
    fi

    # Remove device metadata only after the related queue/history updates commit.
    for META in "$BASE_DIR"/metadata/REQ-*.tsv; do
        [ -f "$META" ] && [ ! -L "$META" ] || continue
        OTHER_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$META")"
        [ "$OTHER_MAC" = "$MAC" ] && rm -f "$META"
    done

    # Release queue/package/accounting locks before taking the independent
    # returning-auth attempt-cache lock to avoid lock-order inversion with watcher.
    exec 7>&-
    exec 8>&-
    exec 9>&-
    policy_return_auth_clear_attempt "$MAC" || die "Portal records were removed, but the returning-auth retry-cache entry could not be cleared; the admin block was retained for safety"
    policy_return_auth_clear_denied "$MAC" || die "Portal records were removed, but the administrator block could not be cleared; use the Blocked Devices tab to retry"
    echo "Permanently forgot guest $MAC. Its portal account, package, quota usage, session records, linked requests/history, metadata, retry-cache entry and administrator block were removed. A future visit is treated as a new guest and follows current portal/automatic-enrollment policy. nlbwmon, AdGuard Home, DHCP and all other services' data were not touched."
    exit 0
fi

# Automatic MAC enrollment. This is only called from the openNDS FAS theme
# when the administrator has explicitly enabled MAC_AUTO_ENROLL in Policy.
# The guest is registered with the configured default separate upload/download
# allowances and is then passed through the normal unassigned access policy.
if [ "$ACTION" = auto-enroll ]; then
    [ "$#" -eq 2 ] || die "Usage: $0 auto-enroll CLIENT_MAC"
    MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid device MAC"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    policy_load
    policy_return_auth_is_denied "$MAC" && die "This MAC is blocked by an administrator; explicitly re-approve or assign a package first"
    [ "$MAC_AUTO_ENROLL" = 1 ] || die "Automatic MAC enrollment is disabled by policy"
    [ -x "$QM" ] || die "Quota manager is missing"
    [ -x "$QDIR/session-policy.sh" ] || die "Session policy engine is missing"

    if CLIENT_JSON="$(policy_ndsctl json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS control remained busy after retries; automatic MAC enrollment was not attempted"
        die "Device is not present in openNDS"
    fi
    CLIENT_MAC="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.mac' 2>/dev/null | head -n 1)"
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    [ "$CLIENT_MAC" = "$MAC" ] || die "openNDS MAC verification failed"
    case "$CLIENT_STATE" in Preauthenticated|Authenticated) ;; *) die "Device is not in an eligible openNDS state" ;; esac

    ACCOUNT_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/accounts.tsv" 2>/dev/null)"
    if [ -z "$ACCOUNT_ROW" ]; then
        QUOTA_DIR="$QDIR" "$QM" add "$MAC" - "$DEFAULT_DOWNLOAD_MIB" "$DEFAULT_UPLOAD_MIB" || die "Could not create the automatic guest account"
        logger -t guest-auto-enroll "account_created mac=$MAC download_mib=$DEFAULT_DOWNLOAD_MIB upload_mib=$DEFAULT_UPLOAD_MIB"
    fi

    POLICY_OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" hold "$MAC" 2>&1)" || die "Account exists, but the unassigned access policy could not be applied: $POLICY_OUT"
    if FINAL_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS control remained busy while verifying the new account; no authentication success was assumed"
        FINAL_JSON=""
    fi
    FINAL_STATE="$(printf '%s\n' "$FINAL_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    if [ "$AUTO_AUTHENTICATE" = 1 ] && [ "$UNASSIGNED_ACCESS_MODE" = throttle ] && [ "$FINAL_STATE" = Authenticated ]; then
        echo "AUTO_MAC_ENROLLED_LIMITED: account ready; temporary speed cap ${UNASSIGNED_RATE_KBPS} kbps each way until a package is assigned."
    elif [ "$AUTO_AUTHENTICATE" = 1 ] && [ "$UNASSIGNED_ACCESS_MODE" = block ]; then
        echo "AUTO_MAC_ENROLLED_BLOCKED: account created; internet remains blocked until a package is assigned."
    else
        echo "AUTO_MAC_ENROLLED_ADMIN: account created; automatic authentication is off, so administrator action is required."
    fi
    exit 0
fi

# Background returning-device authentication. The caller supplies a MAC/IP
# pair taken from the neighbour table on openNDS's managed interface. This is
# distinct from portal resume: openNDS may not yet have a client-list entry.
# ndsctl auth performs its own gateway-interface check before authorizing.
if [ "$ACTION" = resume-preemptive ]; then
    [ "$#" -eq 4 ] || die "Usage: $0 resume-preemptive CLIENT_MAC CLIENT_IP MANAGED_INTERFACE"
    MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    CLIENT_IP="$3"
    CLIENT_IFACE="$4"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid returning-client MAC"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    policy_load
    policy_return_auth_is_denied "$MAC" && { echo "RETURN_ADMIN_BLOCKED"; exit 0; }
    policy_verify_preemptive_neighbour "$MAC" "$CLIENT_IP" "$CLIENT_IFACE" || die "Device is not a verified live neighbour on openNDS's managed guest interface"

    if CLIENT_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && { logger -t guest-return "preemptive_client_lookup_busy mac=$MAC"; echo "RETURN_NO_INTERNET"; exit 0; }
        [ "$NDS_RC" -eq 126 ] || [ "$NDS_RC" -eq 127 ] && { logger -t guest-return "preemptive_ndsctl_unavailable mac=$MAC rc=$NDS_RC"; echo "RETURN_NO_INTERNET"; exit 0; }
        CLIENT_JSON=""
    fi
    CLIENT_MAC="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.mac' 2>/dev/null | head -n 1)"
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"

    ACCOUNT_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/accounts.tsv" 2>/dev/null)"
    if [ "$CLIENT_MAC" = "$MAC" ] && [ "$CLIENT_STATE" = Authenticated ]; then
        echo "RETURN_ALREADY_AUTHENTICATED"
        exit 0
    fi
    if [ "$CLIENT_MAC" = "$MAC" ] && [ "$CLIENT_STATE" = Preauthenticated ]; then
        if [ -z "$ACCOUNT_ROW" ] && [ "$MAC_AUTO_ENROLL" = 1 ]; then
            exec "$0" auto-enroll "$MAC"
        fi
        exec "$0" resume "$MAC"
    fi
    [ -z "$CLIENT_STATE" ] || die "Unexpected openNDS state for preemptive resume: $CLIENT_STATE"

    [ "$AUTO_AUTHENTICATE" = 1 ] || { echo "RETURN_ADMIN_ACTION"; exit 0; }
    if [ -z "$ACCOUNT_ROW" ]; then
        [ "$MAC_AUTO_ENROLL" = 1 ] || { echo "RETURN_NEW_DEVICE"; exit 0; }
        LEASES="${DHCP_LEASES_FILE:-/tmp/dhcp.leases}"
        [ -r "$LEASES" ] || die "DHCP leases are unavailable; automatic enrollment refused"
        awk -v m="$MAC" -v ip="$CLIENT_IP" 'tolower($2)==m && $3==ip {found=1} END {exit !found}' "$LEASES" || die "No matching DHCP lease for this live guest; automatic enrollment refused"
        [ -x "$QM" ] || die "Quota manager is missing"
        QUOTA_DIR="$QDIR" "$QM" add "$MAC" - "$DEFAULT_DOWNLOAD_MIB" "$DEFAULT_UPLOAD_MIB" || die "Could not create the automatic guest account"
        logger -t guest-auto-enroll "preemptive_account_created mac=$MAC download_mib=$DEFAULT_DOWNLOAD_MIB upload_mib=$DEFAULT_UPLOAD_MIB"
        ACCOUNT_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/accounts.tsv" 2>/dev/null)"
    fi

    ACCOUNT_STATUS="$(printf '%s\n' "$ACCOUNT_ROW" | awk -F '\t' '{print $8}')"
    [ "$ACCOUNT_STATUS" = active ] || { echo "RETURN_NO_INTERNET"; exit 0; }

    PACKAGE_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/packages.tsv" 2>/dev/null)"
    if [ -n "$PACKAGE_ROW" ]; then
        POLICY_OUT="$(QUOTA_DIR="$QDIR" QUOTA_PREEMPTIVE_IP="$CLIENT_IP" QUOTA_PREEMPTIVE_IFACE="$CLIENT_IFACE" "$QDIR/session-policy.sh" package-preemptive "$MAC" 2>&1)" || {
            logger -t guest-return "preemptive_package_resume_denied mac=$MAC detail=$POLICY_OUT"
            echo "RETURN_NO_INTERNET"
            exit 0
        }
    else
        policy_mac_has_pending_request "$MAC" && { echo "RETURN_ADMIN_ACTION"; exit 0; }
        if [ "$UNASSIGNED_ACCESS_MODE" != throttle ]; then
            echo "RETURN_NO_INTERNET"
            exit 0
        fi
        POLICY_OUT="$(QUOTA_DIR="$QDIR" QUOTA_PREEMPTIVE_IP="$CLIENT_IP" QUOTA_PREEMPTIVE_IFACE="$CLIENT_IFACE" "$QDIR/session-policy.sh" hold-preemptive "$MAC" 2>&1)" || {
            logger -t guest-return "preemptive_hold_failed mac=$MAC detail=$POLICY_OUT"
            echo "RETURN_NO_INTERNET"
            exit 0
        }
    fi

    if FINAL_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && { logger -t guest-return "preemptive_final_lookup_busy mac=$MAC"; echo "RETURN_NO_INTERNET"; exit 0; }
        [ "$NDS_RC" -eq 126 ] || [ "$NDS_RC" -eq 127 ] && { logger -t guest-return "preemptive_final_ndsctl_unavailable mac=$MAC rc=$NDS_RC"; echo "RETURN_NO_INTERNET"; exit 0; }
        FINAL_JSON=""
    fi
    FINAL_STATE="$(printf '%s\n' "$FINAL_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    if [ "$FINAL_STATE" = Authenticated ]; then
        [ -n "$PACKAGE_ROW" ] && echo "RETURN_PREEMPTIVE_PACKAGE_AUTHENTICATED" || echo "RETURN_PREEMPTIVE_HOLD_AUTHENTICATED"
    else
        logger -t guest-return "preemptive_auth_not_confirmed mac=$MAC state=${FINAL_STATE:-not-listed}"
        echo "RETURN_NO_INTERNET"
    fi
    exit 0
fi

# Promo codes are an alternate portal entry point, not an alternate access policy.
# Apply the same active-package or unassigned holding policy used by requests.
# This path deliberately does not use auth_log or raw ndsctl auth.
if [ "$ACTION" = promo ]; then
    [ "$#" -eq 2 ] || die "Usage: $0 promo CLIENT_MAC"
    MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid promo client MAC"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    policy_load
    policy_return_auth_is_denied "$MAC" && die "This device is blocked by an administrator; approve/authenticate it before granting access"
    if CLIENT_JSON="$(policy_ndsctl json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS control remained busy after retries; promo access was not applied"
        die "Promo client is not in the openNDS client list"
    fi
    CLIENT_MAC="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.mac' 2>/dev/null | head -n 1)"
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    [ "$CLIENT_MAC" = "$MAC" ] || die "Promo client MAC did not match openNDS"
    case "$CLIENT_STATE" in Preauthenticated|Authenticated) ;; *) die "Promo client is not in an eligible openNDS state" ;; esac
    PKG_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/packages.tsv" 2>/dev/null)"
    PKG_STATUS="$(printf '%s\n' "$PKG_ROW" | awk -F '\t' '{print $9}')"
    if [ -n "$PKG_ROW" ] && [ "$PKG_STATUS" = active ]; then
        OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" package "$MAC" 2>&1)" || die "Promo code was valid, but the assigned package policy could not be applied: $OUT"
        P_EXP="$(printf '%s\n' "$PKG_ROW" | awk -F '\t' '{print $4}')"
        NOW="$(date +%s)"
        if [ "$AUTO_AUTHENTICATE" != 1 ]; then
            echo "PROMO_NO_INTERNET: Promo code accepted, but automatic authentication is disabled. The guest remains unauthenticated."
        elif [ "$P_EXP" -gt "$NOW" ] 2>/dev/null; then
            echo "PROMO_PACKAGE: Promo code accepted. The active package policy was applied."
        else
            echo "PROMO_NO_INTERNET: Promo code accepted, but the package has expired. Renewal is required."
        fi
    else
        OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" hold "$MAC" 2>&1)" || die "Promo code was valid, but the unassigned-device policy could not be applied: $OUT"
        if [ "$AUTO_AUTHENTICATE" = 1 ] && [ "$UNASSIGNED_ACCESS_MODE" = throttle ]; then
            echo "PROMO_LIMITED: Promo code accepted. The configured temporary access speed cap was applied until a package is assigned."
        else
            echo "PROMO_NO_INTERNET: Promo code accepted. Access remains blocked by the current policy."
        fi
    fi
    exit 0
fi

# Returning-device login. Match the stable client MAC to its existing quota
# account, then re-apply the same package or unassigned policy without asking
# the guest to enter their name/mobile number again. This action deliberately
# does not create or change a request-queue row or account record.
if [ "$ACTION" = resume ]; then
    [ "$#" -eq 2 ] || die "Usage: $0 resume CLIENT_MAC"
    MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Invalid returning-client MAC"
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    policy_load
    policy_return_auth_is_denied "$MAC" && { echo "RETURN_ADMIN_BLOCKED"; exit 0; }
    [ -f "$QDIR/accounts.tsv" ] || die "Account table is missing"
    [ -f "$QDIR/packages.tsv" ] || die "Package table is missing"

    if CLIENT_JSON="$(policy_ndsctl json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS control remained busy after retries; the guest was not treated as missing and no new access decision was made"
        die "Returning device is not in the openNDS client list"
    fi
    CLIENT_MAC="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.mac' 2>/dev/null | head -n 1)"
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    [ "$CLIENT_MAC" = "$MAC" ] || die "openNDS client MAC did not match the returning device"
    case "$CLIENT_STATE" in Preauthenticated|Authenticated) ;; *) die "Returning device is not in an eligible openNDS state: ${CLIENT_STATE:-unknown}" ;; esac

    ACCOUNT_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/accounts.tsv")"
    if [ -z "$ACCOUNT_ROW" ]; then
        # An authenticated MAC without an account must not retain internet access.
        [ -x "$QDIR/package-shaper.sh" ] || die "Package shaper is missing; cannot safely clear a stale guest profile"
        "$QDIR/package-shaper.sh" clear "$MAC" >/dev/null 2>&1 || die "Could not clear a stale speed profile for a new device"
        if [ "$CLIENT_STATE" = Authenticated ]; then
            policy_ndsctl deauth "$MAC" >/dev/null 2>&1 || die "Unknown device has an authenticated session that could not be revoked"
        fi
        echo "RETURN_NEW_DEVICE"
        exit 0
    fi

    ACCOUNT_STATUS="$(printf '%s\n' "$ACCOUNT_ROW" | awk -F '\t' '{print $8}')"
    if [ "$ACCOUNT_STATUS" != active ]; then
        [ -x "$QDIR/package-shaper.sh" ] && "$QDIR/package-shaper.sh" clear "$MAC" >/dev/null 2>&1 || die "Could not clear the speed profile for a disabled account"
        if [ "$CLIENT_STATE" = Authenticated ]; then
            policy_ndsctl deauth "$MAC" >/dev/null 2>&1 || die "Disabled account has an authenticated session that could not be revoked"
        fi
        echo "RETURN_NO_INTERNET"
        exit 0
    fi

    PACKAGE_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/packages.tsv")"
    if [ -n "$PACKAGE_ROW" ]; then
        # An assigned package, even pending or expired, must never fall back to
        # the unassigned holding rate. session-policy applies or denies it.
        if ! POLICY_OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" package "$MAC" 2>&1)"; then
            logger -t guest-return "package_resume_denied mac=$MAC detail=$POLICY_OUT"
            echo "RETURN_NO_INTERNET"
            exit 0
        fi
    else
        policy_mac_has_pending_request "$MAC" && { echo "RETURN_ADMIN_ACTION"; exit 0; }
        if ! POLICY_OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" hold "$MAC" 2>&1)"; then
            logger -t guest-return "unassigned_resume_failed mac=$MAC detail=$POLICY_OUT"
            echo "RETURN_NO_INTERNET"
            exit 0
        fi
    fi

    # Do not trust a success string alone; confirm the final state from openNDS.
    if FINAL_JSON="$(policy_ndsctl json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS control remained busy while verifying the returning-device session; please retry the portal action"
        die "Could not verify returning-device session after policy application"
    fi
    FINAL_STATE="$(printf '%s\n' "$FINAL_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    if [ "$AUTO_AUTHENTICATE" != 1 ]; then
        echo "RETURN_ADMIN_ACTION"
        exit 0
    fi
    if [ "$FINAL_STATE" != Authenticated ]; then
        echo "RETURN_NO_INTERNET"
        exit 0
    fi
    if [ -n "$PACKAGE_ROW" ]; then
        echo "RETURN_PACKAGE_AUTHENTICATED"
    else
        echo "RETURN_HOLD_AUTHENTICATED"
    fi
    exit 0
fi

case "$ACTION" in
    list)
        [ -f "$QUEUE" ] || { echo "No requests."; exit 0; }
        awk -F '\t' '{printf "ID: %s | Name: %s | Mobile: %s | Status: %s\n", $1, $4, $5, $12}' "$QUEUE"
        exit 0
        ;;
    enroll)
        [ "$#" -eq 4 ] || die "Usage: $0 enroll REQUEST-ID DOWNLOAD_MiB UPLOAD_MiB"
        DOWN_MIB="$3"
        UP_MIB="$4"
        ;;
    approve|reject|auto-process|authenticate)
        [ "$#" -eq 2 ] || die "Usage: $0 $ACTION REQUEST-ID"
        ;;
    *)
        die "Usage: $0 {list|list-return-blocks|clear-return-block CLIENT_MAC|deny-device CLIENT_MAC|revoke-device APPROVED_REQUEST_ID CLIENT_MAC|restore-device REVOKED_REQUEST_ID CLIENT_MAC|delete-device APPROVED_OR_REVOKED_REQUEST_ID CLIENT_MAC|forget-device CLIENT_MAC|auto-enroll CLIENT_MAC|enroll REQUEST-ID DOWNLOAD_MiB UPLOAD_MiB|approve REQUEST-ID|reject REQUEST-ID}"
        ;;
esac

printf '%s\n' "$ID" | grep -Eq '^REQ-[0-9]+-[0-9]+$' ||
    die "Invalid request ID"
[ -f "$QUEUE" ] || die "Request queue not found: $QUEUE"
[ -x "$QM" ] || die "Quota manager is missing or not executable"

exec 9>"$LOCK"
flock -x 9

ROW="$(awk -F '\t' -v id="$ID" -v action="$ACTION" \
    '$1 == id && ($12 == "PENDING" || (action == "authenticate" && $12 == "APPROVED")) { print; found=1; exit }
     END { if (!found) exit 1 }' "$QUEUE")" ||
    die "No matching request for action $ACTION: $ID"

IFS="$(printf '\t')" read -r RID CREATED TOKEN NAME MOBILE CUSTOM SESSION UP_RATE DOWN_RATE UP_QUOTA DOWN_QUOTA STATUS <<EOF_ROW
$ROW
EOF_ROW

printf '%s' "$TOKEN" | grep -Eq '^[a-fA-F0-9]{64}$' ||
    die "Invalid stored token"
printf '%s' "$CUSTOM" | grep -Eq '^[A-Za-z0-9+/=]+$' ||
    die "Invalid stored custom data"

for value in "$SESSION" "$UP_RATE" "$DOWN_RATE" "$UP_QUOTA" "$DOWN_QUOTA"; do
    case "$value" in
        ''|*[!0-9]*) die "Invalid stored numeric request field" ;;
    esac
done

resolve_client() {
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    if CLIENT_JSON="$(policy_ndsctl json "$TOKEN" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS control remained busy after retries; the request remains pending"
        die "Could not query openNDS for the request token"
    fi

    MAC="$(printf '%s\n' "$CLIENT_JSON" |
        jsonfilter -e '@.mac' 2>/dev/null | head -n 1)"
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" |
        jsonfilter -e '@.state' 2>/dev/null | head -n 1)"

    printf '%s' "$MAC" | grep -Eq '^([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}$' ||
        die "Request token is not attached to a live client"

    MAC="$(printf '%s' "$MAC" | tr 'A-F' 'a-f')"
}

if [ "$ACTION" = "auto-process" ]; then
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    policy_load
    [ "$AUTO_APPROVE_REQUESTS" = 1 ] || { echo "AUTO_PENDING: administrator approval is required"; exit 0; }
    resolve_client
    [ "$CLIENT_STATE" = "Preauthenticated" ] || die "Client is not preauthenticated; request remains pending"
    if [ "$AUTO_AUTHENTICATE" = 1 ]; then
        HOLD_OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" hold "$MAC" 2>&1)" || die "Auto-approval failed to apply temporary-access policy; request remains pending: $HOLD_OUT"
    else
        HOLD_OUT="Auto-authentication is disabled; no internet was granted."
    fi
    policy_return_auth_clear_denied "$MAC" || die "Could not clear the administrator return block; request remains pending"
    TMP="$QUEUE.tmp.$$"
    awk -F '\t' -v OFS='\t' -v id="$ID" '$1==id && $12=="PENDING" {$12="APPROVED"; found++} {print} END {if (!found) exit 1}' "$QUEUE" > "$TMP" || { rm -f "$TMP"; die "Could not store automatic approval"; }
    chmod 600 "$TMP" && mv "$TMP" "$QUEUE" || { rm -f "$TMP"; die "Could not commit automatic approval"; }
    HISTORY="$BASE_DIR/history.tsv"; touch "$HISTORY"; chmod 600 "$HISTORY"
    printf '%s\t%s\t%s\t%s\t%s\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" "$ID" "$NAME" "$MOBILE" AUTO_APPROVED >> "$HISTORY"
    if [ "$AUTO_AUTHENTICATE" = 1 ] && [ "$UNASSIGNED_ACCESS_MODE" = throttle ]; then
        echo "AUTO_APPROVED_LIMITED: request approved; temporary speed cap is ${UNASSIGNED_RATE_KBPS} kbps each way. Assign a package to replace this cap."
    else
        echo "AUTO_APPROVED_NO_INTERNET: request approved; internet remains blocked until an active package is assigned and authenticated."
    fi
    exit 0
fi

if [ "$ACTION" = "authenticate" ]; then
    resolve_client
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    policy_return_auth_clear_denied "$MAC" || die "Could not clear the administrator return block"
    PKG_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$QDIR/packages.tsv" 2>/dev/null)"
    if [ -n "$PKG_ROW" ] && [ "$(printf '%s\n' "$PKG_ROW" | awk -F '\t' '{print $9}')" = active ]; then
        OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" package-force "$MAC" 2>&1)" || die "$OUT"
    else
        OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" hold-force "$MAC" 2>&1)" || die "$OUT"
    fi
    echo "$OUT"
    exit 0
fi

if [ "$ACTION" = "enroll" ]; then
    resolve_client

    PHONE_DIGITS="$(printf '%s' "$MOBILE" | tr -cd '0-9')"
    [ "${#PHONE_DIGITS}" -ge 7 ] && [ "${#PHONE_DIGITS}" -le 15 ] ||
        die "Request phone number is not suitable for account registration"

    ACCOUNTS="$QDIR/accounts.tsv"
    if [ -f "$ACCOUNTS" ] &&
       awk -F '\t' -v m="$MAC" '$1 == m { found=1 } END { exit !found }' "$ACCOUNTS"; then
        die "An account already exists for this device; existing usage was not reset"
    fi

    QUOTA_DIR="$QDIR" "$QM" add "$MAC" "$PHONE_DIGITS" "$DOWN_MIB" "$UP_MIB" ||
        die "Account creation failed"

    echo "Quota account created for $MAC; request remains pending."
    echo "Assigned limits: download=$DOWN_MIB MiB, upload=$UP_MIB MiB"
    exit 0
fi

if [ "$ACTION" = "approve" ]; then
    # Approval grants request status only. A guest without an active package
    # always receives the configured holding policy, never the raw FAS quota
    # values. This keeps the 1 kbps/no-internet rule intact until package assign.
    resolve_client
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    policy_load
    HOLD_OUT="$(QUOTA_DIR="$QDIR" "$QDIR/session-policy.sh" hold "$MAC" 2>&1)" || {
        echo "Approval refused; request remains pending because the access policy could not be applied." >&2
        echo "$HOLD_OUT" >&2
        exit 1
    }
    policy_return_auth_clear_denied "$MAC" || die "Could not clear the administrator return block; request remains pending"
    echo "$HOLD_OUT"
    echo "Approved request $ID under the current unassigned-device policy. Assign an active package to grant package access."
fi

if [ "$ACTION" = "reject" ]; then
    # A rejected request must never be treated as an ordinary unassigned account
    # by the background preemptive-auth watcher. Resolve its MAC from the saved
    # request metadata so an administrator can reject it even after the device
    # has gone offline. Mark the MAC before changing the queue; marker failure
    # leaves the request pending and safe.
    . "$QDIR/policy-lib.sh" || die "Policy library is missing"
    command -v ndsctl >/dev/null 2>&1 || die "ndsctl is unavailable; request remains pending"
    command -v jsonfilter >/dev/null 2>&1 || die "jsonfilter is unavailable; request remains pending"
    REJECT_META="$BASE_DIR/metadata/$ID.tsv"
    [ -f "$REJECT_META" ] && [ ! -L "$REJECT_META" ] || die "Request metadata is missing; cannot safely suppress returning-device authentication"
    MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$REJECT_META")"
    printf '%s\n' "$MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || die "Request metadata does not contain a valid device MAC"
    policy_return_auth_mark_denied "$MAC" rejected_request || die "Could not suppress returning-device authentication; request remains pending"
    if CLIENT_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        [ "$NDS_RC" -eq 4 ] && die "openNDS remained busy after retries; rejection block is in place but current session state could not be checked"
        [ "$NDS_RC" -eq 126 ] || [ "$NDS_RC" -eq 127 ] && die "ndsctl could not be executed; request remains pending"
        CLIENT_JSON=""
    fi
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    if [ "$CLIENT_STATE" = "Authenticated" ]; then
        policy_ndsctl deauth "$MAC" >/dev/null 2>&1 || die "Request was marked rejected for return-auth, but the active client could not be disconnected"
    fi
fi

TMP="$QUEUE.tmp.$$"
if ! awk -F '\t' -v OFS='\t' -v id="$ID" -v action="$ACTION" '
    $1 == id && $12 == "PENDING" {
        $12 = (action == "approve" ? "APPROVED" : "REJECTED")
        found++
    }
    { print }
    END { if (!found) exit 1 }
' "$QUEUE" > "$TMP"; then
    rm -f "$TMP"
    die "Could not update request status"
fi

chmod 600 "$TMP"
mv "$TMP" "$QUEUE"

HISTORY="$BASE_DIR/history.tsv"
touch "$HISTORY"
chmod 600 "$HISTORY"
printf '%s\t%s\t%s\t%s\t%s\n' \
    "$(date '+%Y-%m-%d %H:%M:%S %z')" "$ID" "$NAME" "$MOBILE" \
    "$([ "$ACTION" = approve ] && echo APPROVED || echo REJECTED)" >> "$HISTORY"

if [ "$ACTION" = "approve" ]; then
    echo "Approved and authenticated: $ID"
else
    echo "Rejected: $ID"
fi
