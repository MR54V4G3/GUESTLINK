#!/bin/sh

ip="${REMOTE_ADDR:-}"

case "$ip" in
    192.168.2.*)
        exit 0
        ;;
    100.*)
        set -- $(printf '%s' "$ip" | tr '.' ' ')
        case "$#" in
            4)
                case "$2" in
                    ''|*[!0-9]*) ;;
                    *)
                        [ "$1" = 100 ] &&
                        [ "$2" -ge 64 ] 2>/dev/null &&
                        [ "$2" -le 127 ] 2>/dev/null &&
                        exit 0
                        ;;
                esac
                ;;
        esac
        ;;
esac

exit 1
