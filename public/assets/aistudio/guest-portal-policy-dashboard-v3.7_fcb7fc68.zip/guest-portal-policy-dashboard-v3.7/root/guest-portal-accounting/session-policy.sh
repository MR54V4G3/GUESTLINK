#!/bin/sh
# Apply the configured temporary-access or assigned-package policy to one client.
set -eu
DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
. "$DIR/policy-lib.sh"
policy_load
QM="$DIR/quota-manager.sh"
SHAPER="$DIR/package-shaper.sh"
MODE="${1:-}"
PREEMPTIVE_MODE=0
case "$MODE" in
    hold-preemptive) MODE=hold; PREEMPTIVE_MODE=1 ;;
    package-preemptive) MODE=package; PREEMPTIVE_MODE=1 ;;
esac
MAC="$(printf '%s' "${2:-}" | tr 'A-F' 'a-f')"
case "$MAC" in [0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]) ;; *) echo "ERROR: invalid MAC" >&2; exit 1 ;; esac
[ -x "$QM" ] || { echo "ERROR: quota manager missing" >&2; exit 1; }

clear_package_shape() {
    [ -x "$SHAPER" ] || return 0
    "$SHAPER" clear "$MAC" >/dev/null 2>&1
}

client_state() {
    if J="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        RC=$?
        case "$RC" in
            4) echo "openNDS control remained busy after retries; client state was not assumed." >&2 ;;
            *) echo "openNDS client lookup failed (exit $RC); client state was not assumed." >&2 ;;
        esac
        return "$RC"
    fi
    printf '%s\n' "$J" | jsonfilter -e '@.state' 2>/dev/null | head -n 1
}

preauth_client() {
    S="$(client_state)"
    if [ "$S" = Authenticated ]; then
        policy_ndsctl deauth "$MAC" >/dev/null 2>&1 || return 1
    fi
    N=0
    while [ "$N" -lt 5 ]; do
        S="$(client_state)"
        [ "$S" = Preauthenticated ] && return 0
        sleep 1
        N=$((N+1))
    done
    return 1
}

ensure_client_unauthenticated() {
    # Used when Auto-authenticate is Off. A currently authenticated client
    # must be deauthenticated successfully; never report success while leaving
    # an active session in place.
    S="$(client_state)"
    if [ "$S" = Authenticated ]; then
        policy_ndsctl deauth "$MAC" >/dev/null 2>&1 || return 1
    fi
    return 0
}

case "$MODE" in
    hold|hold-force)
        # A removed or unassigned package must not retain its old after-quota TC class.
        clear_package_shape || { echo "Could not clear the previous package speed profile." >&2; exit 1; }
        [ "$MODE" = hold-force ] || [ "$AUTO_AUTHENTICATE" = 1 ] || {
            ensure_client_unauthenticated || { echo "Could not deauthenticate client while Auto-authenticate is Off." >&2; exit 1; }
            echo "Auto-authentication is off; device left unauthenticated."
            exit 0
        }
        if [ "$PREEMPTIVE_MODE" = 1 ]; then
            policy_verify_preemptive_neighbour "$MAC" "${QUOTA_PREEMPTIVE_IP:-}" "${QUOTA_PREEMPTIVE_IFACE:-}" || {
                echo "Device is not a verified live neighbour on openNDS's managed guest interface." >&2
                exit 1
            }
        else
            preauth_client || { echo "Device is not in the openNDS preauthenticated list." >&2; exit 1; }
        fi
        [ "$UNASSIGNED_ACCESS_MODE" = throttle ] || {
            echo "Unassigned access policy is Block: no internet was granted."
            exit 0
        }
        HOLD_CUSTOM='cG9saWN5LWhvbGQ='
        OUT="$(policy_ndsctl auth "$MAC" "$UNASSIGNED_SESSION_MINUTES" "$UNASSIGNED_RATE_KBPS" "$UNASSIGNED_RATE_KBPS" 0 0 "$HOLD_CUSTOM" 2>&1)" || { echo "$OUT" >&2; exit 1; }
        printf '%s' "$OUT" | grep -Fq 'authenticated.' || { echo "$OUT" >&2; exit 1; }
        logger -t guest-policy "unassigned_hold mac=$MAC mode=throttle rate_kbps=$UNASSIGNED_RATE_KBPS"
        echo "Unassigned device authenticated at ${UNASSIGNED_RATE_KBPS} kbps in each direction."
        ;;
    package|package-force)
        [ "$MODE" = package-force ] || {
            if [ "$AUTO_AUTHENTICATE" != 1 ]; then
                clear_package_shape || { echo "Could not clear the previous package speed profile." >&2; exit 1; }
                ensure_client_unauthenticated || { echo "Could not deauthenticate client while Auto-authenticate is Off." >&2; exit 1; }
                echo "Auto-authentication is off; package saved but device remains unauthenticated."
                exit 0
            fi
        }
        ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$DIR/packages.tsv" 2>/dev/null)"
        [ -n "$ROW" ] || { clear_package_shape || :; echo "No assigned package for $MAC" >&2; exit 1; }
        P_STATUS="$(printf '%s\n' "$ROW" | awk -F '\t' '{print $9}')"
        P_EXP="$(printf '%s\n' "$ROW" | awk -F '\t' '{print $4}')"
        NOW="$(date +%s)"
        [ "$P_STATUS" = active ] && [ "$P_EXP" -gt "$NOW" ] 2>/dev/null || {
            clear_package_shape || { echo "Could not clear the inactive package speed profile." >&2; exit 1; }
            S="$(client_state)"
            if [ "$S" = Authenticated ]; then
                policy_ndsctl deauth "$MAC" >/dev/null 2>&1 || { echo "Could not deauthenticate an inactive package." >&2; exit 1; }
            fi
            echo "Package is not active; device remains unauthenticated or in its configured unassigned state."
            exit 0
        }
        # Apply an after-quota class before authentication. If shaping cannot be
        # installed for an exhausted throttle package, fail closed (no auth).
        if [ -x "$SHAPER" ]; then
            "$SHAPER" sync "$MAC" || { echo "Could not apply/clear the package after-quota speed profile; authentication refused." >&2; exit 1; }
        fi
        if [ "$PREEMPTIVE_MODE" = 1 ]; then
            policy_verify_preemptive_neighbour "$MAC" "${QUOTA_PREEMPTIVE_IP:-}" "${QUOTA_PREEMPTIVE_IFACE:-}" || {
                echo "Device is not a verified live neighbour on openNDS's managed guest interface." >&2
                exit 1
            }
            OUT="$(QUOTA_DIR="$DIR" QUOTA_PREEMPTIVE_IP="${QUOTA_PREEMPTIVE_IP:-}" QUOTA_PREEMPTIVE_IFACE="${QUOTA_PREEMPTIVE_IFACE:-}" "$QM" authorize-preemptive "$MAC" 2>&1)" || { echo "$OUT" >&2; exit 1; }
        else
            preauth_client || { S="$(client_state)"; [ -z "$S" ] && { echo "Device is offline; package is active and will apply at next authentication."; exit 0; }; echo "Could not move client into Preauthenticated state (state=$S)." >&2; exit 1; }
            OUT="$(QUOTA_DIR="$DIR" "$QM" authorize "$MAC" 2>&1)" || { echo "$OUT" >&2; exit 1; }
        fi
        echo "$OUT"
        ;;
    *) echo "Usage: $0 {hold|hold-force|hold-preemptive|package|package-force|package-preemptive} MAC" >&2; exit 2 ;;
esac
