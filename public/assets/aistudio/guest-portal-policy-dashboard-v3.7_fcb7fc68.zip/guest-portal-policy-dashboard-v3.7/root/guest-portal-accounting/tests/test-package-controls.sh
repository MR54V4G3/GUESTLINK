#!/bin/sh
# End-to-end isolated tests for package edits/removal and the automatic request workflow.
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
REQ_SOURCE=$(CDPATH= cd -- "$HERE/../guest-portal-requests" 2>/dev/null && pwd)
# The tree layout places guest-portal-requests beside guest-portal-accounting.
[ -d "$REQ_SOURCE" ] || REQ_SOURCE="$(CDPATH= cd -- "$HERE/../../guest-portal-requests" && pwd)"
T=$(mktemp -d /tmp/guest-package-controls.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin" "$T/requests/metadata"
for f in quota-manager.sh package-manager.sh policy-lib.sh session-policy.sh free-enforcer.sh poll-accounting.sh package-shaper.sh; do cp "$HERE/$f" "$T/$f"; done
cp "$HERE/policy.conf.example" "$T/policy.conf"
cp "$REQ_SOURCE/live-manager.sh" "$T/requests/live-manager.sh"
cp "$REQ_SOURCE/submit-request.sh" "$T/requests/submit-request.sh"
chmod 700 "$T"/*.sh "$T/requests"/*.sh
: > "$T/accounting.lock"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/packages.tsv"

cat > "$T/bin/date" <<'MOCK_DATE'
#!/bin/sh
exec /bin/date "$@"
MOCK_DATE
cat > "$T/bin/ndsctl" <<'MOCK_NDS'
#!/bin/sh
case "$1" in
  json)
    case "${2:-}" in *:*) JMAC="$2" ;; *) JMAC="${NDS_FAKE_MAC:-02:00:00:00:00:01}" ;; esac
    printf '{"mac":"%s","state":"%s"}\n' "$JMAC" "${NDS_STATE:-Preauthenticated}" ;;

  auth) printf '%s\n' "$*" >> "$NDS_AUTH_LOG"; echo 'authenticated.' ;;
  deauth) printf '%s\n' "$2" >> "$NDS_DEAUTH_LOG"; echo 'deauthenticated.' ;;
  *) exit 2 ;;
esac
MOCK_NDS
cat > "$T/bin/tc" <<'MOCK_TC'
#!/bin/sh
case "$1:$2:$4" in
  qdisc:show:br-guest) echo 'qdisc htb 1: root refcnt 2' ;;
  class:show:br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit' ;;
  qdisc:show:ifb4br-guest) echo 'qdisc htb 1: root refcnt 2' ;;
  class:show:ifb4br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit'; echo 'class htb 1:10 parent 1:1 rate 10Mbit ceil 10Mbit' ;;
  filter:show:br-guest) case "$*" in *ingress*) echo 'mirred redirect to ifb4br-guest' ;; esac ;;
esac
printf '%s\n' "$*" >> "$TC_LOG"
exit 0
MOCK_TC
cat > "$T/bin/jsonfilter" <<'MOCK_JSONFILTER'
#!/bin/sh
case "$*" in
  *'@.mac'*) sed -n 's/.*"mac":"\([^"]*\)".*/\1/p' ;;
  *'@.state'*) sed -n 's/.*"state":"\([^"]*\)".*/\1/p' ;;
  *) exit 1 ;;
esac
MOCK_JSONFILTER
chmod 700 "$T/bin/"*
export PATH="$T/bin:$PATH" QUOTA_DIR="$T" NDS_AUTH_LOG="$T/auth.log" NDS_DEAUTH_LOG="$T/deauth.log" TC_LOG="$T/tc.log"
export REQUEST_MANAGER_DIR="$T/requests" REQUEST_MANAGER_QUEUE="$T/requests/pending.tsv" QUOTA_MANAGER="$T/quota-manager.sh"

pass_count=0
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; pass_count=$((pass_count+1)); }
repeat_char(){ ch="$1"; count="$2"; out=""; i=0; while [ "$i" -lt "$count" ]; do out="$out$ch"; i=$((i+1)); done; printf '%s' "$out"; }

MAC=02:00:00:00:aa:01
"$T/package-manager.sh" assign "$MAC" 0771234567 100 50 10 128 512 64 64 throttle one_time 0 >/dev/null
ROW=$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$T/packages.tsv")
[ "$(printf '%s\n' "$ROW" | cut -f9)" = active ] || fail 'default immediate assignment did not activate package'
AUTH_LINE=$(grep -F "auth $MAC" "$T/auth.log" | tail -n 1)
printf '%s' "$AUTH_LINE" | grep -Eq "auth $MAC [0-9]+ 128 512 " || fail 'package assignment did not replace temporary rate with package rates'
pass 'new package defaults to immediate activation and applies its speed profile'

# Deliberately add usage, then edit package. The counters must survive.
awk -F '\t' -v OFS='\t' -v m="$MAC" '$1==m {$5=1234567;$6=765432} {print}' "$T/accounts.tsv" > "$T/accounts.tmp"
mv "$T/accounts.tmp" "$T/accounts.tsv"
START=$(printf '%s\n' "$ROW" | cut -f3)
"$T/package-manager.sh" edit "$MAC" 200 75 14 256 1024 128 256 throttle one_time 1 >/dev/null
AROW=$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$T/accounts.tsv")
EXPECTED_ACCOUNT_FIELDS="$(printf '204800\t76800\t1234567\t765432')"
[ "$(printf '%s\n' "$AROW" | cut -f3-6)" = "$EXPECTED_ACCOUNT_FIELDS" ] || fail 'package edit reset usage or did not update allowances'
PROW=$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$T/packages.tsv")
[ "$(printf '%s\n' "$PROW" | cut -f2)" = 14 ] || fail 'validity edit not stored'
[ "$(printf '%s\n' "$PROW" | cut -f4)" = "$((START+14*86400))" ] || fail 'expiry not recalculated from original start'
EXPECTED_PACKAGE_FIELDS="$(printf '256\t1024\tone_time\t1\tactive\t128\t256\tthrottle')"
[ "$(printf '%s\n' "$PROW" | cut -f5-12)" = "$EXPECTED_PACKAGE_FIELDS" ] || fail 'normal speeds, after-quota speeds/action or free policy edit not stored'
pass 'editing an assigned package updates limits, validity, speeds and free status while preserving usage'
"$T/package-manager.sh" edit "$MAC" 200 75 14 256 1024 128 256 throttle auto_renew 1 >/dev/null
[ "$(awk -F '\t' -v m="$MAC" '$1==m {print $7}' "$T/packages.tsv")" = auto_renew ] || fail 'editing package did not enable automatic renewal'
pass 'assigned package can be switched to automatic renewal without resetting usage'

"$T/package-manager.sh" remove "$MAC" >/dev/null
! awk -F '\t' -v m="$MAC" '$1==m {found=1} END {exit !found}' "$T/packages.tsv" || fail 'remove did not delete package metadata'
awk -F '\t' -v m="$MAC" '$1==m {found=1} END {exit !found}' "$T/accounts.tsv" || fail 'remove deleted the underlying quota account'
grep -Fq "auth $MAC" "$T/auth.log" || fail 'remove did not apply the unassigned holding policy'
pass 'removing a package keeps the account and moves device to the configured unassigned policy'

# Automatic request: auto approve + auto authenticate + 1 kbps holding cap.
ID=REQ-1790000000-11; TOKEN=$(repeat_char a 64); REQMAC=02:00:00:00:aa:02
printf '%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tPENDING\n' "$ID" "$(date +%s)" "$TOKEN" Guest 0771111222 dGVzdA== > "$REQUEST_MANAGER_QUEUE"
: > "$T/auth.log"
NDS_FAKE_MAC="$REQMAC" "$T/requests/live-manager.sh" auto-process "$ID" >/dev/null
[ "$(awk -F '\t' '{print $12}' "$REQUEST_MANAGER_QUEUE")" = APPROVED ] || fail 'new request was not auto approved'
grep -Eq "auth $REQMAC 1440 1 1 0 0" "$T/auth.log" || fail 'request was not authenticated with 1 kbps in both directions'
pass 'new request auto-approves and authenticates at the 1 kbps holding rate'

# Auto-auth disabled: still auto approve, but grant no internet until admin action.
sed -i 's/^AUTO_AUTHENTICATE=.*/AUTO_AUTHENTICATE=0/' "$T/policy.conf"
ID2=REQ-1790000001-12; TOKEN2=$(repeat_char b 64)
printf '%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tPENDING\n' "$ID2" "$(date +%s)" "$TOKEN2" Guest2 0771111223 dGVzdA== >> "$REQUEST_MANAGER_QUEUE"
: > "$T/auth.log"
NDS_FAKE_MAC=02:00:00:00:aa:03 "$T/requests/live-manager.sh" auto-process "$ID2" >/dev/null
[ "$(awk -F '\t' -v id="$ID2" '$1==id {print $12}' "$REQUEST_MANAGER_QUEUE")" = APPROVED ] || fail 'auto-approve did not work with auto-auth disabled'
[ ! -s "$T/auth.log" ] || fail 'auto-auth OFF still authenticated the device'
pass 'auto-authentication can be switched off independently from automatic approval'

: > "$T/deauth.log"
NDS_STATE=Authenticated NDS_DEAUTH_LOG="$T/deauth.log" NDS_FAKE_MAC=02:00:00:00:aa:03 \
    QUOTA_DIR="$T" "$T/session-policy.sh" package 02:00:00:00:aa:03 >/dev/null
 grep -Fxq '02:00:00:00:aa:03' "$T/deauth.log" || fail 'Auto-auth Off did not deauthenticate an existing authenticated session'
pass 'Auto-auth Off deauthenticates an existing session rather than leaving it online'

# Manual Authenticate / Apply package action should force the active package,
# even when automatic authentication is disabled globally.
MANUAL_AUTH_MAC=02:00:00:00:aa:03
NDS_FAKE_MAC="$MANUAL_AUTH_MAC" "$T/package-manager.sh" assign "$MANUAL_AUTH_MAC" 0771111223 100 50 10 128 512 64 64 throttle one_time 0 >/dev/null
: > "$T/auth.log"
NDS_FAKE_MAC="$MANUAL_AUTH_MAC" "$T/requests/live-manager.sh" authenticate "$ID2" >/dev/null
 grep -Eq "auth $MANUAL_AUTH_MAC [0-9]+ 128 512 " "$T/auth.log" || fail 'manual Authenticate action did not apply the active package rates'
pass 'administrator Authenticate / Apply package overrides auto-auth Off for that guest only'

# Auto-approval disabled keeps the request waiting.
sed -i 's/^AUTO_APPROVE_REQUESTS=.*/AUTO_APPROVE_REQUESTS=0/' "$T/policy.conf"
ID3=REQ-1790000002-13; TOKEN3=$(repeat_char c 64)
printf '%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tPENDING\n' "$ID3" "$(date +%s)" "$TOKEN3" Guest3 0771111224 dGVzdA== >> "$REQUEST_MANAGER_QUEUE"
NDS_FAKE_MAC=02:00:00:00:aa:04 "$T/requests/live-manager.sh" auto-process "$ID3" >/dev/null
[ "$(awk -F '\t' -v id="$ID3" '$1==id {print $12}' "$REQUEST_MANAGER_QUEUE")" = PENDING ] || fail 'auto approval OFF changed request status'
pass 'automatic approval can be disabled independently, leaving requests pending'

# Manual approval must apply the same holding/blocked policy, not bypass it by
# authenticating against the original FAS quota fields.
: > "$T/auth.log"
NDS_FAKE_MAC=02:00:00:00:aa:04 "$T/requests/live-manager.sh" approve "$ID3" >/dev/null
[ "$(awk -F '\t' -v id="$ID3" '$1==id {print $12}' "$REQUEST_MANAGER_QUEUE")" = APPROVED ] || fail 'manual approval did not update request status'
[ ! -s "$T/auth.log" ] || fail 'manual approval bypassed Auto-auth Off and granted internet'
pass 'manual approval respects Auto-auth Off and leaves the guest unauthenticated'

# With auto-auth enabled, manual approval grants only the unassigned 1 kbps hold.
sed -i 's/^AUTO_AUTHENTICATE=.*/AUTO_AUTHENTICATE=1/' "$T/policy.conf"
sed -i 's/^UNASSIGNED_ACCESS_MODE=.*/UNASSIGNED_ACCESS_MODE=throttle/' "$T/policy.conf"
ID4=REQ-1790000003-14; TOKEN4A=$(repeat_char f 64)
printf '%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tPENDING\n' "$ID4" "$(date +%s)" "$TOKEN4A" Guest4A 0771111227 dGVzdA== >> "$REQUEST_MANAGER_QUEUE"
: > "$T/auth.log"
NDS_FAKE_MAC=02:00:00:00:aa:07 "$T/requests/live-manager.sh" approve "$ID4" >/dev/null
[ "$(awk -F '\t' -v id="$ID4" '$1==id {print $12}' "$REQUEST_MANAGER_QUEUE")" = APPROVED ] || fail 'manual approval with auto-auth On did not update status'
grep -Eq 'auth 02:00:00:00:aa:07 1440 1 1 0 0' "$T/auth.log" || fail 'manual approval bypassed the 1 kbps holding rate'
pass 'manual approval with Auto-auth On applies only the temporary holding rate'

# Auto-authentication can remain enabled while the unassigned mode is Block.
sed -i 's/^AUTO_APPROVE_REQUESTS=.*/AUTO_APPROVE_REQUESTS=1/' "$T/policy.conf"
sed -i 's/^UNASSIGNED_ACCESS_MODE=.*/UNASSIGNED_ACCESS_MODE=block/' "$T/policy.conf"
ID5=REQ-1790000004-15; TOKEN5A=$(repeat_char 9 64)
printf '%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tPENDING\n' "$ID5" "$(date +%s)" "$TOKEN5A" Guest5A 0771111230 dGVzdA== >> "$REQUEST_MANAGER_QUEUE"
: > "$T/auth.log"
NDS_FAKE_MAC=02:00:00:00:aa:09 "$T/requests/live-manager.sh" auto-process "$ID5" >/dev/null
[ "$(awk -F '\t' -v id="$ID5" '$1==id {print $12}' "$REQUEST_MANAGER_QUEUE")" = APPROVED ] || fail 'auto-approve failed when unassigned mode was Block'
[ ! -s "$T/auth.log" ] || fail 'Block mode incorrectly authenticated an unassigned guest'
pass 'Block mode auto-approves the request but keeps the guest on the captive portal without internet'

# Manual package activation: assignment remains pending; activation applies rates.
sed -i 's/^UNASSIGNED_ACCESS_MODE=.*/UNASSIGNED_ACCESS_MODE=throttle/' "$T/policy.conf"
sed -i 's/^PACKAGE_ACTIVATION_MODE=.*/PACKAGE_ACTIVATION_MODE=manual/' "$T/policy.conf"
MANUAL_MAC=02:00:00:00:aa:08
: > "$T/auth.log"
NDS_STATE=Preauthenticated "$T/package-manager.sh" assign "$MANUAL_MAC" 0771111228 300 100 5 80 400 40 200 throttle one_time 0 >/dev/null
[ "$(awk -F '\t' -v m="$MANUAL_MAC" '$1==m {print $9}' "$T/packages.tsv")" = pending ] || fail 'manual activation policy did not leave package pending'
[ ! -s "$T/auth.log" ] || fail 'pending package was authenticated before activation'
NDS_STATE=Preauthenticated "$T/package-manager.sh" activate "$MANUAL_MAC" >/dev/null
[ "$(awk -F '\t' -v m="$MANUAL_MAC" '$1==m {print $9}' "$T/packages.tsv")" = active ] || fail 'manual activation did not set package active'
grep -Eq "auth $MANUAL_MAC [0-9]+ 80 400 " "$T/auth.log" || fail 'manual package activation did not apply package rates'
pass 'manual package mode waits for administrator activation and applies the package profile afterward'
sed -i 's/^PACKAGE_ACTIVATION_MODE=.*/PACKAGE_ACTIVATION_MODE=immediate/' "$T/policy.conf"

# Full FAS submission path: verify that submit-request releases its queue lock
# before live-manager takes that lock to auto-approve the request.
sed -i 's/^AUTO_APPROVE_REQUESTS=.*/AUTO_APPROVE_REQUESTS=1/' "$T/policy.conf"
sed -i 's/^AUTO_AUTHENTICATE=.*/AUTO_AUTHENTICATE=1/' "$T/policy.conf"
: > "$T/auth.log"
TOKEN6=$(repeat_char d 64); HID6=$(repeat_char e 64)
if command -v timeout >/dev/null 2>&1; then
    NDS_FAKE_MAC=02:00:00:00:aa:05 timeout 5 "$T/requests/submit-request.sh" \
        "$TOKEN6" Guest6 0771111231 dGVzdA== 0 0 0 0 0 \
        172.16.42.55 02:00:00:00:aa:05 'Test device' "$HID6" > "$T/submit.out" || {
            cat "$T/submit.out" >&2
            fail 'full request submission did not complete (possible queue-lock deadlock)'
        }
else
    NDS_FAKE_MAC=02:00:00:00:aa:05 "$T/requests/submit-request.sh" \
        "$TOKEN6" Guest6 0771111231 dGVzdA== 0 0 0 0 0 \
        172.16.42.55 02:00:00:00:aa:05 'Test device' "$HID6" > "$T/submit.out" || {
            cat "$T/submit.out" >&2
            fail 'full FAS request submission failed'
        }
fi
SUBMITTED_ID=$(sed -n 's/^Request queued: //p' "$T/submit.out" | head -n 1)
[ -n "$SUBMITTED_ID" ] || fail 'submit-request did not return the request ID'
[ "$(awk -F '\t' -v id="$SUBMITTED_ID" '$1==id {print $12}' "$REQUEST_MANAGER_QUEUE")" = APPROVED ] || fail 'submitted request was not automatically approved'
grep -Eq 'auth 02:00:00:00:aa:05 1440 1 1 0 0' "$T/auth.log" || fail 'submitted request did not receive 1 kbps holding policy'
pass 'full FAS submission auto-approves without queue-lock deadlock and applies the holding rate'

# Promo codes must use the same package and unassigned-device policy engine.
: > "$T/auth.log"
PROMO_OUT=$(NDS_STATE=Preauthenticated "$T/requests/live-manager.sh" promo "$MANUAL_MAC")
printf '%s' "$PROMO_OUT" | grep -q '^PROMO_PACKAGE:' || fail 'promo with active package did not report package policy'
grep -Eq "auth $MANUAL_MAC [0-9]+ 80 400 " "$T/auth.log" || fail 'promo bypassed normal package rate enforcement'
pass 'promo route applies active package policy rather than direct authentication'

PROMO_HOLD_MAC=02:00:00:00:aa:10
: > "$T/auth.log"
PROMO_OUT=$(NDS_STATE=Preauthenticated "$T/requests/live-manager.sh" promo "$PROMO_HOLD_MAC")
printf '%s' "$PROMO_OUT" | grep -q '^PROMO_LIMITED:' || fail 'promo for unassigned device did not report temporary policy'
grep -Eq "auth $PROMO_HOLD_MAC 1440 1 1 0 0 " "$T/auth.log" || fail 'promo for unassigned device bypassed temporary speed cap'
pass 'promo route applies configured temporary holding policy for unassigned guests'

sed -i 's/^AUTO_AUTHENTICATE=.*/AUTO_AUTHENTICATE=0/' "$T/policy.conf"
: > "$T/auth.log"; : > "$T/deauth.log"
PROMO_OUT=$(NDS_STATE=Authenticated "$T/requests/live-manager.sh" promo "$MANUAL_MAC")
printf '%s' "$PROMO_OUT" | grep -q '^PROMO_NO_INTERNET:' || fail 'promo reported internet while Auto-auth was disabled'
! grep -q "auth $MANUAL_MAC" "$T/auth.log" || fail 'promo authenticated a guest while Auto-auth was disabled'
grep -Fxq "$MANUAL_MAC" "$T/deauth.log" || fail 'promo left an existing authenticated guest online while Auto-auth was disabled'
pass 'promo route obeys Auto-auth Off and deauthenticates existing sessions'
sed -i 's/^AUTO_AUTHENTICATE=.*/AUTO_AUTHENTICATE=1/' "$T/policy.conf"

# Also verify the portal theme no longer contains a direct auth_log bypass.
THEME_SOURCE=$(CDPATH= cd -- "$HERE/../../usr/lib/opennds" && pwd)/theme_guest-approval-requests.sh
if grep -q 'auth_log' "$THEME_SOURCE"; then fail 'promo theme still has a direct auth_log authentication path'; fi
pass 'promo theme has no direct auth_log bypass'

# Render the real Packages CGI against an isolated, trusted test account.
DASH_CGI=$(CDPATH= cd -- "$HERE/../../srv/guest-dashboard/cgi-bin" && pwd)/packages
cat > "$T/allow-client.sh" <<'ALLOW'
#!/bin/sh
[ "${REMOTE_ADDR:-}" = 192.168.2.55 ]
ALLOW
chmod 700 "$T/allow-client.sh"
UI_MAC=02:00:00:00:aa:06
UI_NOW=$(date +%s)
printf '%s\t0771111226\t1048576\t262144\t1234\t5678\t2026-11-01\tactive\t0\t-\t0\t0\n' "$UI_MAC" >> "$T/accounts.tsv"
printf '%s\t7\t%s\t%s\t64\t512\tone_time\t0\tactive\t32\t64\tthrottle\n' "$UI_MAC" "$UI_NOW" "$((UI_NOW+7*86400))" >> "$T/packages.tsv"
UI_OUT=$(REQUEST_METHOD=GET REMOTE_ADDR=192.168.2.55 QUOTA_DIR="$T" \
    QUOTA_CGI_ALLOW="$T/allow-client.sh" PACKAGE_MANAGER="$T/package-manager.sh" \
    /bin/sh "$DASH_CGI")
printf '%s' "$UI_OUT" | grep -Fq 'Edit assigned package' || fail 'assigned package editor is missing from rendered page'
printf '%s' "$UI_OUT" | grep -Fq 'Remove package' || fail 'assigned package removal control is missing from rendered page'
printf '%s' "$UI_OUT" | grep -Fq 'Save package changes' || fail 'package edit submit action is missing'
if printf '%s' "$UI_OUT" | grep -Eq '__[A-Z][A-Z_]*__'; then fail 'a package page template placeholder was not expanded'; fi
printf '%s' "$UI_OUT" | grep -Fq 'after_upload_kbps' || fail 'after-quota upload editor field missing'
printf '%s' "$UI_OUT" | grep -Fq 'after_quota_action' || fail 'after-quota action editor missing'
printf '%s' "$UI_OUT" | grep -Fq 'value="auto_renew"' || fail 'automatic renewal option missing from Packages CGI'
pass 'Packages CGI renders assigned-package edit/remove, renewal selection and separate normal/after-quota controls without placeholders'

# The Quotas CGI is another administrator authentication entry point. Verify
# it uses the shared session-policy path rather than raw quota-manager auth.
QUOTAS_CGI=$(CDPATH= cd -- "$HERE/../../srv/guest-dashboard/cgi-bin" && pwd)/quotas
QUOTA_BODY="action=authorize&mac=$UI_MAC"
: > "$T/auth.log"
QUOTA_OUT=$(printf '%s' "$QUOTA_BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#QUOTA_BODY}" \
    REMOTE_ADDR=192.168.2.55 QUOTA_DIR="$T" QUOTA_CGI_ALLOW="$T/allow-client.sh" \
    QUOTA_MANAGER="$T/quota-manager.sh" /bin/sh "$QUOTAS_CGI")
printf '%s' "$QUOTA_OUT" | grep -q 'Package-policy authorization result' || fail 'Quotas CGI did not route an active package through session policy'
grep -Eq "auth $UI_MAC [0-9]+ 64 512 " "$T/auth.log" || fail 'Quotas CGI did not apply the active package speed profile'
pass 'Quotas CGI administrator authorization uses the shared package policy engine'

echo "ALL $pass_count PACKAGE/REQUEST CONTROL TESTS PASSED"
