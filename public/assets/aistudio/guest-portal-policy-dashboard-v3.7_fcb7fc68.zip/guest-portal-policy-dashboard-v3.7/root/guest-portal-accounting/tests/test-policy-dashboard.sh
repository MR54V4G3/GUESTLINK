#!/bin/sh
# Isolated tests for the administrator-editable Policy dashboard CGI.
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
CGI=$(CDPATH= cd -- "$HERE/../.." && pwd)/srv/guest-dashboard/cgi-bin/policy
T=$(mktemp -d /tmp/guest-policy-dashboard-test.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/accounting"
cp "$HERE/policy-lib.sh" "$T/accounting/policy-lib.sh"
cp "$HERE/policy.conf.example" "$T/accounting/policy.conf"
cat > "$T/allow-client.sh" <<'ALLOW'
#!/bin/sh
[ "${REMOTE_ADDR:-}" = 192.168.2.55 ]
ALLOW
chmod 700 "$T/allow-client.sh"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

BODY='action=save&default_download_mib=2048&default_upload_mib=512&default_validity_days=14&default_upload_kbps=128&default_download_kbps=2048&default_after_upload_kbps=32&default_after_download_kbps=64&default_after_quota_action=throttle&default_free_enabled=1&free_window_start=22%3A00&free_window_end=06%3A00&auto_approve_requests=1&auto_authenticate=1&unassigned_access_mode=throttle&unassigned_rate_kbps=1&unassigned_session_minutes=1440&package_activation_mode=immediate&mac_auto_enroll=0'
OUT=$(printf '%s' "$BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" REMOTE_ADDR=192.168.2.55 QUOTA_DIR="$T/accounting" QUOTA_CGI_ALLOW="$T/allow-client.sh" /bin/sh "$CGI")
grep -q 'Policy updated' <<EOF_OUT
$OUT
EOF_OUT
for expected in \
  'DEFAULT_DOWNLOAD_MIB=2048' \
  'DEFAULT_UPLOAD_MIB=512' \
  'DEFAULT_VALIDITY_DAYS=14' \
  'DEFAULT_UPLOAD_KBPS=128' \
  'DEFAULT_DOWNLOAD_KBPS=2048' \
  'DEFAULT_AFTER_UPLOAD_KBPS=32' \
  'DEFAULT_AFTER_DOWNLOAD_KBPS=64' \
  'DEFAULT_AFTER_QUOTA_ACTION=throttle' \
  'DEFAULT_FREE_ENABLED=1' \
  'FREE_WINDOW_START=22:00' \
  'FREE_WINDOW_END=06:00' \
  'AUTO_APPROVE_REQUESTS=1' \
  'AUTO_AUTHENTICATE=1' \
  'UNASSIGNED_ACCESS_MODE=throttle' \
  'UNASSIGNED_RATE_KBPS=1' \
  'UNASSIGNED_SESSION_MINUTES=1440' \
  'PACKAGE_ACTIVATION_MODE=immediate' \
  'MAC_AUTO_ENROLL=0'; do
    grep -Fxq "$expected" "$T/accounting/policy.conf" || fail "policy page did not save $expected"
done
pass 'Policy page saves validated package defaults and custom cross-midnight free window'

OUT=$(REQUEST_METHOD=GET REMOTE_ADDR=192.168.2.55 QUOTA_DIR="$T/accounting" QUOTA_CGI_ALLOW="$T/allow-client.sh" /bin/sh "$CGI")
printf '%s' "$OUT" | grep -q 'value="2048"' || fail 'Policy page did not render saved download default'
printf '%s' "$OUT" | grep -q 'value="22:00"' || fail 'Policy page did not render saved free-window start'
printf '%s' "$OUT" | grep -q '/cgi-bin/policy' || fail 'Policy navigation link missing'
printf '%s' "$OUT" | grep -q 'auto_approve_requests' || fail 'auto-approval control missing'
printf '%s' "$OUT" | grep -q 'auto_authenticate' || fail 'auto-authentication control missing'
printf '%s' "$OUT" | grep -q 'unassigned_access_mode' || fail 'unassigned access control missing'
printf '%s' "$OUT" | grep -q 'default_after_upload_kbps' || fail 'after-quota default upload control missing'
printf '%s' "$OUT" | grep -q 'default_after_quota_action' || fail 'after-quota default action control missing'
printf '%s' "$OUT" | grep -q 'mac_auto_enroll' || fail 'automatic MAC enrollment control missing'
printf '%s' "$OUT" | grep -q "Follow the assigned package's after-quota action" || fail 'Policy page still describes quota exhaustion as globally blocked'
printf '%s' "$OUT" | grep -q 'Throttle keeps the guest connected' || fail 'Policy page does not explain per-package throttle behaviour'
pass 'Policy page renders saved values and dashboard navigation'
pass 'Policy lifecycle summary describes per-package throttle/disconnect behaviour accurately'

MAC_ON='action=save&default_download_mib=2048&default_upload_mib=512&default_validity_days=14&default_upload_kbps=128&default_download_kbps=2048&default_after_upload_kbps=32&default_after_download_kbps=64&default_after_quota_action=throttle&default_free_enabled=1&free_window_start=22%3A00&free_window_end=06%3A00&auto_approve_requests=1&auto_authenticate=1&unassigned_access_mode=throttle&unassigned_rate_kbps=1&unassigned_session_minutes=1440&package_activation_mode=immediate&mac_auto_enroll=1'
OUT=$(printf '%s' "$MAC_ON" | REQUEST_METHOD=POST CONTENT_LENGTH="${#MAC_ON}" REMOTE_ADDR=192.168.2.55 QUOTA_DIR="$T/accounting" QUOTA_CGI_ALLOW="$T/allow-client.sh" /bin/sh "$CGI")
grep -Fxq 'MAC_AUTO_ENROLL=1' "$T/accounting/policy.conf" || fail 'automatic MAC enrollment On setting was not saved'
pass 'Policy page can enable automatic MAC enrollment independently'

BAD='action=save&default_download_mib=111&default_upload_mib=222&default_validity_days=3&default_upload_kbps=10&default_download_kbps=10&default_free_enabled=0&free_window_start=07%3A00&free_window_end=07%3A00'
OUT=$(printf '%s' "$BAD" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BAD}" REMOTE_ADDR=192.168.2.55 QUOTA_DIR="$T/accounting" QUOTA_CGI_ALLOW="$T/allow-client.sh" /bin/sh "$CGI")
printf '%s' "$OUT" | grep -q 'Action not completed\|Policy information' || fail 'invalid equal start/end was not rejected'
grep -Fxq 'DEFAULT_DOWNLOAD_MIB=2048' "$T/accounting/policy.conf" || fail 'invalid policy submission changed existing settings'
pass 'Policy page rejects equal start/end and preserves prior configuration'

OUT=$(REQUEST_METHOD=GET REMOTE_ADDR=203.0.113.8 QUOTA_DIR="$T/accounting" QUOTA_CGI_ALLOW="$T/allow-client.sh" /bin/sh "$CGI")
printf '%s' "$OUT" | grep -q 'Forbidden' || fail 'Policy page did not reject untrusted source'
pass 'Policy page rejects requests outside trusted admin sources'

echo 'ALL 5 POLICY DASHBOARD TESTS PASSED'
