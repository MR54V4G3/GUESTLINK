#!/bin/sh
# Isolated installer/migration test. All destinations are temporary directories.
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PKG_ROOT=$(CDPATH= cd -- "$HERE/../.." && pwd)
T=$(mktemp -d /tmp/guest-installer-mock.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
A="$T/accounting"; D="$T/dashboard"; R="$T/requests"; N="$T/opennds"; I="$T/init.d"
mkdir -p "$A/tests" "$D" "$R" "$N" "$I" "$T/bin"

# Minimal read-only tc mock for the installer's SQM/IFB preflight.
cat > "$T/bin/tc" <<'MOCK_TC'
#!/bin/sh
case "$1:$2:$4" in
    qdisc:show:br-guest) echo 'qdisc htb 1: root' ;;
    class:show:br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit' ;;
    qdisc:show:ifb4br-guest) echo 'qdisc htb 1: root' ;;
    class:show:ifb4br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit' ;;
    filter:show:br-guest) case "$*" in *ingress*) echo 'mirred redirect to ifb4br-guest' ;; esac ;;
esac
MOCK_TC
chmod 700 "$T/bin/tc"

# A minimal but schema-valid old v2 data set and recognizable existing files.
printf '%s\n' '# v2: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS' \
  '02:11:22:33:44:55	7	1700000000	1700604800	128	512	one_time	1	active' > "$A/packages.tsv"
printf '%s\n' '# test accounts' '02:11:22:33:44:55	0771234567	102400	51200	12345	6789	2026-11-01	active	0	-	0	0' > "$A/accounts.tsv"
printf '%s\n' 'DEFAULT_DOWNLOAD_MIB=777' 'AUTO_AUTHENTICATE=0' > "$A/policy.conf"
printf '%s\n' 'old-policy-example-marker' > "$A/policy.conf.example"
printf '%s\n' '# original poller' '"$DIR/free-enforcer.sh" >/dev/null 2>&1' > "$A/poll-accounting.sh"
printf '%s\n' '# original session callback' > "$A/session-end.sh"
chmod 700 "$A/poll-accounting.sh" "$A/session-end.sh"
for f in quota-manager.sh package-manager.sh free-enforcer.sh policy-lib.sh session-policy.sh verify-free-window-runtime.sh; do printf 'old %s\n' "$f" > "$A/$f"; done
for f in requests packages quotas policy disconnect; do printf 'old cgi %s\n' "$f" > "$D/$f"; done
for f in live-manager.sh submit-request.sh; do printf 'old request %s\n' "$f" > "$R/$f"; done
printf '%s\n' 'old theme' > "$N/theme_guest-approval-requests.sh"
printf '%s\n' 'old return auth init marker' > "$I/guest-return-auth"
chmod 600 "$A/packages.tsv" "$A/accounts.tsv" "$A/policy.conf" "$A/policy.conf.example"
ACCOUNTS_BEFORE=$(sha256sum "$A/accounts.tsv" | awk '{print $1}')
POLICY_BEFORE=$(sha256sum "$A/policy.conf" | awk '{print $1}')
POLLER_BEFORE=$(sha256sum "$A/poll-accounting.sh" | awk '{print $1}')

QUOTA_DIR="$A" GUEST_DASHBOARD_CGI="$D" REQUEST_MANAGER_DIR="$R" OPENNDS_LIB_DIR="$N" GUEST_INITD_DIR="$I" TC_BIN="$T/bin/tc" \
  /bin/sh "$PKG_ROOT/install-guest-policy-dashboard.sh" > "$T/install.log" 2>&1 || {
    cat "$T/install.log" >&2
    echo 'FAIL: isolated installer execution failed' >&2
    exit 1
  }

BACKUP=$(sed -n 's/^Backup directory: //p' "$T/install.log" | head -n 1)
EXPECTED='# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION'
[ "$(sed -n '1p' "$A/packages.tsv")" = "$EXPECTED" ] || { cat "$T/install.log"; echo 'FAIL: package header not migrated' >&2; exit 1; }
ROW=$(sed -n '2p' "$A/packages.tsv")
[ "$(printf '%s\n' "$ROW" | cut -f1-9)" = '02:11:22:33:44:55	7	1700000000	1700604800	128	512	one_time	1	active' ] || { echo 'FAIL: v2 package columns were not preserved' >&2; exit 1; }
[ "$(printf '%s\n' "$ROW" | cut -f10-12)" = '64	64	disconnect' ] || { echo 'FAIL: legacy after-quota defaults are wrong' >&2; exit 1; }
[ "$(sha256sum "$A/accounts.tsv" | awk '{print $1}')" = "$ACCOUNTS_BEFORE" ] || { echo 'FAIL: accounts.tsv changed' >&2; exit 1; }
[ "$(sha256sum "$A/policy.conf" | awk '{print $1}')" = "$POLICY_BEFORE" ] || { echo 'FAIL: policy.conf changed' >&2; exit 1; }
grep -q 'auto-renew.sh' "$A/poll-accounting.sh" || { echo 'FAIL: installed poll-accounting.sh does not invoke auto-renew' >&2; exit 1; }
grep -q 'free-enforcer.sh' "$A/poll-accounting.sh" || { echo 'FAIL: installed poll-accounting.sh lost expiry enforcement' >&2; exit 1; }
[ "$(sha256sum "$BACKUP/root/guest-portal-accounting/poll-accounting.sh" | awk '{print $1}')" = "$POLLER_BEFORE" ] || { echo 'FAIL: original poller was not retained in the installer backup' >&2; exit 1; }
[ -x "$A/package-shaper.sh" ] || { echo 'FAIL: package-shaper not installed executable' >&2; exit 1; }
[ -x "$A/tests/test-returning-device.sh" ] || { echo 'FAIL: returning-device test not installed' >&2; exit 1; }
[ -x "$A/tests/test-ndsctl-retry.sh" ] || { echo 'FAIL: ndsctl retry regression test not installed' >&2; exit 1; }
[ -x "$A/tests/test-auto-renew.sh" ] && [ -x "$A/tests/test-delete-device.sh" ] && [ -x "$A/tests/test-device-inventory.sh" ] && [ -x "$A/tests/test-auto-mac-enroll.sh" ] && [ -x "$A/tests/test-returning-preemptive.sh" ] || { echo 'FAIL: new feature tests not installed' >&2; exit 1; }
grep -q 'quota_deauth_callback_ignored_for_throttle_package' "$A/session-end.sh" || { echo 'FAIL: updated BinAuth callback not installed' >&2; exit 1; }
grep -q 'Traffic-control preflight: SQM HTB/IFB hierarchy is compatible' "$T/install.log" || { cat "$T/install.log"; echo 'FAIL: installer did not confirm the read-only SQM/IFB preflight' >&2; exit 1; }
[ -n "$BACKUP" ] && [ -f "$BACKUP/root/guest-portal-accounting/packages.tsv" ] || { echo 'FAIL: packages.tsv backup missing' >&2; exit 1; }
grep -q '^# v2:' "$BACKUP/root/guest-portal-accounting/packages.tsv" || { echo 'FAIL: original v2 package backup is not intact' >&2; exit 1; }
grep -q 'old-policy-example-marker' "$BACKUP/root/guest-portal-accounting/policy.conf.example" || { echo 'FAIL: policy.conf.example backup missing' >&2; exit 1; }
grep -q 'old return auth init marker' "$BACKUP/etc/init.d/guest-return-auth" || { echo 'FAIL: prior returning-auth init service was not backed up' >&2; exit 1; }
echo 'PASS: installer backs up and migrates v2 packages while preserving existing account/policy data'
[ -x "$A/auto-renew.sh" ] || { echo 'FAIL: auto-renew worker not installed executable' >&2; exit 1; }
echo 'PASS: installer deploys package shaper, updated BinAuth callback and auto-renew-enabled poller'
echo 'PASS: installer retains rollback copies of package metadata and policy example'
echo 'PASS: installer verifies the existing SQM/IFB hierarchy before changing live files'
grep -q 'MAC_AUTO_ENROLL=0' "$A/policy.conf.example" || { echo 'FAIL: automatic MAC enrollment must default to Off' >&2; exit 1; }
grep -q 'MAC_AUTO_ENROLL=0' "$A/policy-lib.sh" || { echo 'FAIL: Policy library automatic MAC enrollment default missing' >&2; exit 1; }
grep -q 'mac_auto_enroll' "$D/policy" || { echo 'FAIL: automatic MAC onboarding control not deployed' >&2; exit 1; }
grep -q 'Connected device inventory' "$D/requests" || { echo 'FAIL: rich device inventory not deployed' >&2; exit 1; }
echo 'PASS: installer deploys connected-device inventory and Policy-controlled automatic MAC enrollment'
[ -x "$A/returning-auth.sh" ] || { echo 'FAIL: returning-auth watcher was not deployed' >&2; exit 1; }
[ -x "$I/guest-return-auth" ] && grep -q 'returning-auth.sh daemon' "$I/guest-return-auth" || { echo 'FAIL: returning-auth init service was not deployed' >&2; exit 1; }
grep -q 'old return auth init marker' "$BACKUP/etc/init.d/guest-return-auth" || { echo 'FAIL: init service backup was not retained' >&2; exit 1; }
grep -q 'policy_mac_has_pending_request' "$A/returning-auth.sh" || { echo 'FAIL: pending manual-approval guard was not deployed' >&2; exit 1; }
grep -q 'function decode' "$D/requests" || { echo 'FAIL: URL-decoding form handler was not deployed' >&2; exit 1; }
grep -q 'policy_return_auth_is_denied' "$A/returning-auth.sh" || { echo 'FAIL: administrator return-deny guard was not deployed' >&2; exit 1; }
grep -q 'rejected_request' "$R/live-manager.sh" || { echo 'FAIL: rejected-request return-auth suppression was not deployed' >&2; exit 1; }
grep -q 'policy_ndsctl()' "$A/policy-lib.sh" && grep -q 'policy_ndsctl_once json' "$A/poll-accounting.sh" || { echo 'FAIL: ndsctl contention retry and accounting-lock safe polling were not deployed' >&2; exit 1; }
grep -q 'revoke-device' "$R/live-manager.sh" && grep -q 'restore-device' "$R/live-manager.sh" && grep -q 'REVOKED' "$D/requests" || { echo 'FAIL: approval revoke/restore workflow was not deployed' >&2; exit 1; }
grep -q 'Permanently delete portal records' "$D/requests" && grep -q 'policy_return_auth_clear_attempt' "$R/live-manager.sh" || { echo 'FAIL: portal-only permanent deletion cleanup was not deployed' >&2; exit 1; }
grep -q 'list-return-blocks' "$R/live-manager.sh" && grep -q 'forget-device' "$R/live-manager.sh" && grep -q 'panel-blocked' "$D/requests" || { echo 'FAIL: Blocked Devices management was not deployed' >&2; exit 1; }
grep -q 'RETURN_ADMIN_BLOCKED' "$N/theme_guest-approval-requests.sh" && grep -q 'Access temporarily disabled' "$N/theme_guest-approval-requests.sh" || { echo 'FAIL: explicit administrator-block portal message was not deployed' >&2; exit 1; }
grep -q 'Permanent deletion was not confirmed' "$D/requests" || { echo 'FAIL: server-side permanent-delete confirmation was not deployed' >&2; exit 1; }
grep -q 'already preauthenticated' "$D/disconnect" || { echo 'FAIL: preauthenticated disconnect handling was not deployed' >&2; exit 1; }
grep -q 'old cgi disconnect' "$BACKUP/srv/guest-dashboard/cgi-bin/disconnect" || { echo 'FAIL: prior disconnect CGI was not backed up' >&2; exit 1; }
echo 'PASS: installer deploys the optional preemptive-auth watcher with approval and administrator-deny guards, rollback backup and no auto-start'
echo 'PASS: installer prevents rejected requests from being silently reauthenticated on reconnect'
echo 'PASS: installer deploys ndsctl contention handling and both portal account-removal methods'
echo 'ALL 8 INSTALLER MOCK CHECKS PASSED'
