#!/bin/sh
# Exercise silent reconnect authorization over the openNDS managed guest bridge.
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
PKG_ROOT="$(CDPATH= cd -- "$HERE/../.." && pwd)"
T="$(mktemp -d /tmp/guest-preemptive-test.XXXXXX)"
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin" "$T/requests/metadata" "$T/locks"
for f in policy-lib.sh quota-manager.sh session-policy.sh returning-auth.sh; do cp "$HERE/$f" "$T/$f"; done
cp "$PKG_ROOT/root/guest-portal-requests/live-manager.sh" "$T/requests/live-manager.sh"
cp "$HERE/package-shaper.sh" "$T/package-shaper-real-source"
chmod 700 "$T"/*.sh "$T/requests/live-manager.sh"

MAC=02:00:00:00:ee:01
UNKNOWN=02:00:00:00:ee:02
IP=172.16.42.101
NOW=$(/bin/date +%s)
STATE_FILE="$T/nds-state"
AUTH_LOG="$T/auth.log"
DEAUTH_LOG="$T/deauth.log"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/packages.tsv"
printf '%s\t0771234567\t102400\t51200\t0\t0\t2026-11-02\tactive\t0\t-\t0\t0\n' "$MAC" > "$T/accounts.tsv"
: > "$T/daily-usage.tsv"; : > "$T/session-state.tsv"; : > "$T/session-events.tsv"
printf '%s %s %s guest-device 01:02:03:04:05:06\n' "$((NOW+3600))" "$MAC" "$IP" > "$T/dhcp.leases"
: > "$STATE_FILE"; : > "$AUTH_LOG"; : > "$DEAUTH_LOG"

cat > "$T/policy.conf" <<'POLICY'
DEFAULT_DOWNLOAD_MIB=100
DEFAULT_UPLOAD_MIB=50
DEFAULT_VALIDITY_DAYS=7
DEFAULT_UPLOAD_KBPS=64
DEFAULT_DOWNLOAD_KBPS=512
DEFAULT_AFTER_UPLOAD_KBPS=32
DEFAULT_AFTER_DOWNLOAD_KBPS=64
DEFAULT_AFTER_QUOTA_ACTION=throttle
DEFAULT_FREE_ENABLED=0
FREE_WINDOW_START=00:00
FREE_WINDOW_END=07:00
DEFAULT_RENEWAL_MODE=one_time
EXPIRED_ACCOUNT_ACTION=block_until_renewed
AUTO_APPROVE_REQUESTS=1
AUTO_AUTHENTICATE=1
UNASSIGNED_ACCESS_MODE=throttle
UNASSIGNED_RATE_KBPS=24
UNASSIGNED_SESSION_MINUTES=1440
PACKAGE_ACTIVATION_MODE=immediate
MAC_AUTO_ENROLL=0
POLICY

cat > "$T/bin/ndsctl" <<'NDS'
#!/bin/sh
case "$1" in
 status)
  cat <<'STATUS'
Managed interface: br-guest
Preemptive Authentication is Enabled
STATUS
  ;;
 json)
  mac="${NDS_MAC_OVERRIDE:-$2}"; state=$(cat "$STATE_FILE" 2>/dev/null)
  if [ -n "$state" ]; then printf '{"mac":"%s","state":"%s"}\n' "$mac" "$state"; else printf '{"mac":"","state":""}\n'; fi
  ;;
 auth)
  printf '%s\n' "$*" >> "$AUTH_LOG"
  echo Authenticated > "$STATE_FILE"
  echo 'authenticated.'
  ;;
 deauth)
  printf '%s\n' "$2" >> "$DEAUTH_LOG"
  echo Preauthenticated > "$STATE_FILE"
  echo 'deauthenticated.'
  ;;
 *) exit 2 ;;
esac
NDS
cat > "$T/bin/ip" <<'IP'
#!/bin/sh
[ "$1" = neigh ] && [ "$2" = show ] && [ "$3" = dev ] || exit 2
printf '%s dev %s lladdr %s REACHABLE\n' "$NEIGH_IP" "$NEIGH_IFACE" "$NEIGH_MAC"
IP
cat > "$T/bin/jsonfilter" <<'JSONFILTER'
#!/bin/sh
case "$*" in
 *'@.mac'*) sed -n 's/.*"mac":"\([^"]*\)".*/\1/p' ;;
 *'@.state'*) sed -n 's/.*"state":"\([^"]*\)".*/\1/p' ;;
 *) exit 1 ;;
esac
JSONFILTER
cat > "$T/bin/logger" <<'LOGGER'
#!/bin/sh
exit 0
LOGGER
cat > "$T/package-shaper.sh" <<'SHAPER'
#!/bin/sh
echo "$*" >> "$SHAPER_LOG"
exit 0
SHAPER
chmod 700 "$T/bin/ndsctl" "$T/bin/ip" "$T/bin/jsonfilter" "$T/bin/logger" "$T/package-shaper.sh"

export PATH="$T/bin:$PATH" QUOTA_DIR="$T" REQUEST_MANAGER_DIR="$T/requests" \
  REQUEST_MANAGER_QUEUE="$T/requests/pending.tsv" DHCP_LEASES_FILE="$T/dhcp.leases" \
  STATE_FILE AUTH_LOG DEAUTH_LOG SHAPER_LOG="$T/shaper.log" \
  RETURN_AUTH_LOCK="$T/locks/return-auth.lock" RETURN_AUTH_ATTEMPTS="$T/attempts.tsv" \
  NEIGH_IFACE=br-guest NEIGH_IP="$IP" NEIGH_MAC="$MAC" \
  QUOTA_PREEMPTIVE_IP="$IP" QUOTA_PREEMPTIVE_IFACE=br-guest

PASS=0
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; PASS=$((PASS+1)); }
reset_run(){
  : > "$STATE_FILE"; : > "$AUTH_LOG"; : > "$DEAUTH_LOG"; : > "$T/attempts.tsv"; : > "$T/shaper.log"
  rm -f "$T/return-auth-deny.tsv"
  sed -i '/^MAC_AUTO_ENROLL=/d;/^AUTO_AUTHENTICATE=/d;/^UNASSIGNED_ACCESS_MODE=/d' "$T/policy.conf"
  printf '%s\n' 'AUTO_AUTHENTICATE=1' 'MAC_AUTO_ENROLL=0' 'UNASSIGNED_ACCESS_MODE=throttle' >> "$T/policy.conf"
  NEIGH_MAC="$MAC"; export NEIGH_MAC
}
run_worker(){ QUOTA_DIR="$T" REQUEST_MANAGER_DIR="$T/requests" "$T/returning-auth.sh" once; }

# Known unassigned/approved account gets the temporary hold policy before CPD.
reset_run
run_worker
[ "$(cat "$STATE_FILE")" = Authenticated ] || fail 'known unassigned guest was not preemptively authenticated'
grep -q "$MAC 1440 24 24 0 0" "$AUTH_LOG" || fail 'temporary session/rate policy was not passed to ndsctl auth'
pass 'known approved guest without a package is preemptively authenticated at the configured holding speed'

# A manually created account with a still-pending portal request must wait for
# approval; once the same request is approved, the watcher may apply the hold.
reset_run
RID="REQ-$NOW-1234"
TOKEN="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
mkdir -p "$T/requests/metadata"
printf '%s\t%s\t%s\t%s\t%s\t%s\t1440\t0\t0\t0\t0\tPENDING\n' \
  "$RID" "$NOW" "$TOKEN" 'Pending Guest' 0771234567 dGVzdA== > "$T/requests/pending.tsv"
printf '%s\t%s\t%s\t%s\n' "$MAC" "$IP" 'test-browser' 'test-hid' > "$T/requests/metadata/$RID.tsv"
run_worker
[ ! -s "$AUTH_LOG" ] || fail 'known account with a pending request was authenticated before administrator approval'
pass 'a guest with a pending manual request is not preemptively authenticated before approval'
awk -F '\t' -v OFS='\t' -v id="$RID" '$1==id {$12="APPROVED"} {print}' \
  "$T/requests/pending.tsv" > "$T/requests/pending.new" && mv "$T/requests/pending.new" "$T/requests/pending.tsv"
run_worker
[ "$(cat "$STATE_FILE")" = Authenticated ] || fail 'approved request without a package was not preemptively authenticated'
[ -s "$AUTH_LOG" ] || fail 'approved request without a package did not receive temporary policy'
pass 'once approved, an unassigned guest is preemptively authenticated under the temporary access policy'

# Active assigned package uses the package manager's normal quota/rate logic.
reset_run
printf '%s\t7\t%s\t%s\t96\t384\tone_time\t0\tactive\t32\t64\tthrottle\n' "$MAC" "$NOW" "$((NOW+86400))" > "$T/packages.tsv"
run_worker
[ "$(cat "$STATE_FILE")" = Authenticated ] || fail 'active package guest was not preemptively authenticated'
grep -q "$MAC" "$AUTH_LOG" || fail 'package auth did not reach ndsctl'
grep -q '96 384' "$AUTH_LOG" || fail 'package upload/download rates were not applied'
pass 'active package is applied during preemptive reconnect with its package speeds and quota guard'

# Expired and pending package rows never fall back to the unassigned hold policy.
reset_run
printf '%s\t7\t%s\t%s\t96\t384\tone_time\t0\tactive\t32\t64\tthrottle\n' "$MAC" "$((NOW-86400))" "$((NOW-1))" > "$T/packages.tsv"
run_worker
[ ! -s "$AUTH_LOG" ] && [ ! -s "$STATE_FILE" ] || fail 'expired package received preemptive access'
pass 'expired package is not preemptively authenticated and never falls back to unassigned access'
reset_run
printf '%s\t7\t%s\t%s\t96\t384\tone_time\t0\tpending\t32\t64\tthrottle\n' "$MAC" "$NOW" "$((NOW+86400))" > "$T/packages.tsv"
run_worker
[ ! -s "$AUTH_LOG" ] || fail 'pending package received preemptive access'
pass 'pending package stays unauthenticated during preemptive reconnect'

# Disabled accounts and Block mode remain denied.
reset_run
awk -F '\t' -v OFS='\t' '{$8="disabled";print}' "$T/accounts.tsv" > "$T/accounts.new"; mv "$T/accounts.new" "$T/accounts.tsv"
run_worker
[ ! -s "$AUTH_LOG" ] || fail 'disabled account received preemptive access'
pass 'disabled account is never preemptively authenticated'
reset_run
awk -F '\t' -v OFS='\t' '{$8="active";print}' "$T/accounts.tsv" > "$T/accounts.new"; mv "$T/accounts.new" "$T/accounts.tsv"
sed -i 's/^UNASSIGNED_ACCESS_MODE=.*/UNASSIGNED_ACCESS_MODE=block/' "$T/policy.conf"
run_worker
[ ! -s "$AUTH_LOG" ] || fail 'Block mode authenticated unassigned guest'
pass 'unassigned Block mode remains blocked during preemptive reconnect'

# Unknown MAC is untouched with enrollment off; with it on a lease-matched
# account is created and immediately receives the configured temporary policy.
reset_run
UNKNOWN=02:00:00:00:ee:02
NEIGH_MAC="$UNKNOWN"; export NEIGH_MAC
printf '%s %s %s new-device 01:02:03:04:05:07\n' "$((NOW+3600))" "$UNKNOWN" "$IP" > "$T/dhcp.leases"
run_worker
[ -z "$(awk -F '\t' -v m="$UNKNOWN" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'unknown device was enrolled while policy was off'
[ ! -s "$AUTH_LOG" ] || fail 'unknown device was authenticated while enrollment was off'
pass 'unknown MAC is not enrolled or authenticated when automatic enrollment is OFF'
reset_run
NEIGH_MAC="$UNKNOWN"; export NEIGH_MAC
sed -i 's/^MAC_AUTO_ENROLL=.*/MAC_AUTO_ENROLL=1/' "$T/policy.conf"
run_worker
ROW="$(awk -F '\t' -v m="$UNKNOWN" '$1==m {print;exit}' "$T/accounts.tsv")"
[ -n "$ROW" ] || fail 'MAC auto-enrollment did not create a guest account'
[ "$(printf '%s\n' "$ROW" | cut -f2)" = '-' ] || fail 'MAC enrollment invented guest phone details'
[ "$(cat "$STATE_FILE")" = Authenticated ] || fail 'auto-enrolled device did not receive temporary preemptive access'
pass 'enabled MAC enrollment creates a lease-matched account without fake details and applies temporary access'

# A manual disconnect/deletion tombstone prevents the background watcher
# from undoing an explicit administrator action, and can be cleared only by
# an explicit administrator approval/package action.
reset_run
NEIGH_MAC="$MAC"; export NEIGH_MAC
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/packages.tsv"
( . "$T/policy-lib.sh"; policy_return_auth_mark_denied "$MAC" manual_disconnect ) || fail 'could not write manual return deny marker'
run_worker
[ ! -s "$AUTH_LOG" ] || fail 'manually denied returning device was automatically authenticated'
( . "$T/policy-lib.sh"; policy_return_auth_clear_denied "$MAC" ) || fail 'could not clear manual return deny marker'
run_worker
[ "$(cat "$STATE_FILE")" = Authenticated ] || fail 'device did not authenticate after administrator cleared the deny marker'
pass 'administrator disconnect suppression prevents automatic reauthentication and explicit admin release restores it'


# Rejecting a request must leave a persistent return-auth denial so an existing
# quota account cannot be mistaken for an approved unassigned guest later.
reset_run
REJECT_ID="REQ-$((NOW+1))-9999"
REJECT_TOKEN="abcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcd"
printf '%s\t%s\t%s\t%s\t%s\t%s\t1440\t0\t0\t0\t0\tPENDING\n' \
  "$REJECT_ID" "$NOW" "$REJECT_TOKEN" 'Rejected Guest' 0771234567 dGVzdA== > "$T/requests/pending.tsv"
printf '%s\t%s\t%s\t%s\n' "$MAC" "$IP" 'test-browser' 'test-hid' > "$T/requests/metadata/$REJECT_ID.tsv"
: > "$STATE_FILE"  # rejection must also work after the guest has gone offline
QUOTA_DIR="$T" REQUEST_MANAGER_DIR="$T/requests" \
  "$T/requests/live-manager.sh" reject "$REJECT_ID" >/dev/null || fail 'request rejection failed'
[ -n "$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$T/return-auth-deny.tsv")" ] || fail 'reject action did not create a return-auth deny marker'
: > "$AUTH_LOG"
: > "$T/attempts.tsv"
run_worker
[ ! -s "$AUTH_LOG" ] || fail 'rejected guest was preemptively authenticated on reconnect'
pass 'manually rejected requests remain blocked from preemptive reconnect even when an account row exists'

# A stale/wrong interface neighbour must be rejected even if the MAC matches.
reset_run
NEIGH_IFACE=br-lan; export NEIGH_IFACE
if QUOTA_DIR="$T" REQUEST_MANAGER_DIR="$T/requests" "$T/requests/live-manager.sh" resume-preemptive "$MAC" "$IP" br-lan >/dev/null 2>&1; then
  fail 'preemptive manager accepted a non-openNDS managed interface'
fi
[ ! -s "$AUTH_LOG" ] || fail 'wrong interface caused authentication'
pass 'preemptive authentication refuses a neighbour outside the openNDS managed guest interface'

echo "ALL $PASS PREEMPTIVE RETURNING-DEVICE CHECKS PASSED"
