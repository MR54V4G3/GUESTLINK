#!/bin/sh
# Isolated tests for approved-device deletion and the Requests dashboard button.
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
PKG_ROOT="$(CDPATH= cd -- "$HERE/../.." && pwd)"
REQ_ROOT="$PKG_ROOT/root/guest-portal-requests"
DASH_ROOT="$PKG_ROOT/srv/guest-dashboard/cgi-bin"
T="$(mktemp -d /tmp/guest-delete-device.XXXXXX)"
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin" "$T/requests/metadata" "$T/cgi"
cp "$HERE/policy-lib.sh" "$T/policy-lib.sh"
cp "$REQ_ROOT/live-manager.sh" "$T/requests/live-manager.sh"
cp "$DASH_ROOT/requests" "$T/cgi/requests"
chmod 700 "$T/requests/live-manager.sh" "$T/cgi/requests"
cat > "$T/policy.conf" <<'POLICY'
DEFAULT_DOWNLOAD_MIB=1024
DEFAULT_UPLOAD_MIB=256
DEFAULT_VALIDITY_DAYS=7
DEFAULT_UPLOAD_KBPS=64
DEFAULT_DOWNLOAD_KBPS=512
DEFAULT_FREE_ENABLED=0
FREE_WINDOW_START=00:00
FREE_WINDOW_END=07:00
DEFAULT_RENEWAL_MODE=one_time
EXPIRED_ACCOUNT_ACTION=block_until_renewed
AUTO_APPROVE_REQUESTS=1
AUTO_AUTHENTICATE=1
UNASSIGNED_ACCESS_MODE=throttle
UNASSIGNED_RATE_KBPS=1
UNASSIGNED_SESSION_MINUTES=1440
PACKAGE_ACTIVATION_MODE=immediate
DEFAULT_AFTER_UPLOAD_KBPS=32
DEFAULT_AFTER_DOWNLOAD_KBPS=64
DEFAULT_AFTER_QUOTA_ACTION=throttle
POLICY

MAC=02:00:00:00:dd:01
OTHER=02:00:00:00:dd:02
NO_PACKAGE=02:00:00:00:dd:03
LEGACY_BLOCK=02:00:00:00:dd:04
THIRD=02:00:00:00:dd:05
ID1=REQ-1790000000-1
ID2=REQ-1790000001-2
ID3=REQ-1790000002-3
ID4=REQ-1790000003-4
ID5=REQ-1790000004-5
TOKEN1=$(printf '%064d' 1 | tr '0' 'a')
TOKEN2=$(printf '%064d' 2 | tr '0' 'b')
TOKEN3=$(printf '%064d' 3 | tr '0' 'c')
TOKEN4=$(printf '%064d' 4 | tr '0' 'd')
TOKEN5=$(printf '%064d' 5 | tr '0' 'e')

printf '%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tAPPROVED\n%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tREJECTED\n%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tAPPROVED\n%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tAPPROVED\n%s\t%s\t%s\t%s\t%s\t%s\t0\t0\t0\t0\t0\tAPPROVED\n' \
    "$ID1" 1790000000 "$TOKEN1" 'Guest One' 0771111001 dGVzdA== \
    "$ID2" 1790000001 "$TOKEN2" 'Guest One Old' 0771111001 dGVzdA== \
    "$ID3" 1790000002 "$TOKEN3" 'Other Guest' 0771111002 dGVzdA== \
    "$ID4" 1790000003 "$TOKEN4" 'Approved No Package' 0771111003 dGVzdA== \
    "$ID5" 1790000004 "$TOKEN5" 'Approved No Package Old' 0771111003 dGVzdA== > "$T/requests/pending.tsv"
printf '%s\t172.16.42.10\tTest Android\n' "$MAC" > "$T/requests/metadata/$ID1.tsv"
printf '%s\t172.16.42.10\tOlder device record\n' "$MAC" > "$T/requests/metadata/$ID2.tsv"
printf '%s\t172.16.42.11\tOther device\n' "$OTHER" > "$T/requests/metadata/$ID3.tsv"
printf '%s\t172.16.42.12\tApproved No Package\n' "$NO_PACKAGE" > "$T/requests/metadata/$ID4.tsv"
printf '%s\t172.16.42.12\tOlder approved no-package request\n' "$NO_PACKAGE" > "$T/requests/metadata/$ID5.tsv"
printf '%s\t0771111001\t102400\t51200\t1000\t2000\t2026-11-01\tactive\t0\t-\t10\t20\n%s\t0771111002\t102400\t51200\t3000\t4000\t2026-11-01\tactive\t0\t-\t30\t40\n' "$MAC" "$OTHER" > "$T/accounts.tsv"
printf '%s\t0771111003\t102400\t51200\t0\t0\t2026-11-01\tactive\t0\t-\t0\t0\n' "$NO_PACKAGE" >> "$T/accounts.tsv"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/packages.tsv"
printf '%s\t30\t1790000000\t1792592000\t64\t512\tone_time\t0\tactive\t32\t64\tdisconnect\n%s\t30\t1790000000\t1792592000\t64\t512\tone_time\t0\tactive\t32\t64\tdisconnect\n' "$MAC" "$OTHER" >> "$T/packages.tsv"
printf '2026-11-01\t%s\t111\t222\n2026-11-01\t%s\t333\t444\n' "$MAC" "$OTHER" > "$T/daily-usage.tsv"
printf '%s\t1790000000\t1000\t2000\t1790000060\n%s\t1790000001\t3000\t4000\t1790000060\n' "$MAC" "$OTHER" > "$T/session-state.tsv"
printf '1790000100\t%s\t1000\t2000\t1790000000\tdeauth\n1790000100\t%s\t3000\t4000\t1790000001\tdeauth\n' "$MAC" "$OTHER" > "$T/session-events.tsv"
printf '2026-11-01 10:00:00 +0530\t%s\tGuest One\t0771111001\tAPPROVED\n2026-11-01 10:01:00 +0530\t%s\tGuest One Old\t0771111001\tREJECTED\n2026-11-01 10:02:00 +0530\t%s\tOther Guest\t0771111002\tAPPROVED\n' "$ID1" "$ID2" "$ID3" > "$T/requests/history.tsv"
printf '%s\t1790000200\tmanual_disconnect\n%s\t1790000201\tlegacy_deleted_guest\n' "$MAC" "$LEGACY_BLOCK" > "$T/return-auth-deny.tsv"

cat > "$T/bin/ndsctl" <<'MOCK_NDS'
#!/bin/sh
case "$1" in
    json) printf '{"mac":"%s","state":"%s"}\n' "$2" "${NDS_STATE:-Authenticated}" ;;
    deauth)
        [ "${NDS_STATE:-Authenticated}" = Authenticated ] || { echo 'ndsctl deauth only accepts currently authenticated clients' >&2; exit 1; }
        [ "${NDS_DEAUTH_FAIL:-0}" = 1 ] && { echo 'mock deauth permission denied' >&2; exit 6; }
        printf '%s\n' "$2" >> "$NDS_DEAUTH_LOG"
        echo deauthenticated.
        ;;
    *) exit 2 ;;
esac
MOCK_NDS
cat > "$T/bin/jsonfilter" <<'MOCK_JSON'
#!/bin/sh
case "$*" in
    *'@.mac'*) sed -n 's/.*"mac":"\([^"]*\)".*/\1/p' ;;
    *'@.state'*) sed -n 's/.*"state":"\([^"]*\)".*/\1/p' ;;
    *) exit 1 ;;
esac
MOCK_JSON
cat > "$T/bin/logger" <<'MOCK_LOGGER'
#!/bin/sh
exit 0
MOCK_LOGGER
cat > "$T/package-shaper.sh" <<'MOCK_SHAPER'
#!/bin/sh
[ "$1" = clear ] || exit 2
printf '%s\n' "$*" >> "$SHAPER_LOG"
exit 0
MOCK_SHAPER
cat > "$T/allow-client.sh" <<'ALLOW'
#!/bin/sh
[ "${REMOTE_ADDR:-}" = 192.168.2.55 ]
ALLOW
chmod 700 "$T/bin/"* "$T/package-shaper.sh" "$T/allow-client.sh"

printf '%s\t%s\n%s\t%s\n%s\t%s\n' 1790000200 "$MAC" 1790000201 "$OTHER" 1790000202 "$THIRD" > "$T/attempts.tsv"
export PATH="$T/bin:$PATH" QUOTA_DIR="$T" REQUEST_MANAGER_DIR="$T/requests" \
    REQUEST_MANAGER_QUEUE="$T/requests/pending.tsv" NDS_DEAUTH_LOG="$T/deauth.log" \
    SHAPER_LOG="$T/shaper.log" QUOTA_CGI_ALLOW="$T/allow-client.sh" \
    REQUEST_MANAGER="$T/requests/live-manager.sh" RETURN_AUTH_ATTEMPTS="$T/attempts.tsv"
: > "$T/deauth.log"

pass_count=0
fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; pass_count=$((pass_count+1)); }

# Verify the dashboard presents an explicit destructive action only on the
# approved-request card and ties it to both request ID and MAC.
UI_OUT=$(REQUEST_METHOD=GET REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_OUT" | grep -Fq 'Permanently delete portal records' || fail 'approved request card has no delete button'
printf '%s' "$UI_OUT" | grep -Fq 'Revoke access — keep history' || fail 'approved request card has no preserve-history revoke button'
printf '%s' "$UI_OUT" | grep -Fq 'PERMANENTLY forget this guest from the portal' || fail 'delete button lacks an irreversible-action confirmation'
printf '%s' "$UI_OUT" | grep -Fq "name=\"id\" value=\"$ID1\"" || fail 'delete form is not tied to approved request ID'
printf '%s' "$UI_OUT" | grep -Fq "name=\"mac\" value=\"$MAC\"" || fail 'delete form is not tied to the device MAC'
pass 'Approved tab renders a confirmed delete action tied to the approved request and verified MAC'
# Approved requests without packages must remain visible and deletable.
printf '%s' "$UI_OUT" | grep -Fq "name=\"id\" value=\"$ID4\"" || fail 'approved request without a package disappeared from the Approved list'
printf '%s' "$UI_OUT" | grep -Fq 'Approved No Package' || fail 'approved no-package guest identity is not rendered'
printf '%s' "$UI_OUT" | grep -Fq "name=\"mac\" value=\"$NO_PACKAGE\"" || fail 'approved no-package guest has no delete action'
pass 'approved guests without packages remain in the Approved list with a working delete action'
printf '%s' "$UI_OUT" | grep -Fq 'data-tab="blocked">Blocked' || fail 'Requests dashboard has no Blocked Devices tab'
printf '%s' "$UI_OUT" | grep -Fq 'Administrator-blocked devices' || fail 'Blocked Devices panel is missing'
printf '%s' "$UI_OUT" | grep -Fq 'manual_disconnect' || fail 'Blocked Devices panel does not show the administrator block reason'
printf '%s' "$UI_OUT" | grep -Fq 'Clear block / allow saved account' || fail 'Blocked Devices panel has no clear-block action'
printf '%s' "$UI_OUT" | grep -Fq 'Permanently forget device &amp; clear block' || fail 'Blocked Devices panel has no complete-forget action'
pass 'Blocked Devices tab lists portal blocks with clear and complete-forget controls'

# A request ID cannot be used to delete a different device.
if "$T/requests/live-manager.sh" delete-device "$ID1" "$OTHER" >/dev/null 2>&1; then
    fail 'delete accepted an unrelated MAC'
fi
[ -f "$T/accounts.tsv" ] && [ -f "$T/packages.tsv" ] || fail 'failed MAC verification changed accounting files'
pass 'delete refuses a mismatched MAC without changing records'

# A non-approved request cannot be used as the deletion anchor.
if "$T/requests/live-manager.sh" delete-device "$ID2" "$MAC" >/dev/null 2>&1; then
    fail 'delete accepted a rejected request'
fi
pass 'delete refuses a non-approved request'

# Revoke preserves account/package/usage data and moves approved requests to REVOKED.
if ! NDS_STATE=Preauthenticated "$T/requests/live-manager.sh" revoke-device "$ID1" "$MAC" >"$T/revoke.out" 2>&1; then
    cat "$T/revoke.out" >&2; fail 'revoke-device operation failed'
fi
[ "$(awk -F '\t' -v id="$ID1" '$1==id {print $12}' "$T/requests/pending.tsv")" = REVOKED ] || fail 'approved request was not marked REVOKED'
[ "$(awk -F '\t' -v id="$ID2" '$1==id {print $12}' "$T/requests/pending.tsv")" = REJECTED ] || fail 'revoke changed an already rejected request'
[ -n "$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'revoke removed the account'
[ -n "$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$T/packages.tsv")" ] || fail 'revoke removed the package'
[ -n "$(awk -F '\t' -v m="$MAC" '$2==m {print;exit}' "$T/daily-usage.tsv")" ] || fail 'revoke removed quota usage'
grep -Fq "$MAC" "$T/return-auth-deny.tsv" || fail 'revoke did not block automatic return authentication'
grep -Fq 'ACCESS_REVOKED' "$T/requests/history.tsv" || fail 'revoke event was not recorded in portal history'
! grep -Fxq "$MAC" "$T/deauth.log" || fail 'revoke incorrectly called ndsctl deauth for an already-preauthenticated device'
pass 'revoke marks approval REVOKED and preserves account, package, usage and history; preauthenticated clients are not deauthed again' 
if "$T/requests/live-manager.sh" clear-return-block "$MAC" >/dev/null 2>&1; then
    fail 'clear-return-block bypassed a REVOKED request instead of requiring Restore approval'
fi
pass 'generic block clearing refuses to bypass linked revoked approvals'

if ! "$T/requests/live-manager.sh" restore-device "$ID1" "$MAC" >"$T/restore.out" 2>&1; then
    cat "$T/restore.out" >&2; fail 'restore-device operation failed'
fi
[ "$(awk -F '\t' -v id="$ID1" '$1==id {print $12}' "$T/requests/pending.tsv")" = APPROVED ] || fail 'request was not restored to APPROVED'
! grep -Fq "$MAC" "$T/return-auth-deny.tsv" || fail 'restore did not clear the portal return-auth block'
grep -Fq 'ACCESS_RESTORED' "$T/requests/history.tsv" || fail 'restore event was not recorded in portal history'
pass 'restore clears only the portal block and restores approval without resetting guest data'

# Exercise revoke and restore via the browser form submission route.
MAC_URL=$(printf '%s' "$MAC" | sed 's/:/%3A/g')
BODY="action=revoke_device&id=$ID1&mac=$MAC_URL"
UI_REVOKE=$(printf '%s' "$BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" \
    REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_REVOKE" | grep -Fq 'Revoked access for' || fail 'Requests CGI did not invoke revoke-device'
[ "$(awk -F '\t' -v id="$ID1" '$1==id {print $12}' "$T/requests/pending.tsv")" = REVOKED ] || fail 'dashboard revoke did not mark the request REVOKED'
pass 'Approved dashboard form invokes preserve-history revocation'
BODY="action=restore_device&id=$ID1&mac=$MAC_URL"
UI_RESTORE=$(printf '%s' "$BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" \
    REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_RESTORE" | grep -Fq 'Restored approval for' || fail 'Requests CGI did not invoke restore-device'
[ "$(awk -F '\t' -v id="$ID1" '$1==id {print $12}' "$T/requests/pending.tsv")" = APPROVED ] || fail 'dashboard restore did not return the request to APPROVED'
pass 'Approved dashboard form invokes approval restoration'

# Browser form submissions URL-encode colons in MAC addresses as %3A.
# Exercise both Disconnect and permanent deletion through that real form path.
OTHER_URL=$(printf '%s' "$OTHER" | sed 's/:/%3A/g')
BODY="action=disconnect&mac=$OTHER_URL"
UI_DISCONNECT=$(printf '%s' "$BODY" | NDS_STATE=Preauthenticated REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" \
    REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_DISCONNECT" | grep -Fq 'Guest device disconnected. Automatic returning-device authentication is suppressed' || fail 'Requests CGI did not decode the browser-encoded MAC for disconnect'
! grep -Fxq "$OTHER" "$T/deauth.log" || fail 'browser-encoded disconnect unnecessarily called deauth for a preauthenticated device'
grep -Fq "$OTHER" "$T/return-auth-deny.tsv" || fail 'manual disconnect did not suppress background reauthentication'
[ -n "$(awk -F '\t' -v m="$OTHER" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'disconnect unexpectedly removed the account'
pass 'Disconnect CGI URL-decodes MAC addresses, accepts an already-preauthenticated client without a redundant deauth, and suppresses automatic reconnection'
BODY="action=clear_block&mac=$OTHER_URL&confirm=yes"
UI_CLEAR=$(printf '%s' "$BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" \
    REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_CLEAR" | grep -Fq 'Cleared the OpenNDS portal block' || fail 'Blocked tab clear action did not clear the marker'
! grep -Fq "$OTHER" "$T/return-auth-deny.tsv" || fail 'clear-block left the administrator marker in place'
[ -n "$(awk -F '\t' -v m="$OTHER" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'clear-block removed the saved account'
[ -z "$(awk -F '\t' -v m="$OTHER" '$2==m {print;exit}' "$T/attempts.tsv")" ] || fail 'clear-block left its retry-cache entry'
pass 'dashboard clear-block removes only portal block/cache while preserving account data'

MAC_URL=$(printf '%s' "$MAC" | sed 's/:/%3A/g')
BODY="action=delete_device&id=$ID1&mac=$MAC_URL"
UI_UNCONFIRMED=$(printf '%s' "$BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" \
    REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_UNCONFIRMED" | grep -Fq 'Permanent deletion was not confirmed' || fail 'Requests CGI did not enforce server-side delete confirmation'
[ -n "$(awk -F "$(printf '\t')" -v m="$MAC" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'unconfirmed delete changed account records'
pass 'permanent deletion requires server-side POST confirmation'
BODY="action=delete_device&id=$ID1&mac=$MAC_URL&confirm=yes"
UI_POST=$(printf '%s' "$BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" \
    REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_POST" | grep -Fq "Permanently forgot guest $MAC" || fail 'Requests CGI did not report successful deletion'
grep -Fxq "$MAC" "$T/deauth.log" || fail 'active device was not deauthenticated before deletion'
grep -q '^clear ' "$T/shaper.log" || fail 'device-specific package-shaper entry was not cleared'
! grep -Fq "$MAC" "$T/return-auth-deny.tsv" || fail 'permanent deletion left an administrator block marker behind'
pass 'delete action disconnects the device, clears its SQM entry and removes the portal admin block'
[ -z "$(awk -F '\t' -v m="$MAC" '$2==m {print;exit}' "$T/attempts.tsv")" ] || fail 'complete portal deletion retained its returning-auth attempt-cache entry'
[ -n "$(awk -F '\t' -v m="$THIRD" '$2==m {print;exit}' "$T/attempts.tsv")" ] || fail 'complete portal deletion changed another device cache entry'
pass 'complete portal deletion clears only that MAC from the portal-owned retry cache'

for file in accounts.tsv packages.tsv daily-usage.tsv session-state.tsv session-events.tsv; do
    [ -f "$T/$file" ] || continue
    field=1
    case "$file" in daily-usage.tsv|session-events.tsv) field=2 ;; esac
    awk -F '\t' -v m="$MAC" -v f="$field" '$f==m {found=1} END {exit !found}' "$T/$file" && fail "$file still contains deleted device records"
done
[ -n "$(awk -F '\t' -v m="$OTHER" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'unrelated account was deleted'
[ -n "$(awk -F '\t' -v m="$OTHER" '$1==m {print;exit}' "$T/packages.tsv")" ] || fail 'unrelated package was deleted'
[ -n "$(awk -F '\t' -v m="$OTHER" '$2==m {print;exit}' "$T/daily-usage.tsv")" ] || fail 'unrelated daily usage was deleted'
pass 'delete removes the guest account, package, quota usage, session state and session events while preserving unrelated guests'

[ -z "$(awk -F '\t' -v id="$ID1" '$1==id {print;exit}' "$T/requests/pending.tsv")" ] || fail 'approved request row remains'
[ -z "$(awk -F '\t' -v id="$ID2" '$1==id {print;exit}' "$T/requests/pending.tsv")" ] || fail 'older request row for same MAC remains'
[ -z "$(awk -F '\t' -v id="$ID1" '$2==id {print;exit}' "$T/requests/history.tsv")" ] || fail 'linked decision history remains'
[ -z "$(awk -F '\t' -v id="$ID2" '$2==id {print;exit}' "$T/requests/history.tsv")" ] || fail 'older linked decision history remains'
[ ! -e "$T/requests/metadata/$ID1.tsv" ] && [ ! -e "$T/requests/metadata/$ID2.tsv" ] || fail 'linked device metadata remains'
[ -e "$T/requests/metadata/$ID3.tsv" ] || fail 'unrelated device metadata was deleted'
[ -n "$(awk -F '\t' -v id="$ID3" '$1==id {print;exit}' "$T/requests/pending.tsv")" ] || fail 'unrelated request row was deleted'
pass 'delete removes all request records and linked history for that MAC while preserving other approved guests'

# A legacy block can survive old dashboard versions after its request metadata
# is gone. MAC-only forget must still clear the marker and portal retry cache.
if ! NDS_STATE=Preauthenticated "$T/requests/live-manager.sh" forget-device "$LEGACY_BLOCK" >"$T/forget.out" 2>&1; then
    cat "$T/forget.out" >&2; fail 'MAC-only forget failed for a legacy block'
fi
! grep -Fq "$LEGACY_BLOCK" "$T/return-auth-deny.tsv" || fail 'MAC-only forget left the legacy administrator block'
[ -z "$(awk -F '\t' -v m="$LEGACY_BLOCK" '$2==m {print;exit}' "$T/attempts.tsv")" ] || fail 'MAC-only forget left the portal retry-cache record'
! grep -Fxq "$LEGACY_BLOCK" "$T/deauth.log" || fail 'MAC-only forget incorrectly called deauth for a preauthenticated device'
pass 'MAC-only permanent forget clears a legacy block without calling unsupported deauth for a preauthenticated client' 

# Exercise the real dashboard POST handler and server-side confirmation gate.
LEGACY_URL=$(printf '%s' "$LEGACY_BLOCK" | sed 's/:/%3A/g')
BODY="action=forget_device&mac=$LEGACY_URL&confirm=yes"
UI_FORGET=$(printf '%s' "$BODY" | REQUEST_METHOD=POST CONTENT_LENGTH="${#BODY}" \
    REMOTE_ADDR=192.168.2.55 /bin/sh "$T/cgi/requests")
printf '%s' "$UI_FORGET" | grep -Fq 'Permanently forgot guest' || fail 'Blocked tab forget action did not invoke complete portal deletion'
pass 'Blocked Devices dashboard permanently forgets a MAC through the protected POST action'


# A normal approved-request delete must also succeed for an already-preauthenticated client.
PREAUTH_DELETE=02:00:00:00:dd:06
ID6=REQ-1790000006-6
TOKEN6=$(printf '%064d' 6 | tr '0' 'f')
printf '%s\t1790000006\t%s\tPreauth Delete Guest\t0771111006\tdGVzdA==\t0\t0\t0\t0\t0\tAPPROVED\n' "$ID6" "$TOKEN6" >> "$T/requests/pending.tsv"
printf '%s\t172.16.42.16\tPreauthenticated delete test\n' "$PREAUTH_DELETE" > "$T/requests/metadata/$ID6.tsv"
printf '%s\t0771111006\t102400\t51200\t1000\t2000\t2026-11-01\tactive\t0\t-\t10\t20\n' "$PREAUTH_DELETE" >> "$T/accounts.tsv"
printf '%s\t30\t1790000000\t1792592000\t64\t512\tone_time\t0\tactive\t32\t64\tdisconnect\n' "$PREAUTH_DELETE" >> "$T/packages.tsv"
printf '2026-11-01\t%s\t111\t222\n' "$PREAUTH_DELETE" >> "$T/daily-usage.tsv"
printf '%s\t1790000000\t1000\t2000\t1790000060\n' "$PREAUTH_DELETE" >> "$T/session-state.tsv"
printf '1790000100\t%s\t1000\t2000\t1790000000\tdeauth\n' "$PREAUTH_DELETE" >> "$T/session-events.tsv"
printf '2026-11-01 10:06:00 +0530\t%s\tPreauth Delete Guest\t0771111006\tAPPROVED\n' "$ID6" >> "$T/requests/history.tsv"
: > "$T/deauth.log"
if ! NDS_STATE=Preauthenticated "$T/requests/live-manager.sh" delete-device "$ID6" "$PREAUTH_DELETE" >"$T/preauth-delete.out" 2>&1; then
    cat "$T/preauth-delete.out" >&2; fail 'approved-request deletion failed for a preauthenticated guest'
fi
! grep -Fxq "$PREAUTH_DELETE" "$T/deauth.log" || fail 'approved-request deletion called ndsctl deauth for a preauthenticated guest'
! grep -Fq "$PREAUTH_DELETE" "$T/return-auth-deny.tsv" || fail 'approved-request deletion left the portal block marker'
[ -z "$(awk -F '\t' -v m="$PREAUTH_DELETE" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'approved-request deletion kept the preauthenticated guest account'
pass 'approved-request permanent deletion safely completes for a Preauthenticated client without calling ndsctl deauth'


# If a genuinely authenticated client cannot be deauthenticated, permanent
# deletion must fail closed and retain the deleted_guest marker for safety.
DEAUTH_FAIL_MAC=02:00:00:00:dd:07
ID7=REQ-1790000007-7
TOKEN7=$(printf '%064d' 7 | tr '0' '7')
printf '%s\t1790000007\t%s\tDeauth Failure Guest\t0771111007\tdGVzdA==\t0\t0\t0\t0\t0\tAPPROVED\n' "$ID7" "$TOKEN7" >> "$T/requests/pending.tsv"
printf '%s\t172.16.42.17\tAuthenticated delete failure test\n' "$DEAUTH_FAIL_MAC" > "$T/requests/metadata/$ID7.tsv"
printf '%s\t0771111007\t102400\t51200\t1000\t2000\t2026-11-01\tactive\t0\t-\t10\t20\n' "$DEAUTH_FAIL_MAC" >> "$T/accounts.tsv"
printf '%s\t30\t1790000000\t1792592000\t64\t512\tone_time\t0\tactive\t32\t64\tdisconnect\n' "$DEAUTH_FAIL_MAC" >> "$T/packages.tsv"
if NDS_DEAUTH_FAIL=1 "$T/requests/live-manager.sh" delete-device "$ID7" "$DEAUTH_FAIL_MAC" >"$T/deauth-fail.out" 2>&1; then
    fail 'permanent deletion continued after an authenticated-client deauth failure'
fi
grep -Fq 'mock deauth permission denied' "$T/deauth-fail.out" || fail 'delete error hid the actual ndsctl deauth failure detail'
[ -n "$(awk -F '\t' -v m="$DEAUTH_FAIL_MAC" '$1==m {print;exit}' "$T/accounts.tsv")" ] || fail 'failed authenticated deauth still deleted the guest account'
grep -Fq "$DEAUTH_FAIL_MAC" "$T/return-auth-deny.tsv" || fail 'failed authenticated deauth did not retain a safety block'
pass 'authenticated-client deauth failures remain fail-closed, preserve account records, retain the block, and report the underlying error'

# The captive portal must show the deliberate admin-block explanation instead
# of the generic saved-account policy failure message.
grep -Fq '*RETURN_ADMIN_BLOCKED*)' "$PKG_ROOT/usr/lib/opennds/theme_guest-approval-requests.sh" || fail 'openNDS theme has no RETURN_ADMIN_BLOCKED case'
grep -Fq 'Access temporarily disabled' "$PKG_ROOT/usr/lib/opennds/theme_guest-approval-requests.sh" || fail 'admin-block portal message is missing'
pass 'captive portal has a dedicated explanation for administrator-blocked devices'

echo "ALL $pass_count GUEST DELETION / BLOCK-MANAGEMENT CHECKS PASSED"
