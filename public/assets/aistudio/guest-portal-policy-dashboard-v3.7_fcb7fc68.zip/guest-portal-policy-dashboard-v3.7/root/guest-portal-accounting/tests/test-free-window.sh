#!/bin/sh
# Isolated functional tests for editable per-account free-window policy.
# All account data, OpenNDS commands and clocks are temporary/mocked.
set -eu

HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SOURCE_QM="$HERE/quota-manager.sh"
SOURCE_PM="$HERE/package-manager.sh"
SOURCE_POLL="$HERE/poll-accounting.sh"
SOURCE_ENF="$HERE/free-enforcer.sh"
SOURCE_POLICY="$HERE/policy-lib.sh"
SOURCE_SHAPER="$HERE/package-shaper.sh"

for f in "$SOURCE_QM" "$SOURCE_PM" "$SOURCE_POLL" "$SOURCE_ENF" "$SOURCE_POLICY" "$SOURCE_SHAPER"; do
    [ -f "$f" ] || { echo "Missing source file: $f" >&2; exit 1; }
    /bin/sh -n "$f" || { echo "Syntax error: $f" >&2; exit 1; }
done

T=$(mktemp -d /tmp/guest-free-window-test.XXXXXX) || exit 1
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin"
cp "$SOURCE_QM" "$SOURCE_PM" "$SOURCE_POLL" "$SOURCE_POLICY" "$SOURCE_SHAPER" "$HERE/session-policy.sh" "$T/"
cp "$HERE/policy.conf.example" "$T/policy.conf"
cp "$SOURCE_ENF" "$T/free-enforcer.orig"
chmod 700 "$T"/*.sh
: > "$T/accounting.lock"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/packages.tsv"
chmod 600 "$T/packages.tsv"

# Test-only clock and Colombo UTC+05:30 offset wrapper for policy calculations.
cat > "$T/bin/date" <<'MOCK_DATE'
#!/bin/sh
case "$1" in
    +%H%M) if [ -n "${TEST_CLOCK:-}" ]; then printf '%s\n' "$(printf '%s' "$TEST_CLOCK" | cut -c1-4)"; else exec /bin/date +%H%M; fi ;;
    +%z) printf '%s\n' +0530 ;;
    *) exec /bin/date "$@" ;;
esac
MOCK_DATE

# A harmless OpenNDS mock: auth and deauth are logged, never sent to a router.
cat > "$T/bin/tc" <<'MOCK_TC'
#!/bin/sh
case "$1:$2:$4" in
  qdisc:show:br-guest) echo 'qdisc htb 1: root refcnt 2' ;;
  class:show:br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit' ;;
  qdisc:show:ifb4br-guest) echo 'qdisc htb 1: root refcnt 2' ;;
  class:show:ifb4br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit'; echo 'class htb 1:10 parent 1:1 rate 10Mbit ceil 10Mbit' ;;
  filter:show:br-guest) case "$*" in *ingress*) echo 'mirred redirect to ifb4br-guest' ;; esac ;;
esac
exit 0
MOCK_TC
cat > "$T/bin/ndsctl" <<'MOCK_NDS'
#!/bin/sh
case "$1" in
    json)
        printf '{"mac":"%s","state":"%s"}\n' "$2" "${NDS_STATE:-Authenticated}"
        ;;
    auth)
        printf '%s\n' "$*" >> "$NDS_AUTH_LOG"
        echo 'authenticated.'
        ;;
    deauth)
        printf '%s\n' "$2" >> "$NDS_DEAUTH_LOG"
        echo 'deauthenticated.'
        ;;
    *) exit 2 ;;
esac
MOCK_NDS
cat > "$T/bin/jsonfilter" <<'MOCK_JSONFILTER'
#!/bin/sh
case "$*" in
    *'@.mac'*) sed -n 's/.*"mac":"\([^"]*\)".*/\1/p' ;;
    *'@.state'*) sed -n 's/.*"state":"\([^"]*\)".*/\1/p' ;;
    *) exit 1 ;;
esac
MOCK_JSONFILTER
chmod 700 "$T/bin/"*
export PATH="$T/bin:$PATH"

PASS=0
fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; PASS=$((PASS+1)); }

QM="$T/quota-manager.sh"
PM="$T/package-manager.sh"
NOW=$(date +%s)
FUTURE=$((NOW+86400))
PAST=$((NOW-10))

# Derive Colombo midnight from UTC epoch arithmetic (UTC+05:30).
# This avoids requiring zoneinfo/tzdata on minimal OpenWrt BusyBox systems.
MID=$(((NOW + 19800) / 86400 * 86400 - 19800))
T01=$((MID+3600)); T02=$((MID+7200)); T06=$((MID+21600))
T08=$((MID+28800)); T09=$((MID+32400)); Y23=$((MID-3600))

account_case() {
    mac=$1 free=$2 start=$3 end=$4 expected=$5 label=$6
    QUOTA_DIR="$T" "$QM" add "$mac" - 100 100 >/dev/null
    printf '%s\t7\t1\t4102444800\t64\t512\tone_time\t%s\tactive\t64\t64\tdisconnect\n' \
        "$mac" "$free" >> "$T/packages.tsv"
    QUOTA_DIR="$T" "$QM" --locked sample "$mac" "$start" 0 0 "$start" "$start"
    QUOTA_DIR="$T" "$QM" --locked sample "$mac" "$start" 1000000 1000000 "$start" "$end"
    got=$(awk -F '\t' -v m="$mac" '$1==m {print $5 " " $6; exit}' "$T/accounts.tsv")
    [ "$got" = "$expected $expected" ] || fail "$label expected $expected/$expected bytes, got $got"
    pass "$label"
}

account_case 02:00:00:00:ff:11 1 "$T06" "$T08" 500000 '06:00–08:00 sample bills only non-free half'
account_case 02:00:00:00:ff:12 1 "$T01" "$T02" 0 '01:00–02:00 sample is fully free'
account_case 02:00:00:00:ff:13 1 "$T08" "$T09" 1000000 '08:00–09:00 sample is fully billable'
account_case 02:00:00:00:ff:14 1 "$Y23" "$T01" 500000 '23:00–01:00 midnight boundary is apportioned correctly'
account_case 02:00:00:00:ff:15 0 "$T01" "$T02" 1000000 'free setting OFF bills traffic during free hours'

# A Policy-page schedule crossing midnight must also be used by the accountant.
cat > "$T/policy.conf" <<'POLICY_TEST'
DEFAULT_DOWNLOAD_MIB=1024
DEFAULT_UPLOAD_MIB=256
DEFAULT_VALIDITY_DAYS=7
DEFAULT_UPLOAD_KBPS=64
DEFAULT_DOWNLOAD_KBPS=512
DEFAULT_FREE_ENABLED=0
FREE_WINDOW_START=22:00
FREE_WINDOW_END=06:00
DEFAULT_RENEWAL_MODE=one_time
EXPIRED_ACCOUNT_ACTION=block_until_renewed
POLICY_TEST
T21=$((MID+21*3600)); T23=$((MID+23*3600)); T03=$((MID+27*3600)); T06=$((MID+30*3600)); T07=$((MID+31*3600))
account_case 02:00:00:00:ff:16 1 "$T21" "$T07" 200000 'custom 22:00–06:00 window bills only the 2 daytime hours'
account_case 02:00:00:00:ff:17 1 "$T23" "$T03" 0 'custom overnight window treats 23:00–03:00 as free'
account_case 02:00:00:00:ff:18 1 "$T06" "$T07" 1000000 'custom overnight window ends exactly at 06:00'
# Restore the baseline policy used by the following auth/enforcer scenarios.
cp "$HERE/policy.conf.example" "$T/policy.conf"

# Package-manager prerequisite guard: it must not assign a free package unless
# both the poller and enforcer are installed and executable.
mkdir -p "$T/guard"
cp "$QM" "$T/guard/quota-manager.sh"
cp "$SOURCE_POLICY" "$T/guard/policy-lib.sh"
cp "$SOURCE_SHAPER" "$T/guard/package-shaper.sh"
cp "$HERE/policy.conf.example" "$T/guard/policy.conf"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/guard/packages.tsv"
cp "$PM" "$T/guard/package-manager.sh"
chmod 700 "$T/guard/"*.sh
if QUOTA_DIR="$T/guard" "$T/guard/package-manager.sh" assign 02:00:00:00:fa:01 0771234567 10 10 1 64 512 32 32 throttle one_time 1 >/dev/null 2>&1; then
    fail 'package manager allowed free window without poller/enforcer'
fi
[ ! -s "$T/guard/accounts.tsv" ] || fail 'failed free-package assignment created an account'
pass 'free-package assignment safely refuses missing poller/enforcer'

# Install the dependencies only inside the temporary directory, then verify
# the package manager stores independent per-account FREE_ENABLED values.
cp "$SOURCE_POLL" "$SOURCE_ENF" "$T/"
chmod 700 "$T/poll-accounting.sh" "$T/free-enforcer.sh"
NDS_STATE=Preauthenticated QUOTA_DIR="$T" "$PM" assign 02:00:00:00:fa:02 0771234568 10 10 1 64 512 32 32 disconnect one_time 1 >/dev/null
NDS_STATE=Preauthenticated QUOTA_DIR="$T" "$PM" assign 02:00:00:00:fa:03 0771234569 10 10 1 64 512 32 32 disconnect one_time 0 >/dev/null
ON=$(awk -F '\t' '$1=="02:00:00:00:fa:02" {print $8}' "$T/packages.tsv")
OFF=$(awk -F '\t' '$1=="02:00:00:00:fa:03" {print $8}' "$T/packages.tsv")
[ "$ON" = 1 ] && [ "$OFF" = 0 ] || fail 'package manager did not save per-account free values independently'
pass 'package manager stores independent ON/OFF values per account'
NDS_STATE=Preauthenticated QUOTA_DIR="$T" "$PM" assign 02:00:00:00:fa:04 0771234570 10 10 1 64 512 32 32 disconnect auto_renew 0 >/dev/null
[ "$(awk -F '\t' '$1=="02:00:00:00:fa:04" {print $7}' "$T/packages.tsv")" = auto_renew ] || fail 'package manager did not store auto_renew mode'
pass 'package manager accepts and stores auto-renew mode' 

# The enforcer gets a deterministic test clock via the mock date in PATH.
cp "$T/free-enforcer.sh" "$T/free-enforcer.test.sh"
chmod 700 "$T/free-enforcer.test.sh"

add_enforcer_case() {
    mac=$1 free=$2 expiry=$3 status=$4 used=$5
    QUOTA_DIR="$T" "$QM" add "$mac" - 1 1 >/dev/null
    awk -F '\t' -v OFS='\t' -v m="$mac" -v st="$status" -v u="$used" \
        '$1==m {$5=u; $6=u; $8=st} {print}' "$T/accounts.tsv" > "$T/accounts.tmp"
    mv "$T/accounts.tmp" "$T/accounts.tsv"
    printf '%s\t7\t%s\t%s\t64\t512\tone_time\t%s\tactive\t64\t64\tdisconnect\n' \
        "$mac" "$NOW" "$expiry" "$free" >> "$T/packages.tsv"
}
blocked() { awk -F '\t' -v m="$1" '$1==m {print $9; exit}' "$T/accounts.tsv"; }
run_enforcer() {
    : > "$T/deauth.log"
    QUOTA_DIR="$T" TEST_CLOCK="$1" \
        NDS_DEAUTH_LOG="$T/deauth.log" NDS_AUTH_LOG="$T/auth.log" \
        PATH="$T/bin:$PATH" "$T/free-enforcer.test.sh"
}

M1=02:00:00:00:ee:01
add_enforcer_case "$M1" 1 "$FUTURE" active 1048576
run_enforcer 070000
[ "$(blocked "$M1")" = 1 ] || fail 'exhausted free-enabled account not blocked at exactly 07:00'
grep -Fxq "$M1" "$T/deauth.log" || fail 'active exhausted client not deauthenticated at exactly 07:00'
pass '07:00 boundary immediately blocks and deauthenticates exhausted free-enabled account'

M2=02:00:00:00:ee:02
add_enforcer_case "$M2" 1 "$FUTURE" active 1048576
run_enforcer 010000
[ "$(blocked "$M2")" = 0 ] || fail 'exhausted free-enabled account blocked at 01:00'
! grep -Fxq "$M2" "$T/deauth.log" || fail 'free-enabled client deauthenticated at 01:00'
pass '01:00 enforcer leaves exhausted free-enabled account unblocked'

M3=02:00:00:00:ee:03
add_enforcer_case "$M3" 1 "$PAST" active 0
run_enforcer 010000
[ "$(blocked "$M3")" = 0 ] || fail 'expiry incorrectly set the quota lock'
grep -Fxq "$M3" "$T/deauth.log" || fail 'expired active client was not deauthenticated'
pass 'package expiry deauthenticates without setting the quota lock'

M4=02:00:00:00:ee:04
add_enforcer_case "$M4" 1 "$FUTURE" disabled 0
run_enforcer 010000
[ "$(blocked "$M4")" = 0 ] || fail 'administrative disable incorrectly set the quota lock'
grep -Fxq "$M4" "$T/deauth.log" || fail 'administratively disabled active client was not deauthenticated'
QUOTA_DIR="$T" "$QM" enable "$M4" >/dev/null
[ "$(awk -F '\t' -v m="$M4" '$1==m {print $8; exit}' "$T/accounts.tsv")" = active ] || fail 'admin re-enable did not restore account status'
[ "$(blocked "$M4")" = 0 ] || fail 'admin re-enable left a stale quota lock'
NDS_STATE=Preauthenticated NDS_AUTH_LOG="$T/auth.log" NDS_DEAUTH_LOG="$T/deauth.log" \
    QUOTA_DIR="$T" PATH="$T/bin:$PATH" TEST_CLOCK=010000 \
    "$QM" authorize "$M4" >/dev/null 2>&1 || fail 're-enabled account could not authenticate during free hours'
pass 'administrative disable/deauth and re-enable do not create a stale quota lock'

# A pending package is not an active entitlement, so deauthenticate if needed
# but do not turn that state into a persistent quota lock. Activation must work.
M_PENDING=02:00:00:00:ee:06
QUOTA_DIR="$T" "$QM" add "$M_PENDING" - 10 10 >/dev/null
printf '%s\t7\t0\t0\t64\t512\tone_time\t1\tpending\t64\t64\tdisconnect\n' "$M_PENDING" >> "$T/packages.tsv"
run_enforcer 010000
[ "$(blocked "$M_PENDING")" = 0 ] || fail 'pending package gained a quota lock'
NDS_STATE=Preauthenticated QUOTA_DIR="$T" "$PM" activate "$M_PENDING" >/dev/null
[ "$(blocked "$M_PENDING")" = 0 ] || fail 'activation left a stale quota lock'
pass 'pending free-enabled package can be activated without a stale quota lock'

# A not-yet-due auto-renew package is a valid entitlement.
M_AUTO=02:00:00:00:ee:07
QUOTA_DIR="$T" "$QM" add "$M_AUTO" - 10 10 >/dev/null
printf '%s\t7\t%s\t%s\t64\t512\tauto_renew\t1\tactive\t64\t64\tdisconnect\n' "$M_AUTO" "$NOW" "$FUTURE" >> "$T/packages.tsv"
run_enforcer 010000
[ "$(blocked "$M_AUTO")" = 0 ] || fail 'valid auto-renew package gained a quota lock'
! grep -Fxq "$M_AUTO" "$T/deauth.log" || fail 'valid auto-renew package was deauthenticated before expiry'
pass 'active auto-renew packages remain valid until expiry enforcement' 

M5=02:00:00:00:ee:05
add_enforcer_case "$M5" 0 "$FUTURE" active 1048576
run_enforcer 080000
[ "$(blocked "$M5")" = 0 ] || fail 'free-OFF account was modified by the free enforcer'
pass 'free-OFF account stays under normal OpenNDS quota enforcement'

# Configurable window is shared by the runtime enforcer as well as accounting.
M8=02:00:00:00:ee:08
add_enforcer_case "$M8" 1 "$FUTURE" active 1048576
cat > "$T/policy.conf" <<'POLICY_NIGHT'
DEFAULT_DOWNLOAD_MIB=1024
DEFAULT_UPLOAD_MIB=256
DEFAULT_VALIDITY_DAYS=7
DEFAULT_UPLOAD_KBPS=64
DEFAULT_DOWNLOAD_KBPS=512
DEFAULT_FREE_ENABLED=0
FREE_WINDOW_START=22:00
FREE_WINDOW_END=06:00
DEFAULT_RENEWAL_MODE=one_time
EXPIRED_ACCOUNT_ACTION=block_until_renewed
POLICY_NIGHT
run_enforcer 050000
[ "$(blocked "$M8")" = 0 ] || fail '22:00–06:00 schedule incorrectly blocked at 05:00'
run_enforcer 060000
[ "$(blocked "$M8")" = 1 ] || fail '22:00–06:00 schedule did not enforce quota at 06:00'
grep -Fxq "$M8" "$T/deauth.log" || fail 'custom-window daytime enforcement did not deauthenticate the session'
pass 'free enforcer follows administrator-configured 22:00–06:00 schedule and end boundary'
cp "$HERE/policy.conf.example" "$T/policy.conf"

# Authorization tests verify that exhausted accounts receive an unlimited
# OpenNDS session only inside the enabled account's free window.
M6=02:00:00:00:ab:01
M7=02:00:00:00:ab:02
for mac in "$M6" "$M7"; do
    QUOTA_DIR="$T" "$QM" add "$mac" - 1 1 >/dev/null
done
awk -F '\t' -v OFS='\t' -v a="$M6" -v b="$M7" \
    '$1==a || $1==b {$5=1048576; $6=1048576; $9=1} {print}' \
    "$T/accounts.tsv" > "$T/accounts.tmp"
mv "$T/accounts.tmp" "$T/accounts.tsv"
printf '%s\t1\t%s\t%s\t64\t512\tone_time\t1\tactive\t64\t64\tdisconnect\n' "$M6" "$NOW" "$FUTURE" >> "$T/packages.tsv"
printf '%s\t1\t%s\t%s\t64\t512\tone_time\t0\tactive\t64\t64\tdisconnect\n' "$M7" "$NOW" "$FUTURE" >> "$T/packages.tsv"
export QUOTA_DIR="$T" NDS_AUTH_LOG="$T/auth.log" NDS_DEAUTH_LOG="$T/deauth.log"
export PATH="$T/bin:$PATH" QUOTA_AUTH_SESSION=30 QUOTA_AUTH_UP_RATE=64 QUOTA_AUTH_DOWN_RATE=512 NDS_STATE=Preauthenticated
: > "$T/auth.log"
TEST_CLOCK=010000 "$QM" authorize "$M6" > "$T/auth-free.out" || { cat "$T/auth-free.out" >&2; fail 'free-enabled exhausted client could not authenticate at 01:00'; }
grep -Fq "auth $M6" "$T/auth.log" || fail 'free-window authorization did not call ndsctl auth'
grep -Eq "auth $M6 [0-9]+ 64 512 0 0" "$T/auth.log" || fail 'free-window authorization did not set unlimited OpenNDS quota'
pass 'exhausted free-enabled client can authenticate at 01:00 with external enforcement'

if TEST_CLOCK=065959 "$QM" authorize "$M6" > "$T/auth-last-second.out" 2>&1; then
    pass 'exhausted free-enabled client can authenticate through 06:59:59'
else
    cat "$T/auth-last-second.out" >&2
    fail 'free-enabled client was denied one second before 07:00'
fi
if TEST_CLOCK=070000 "$QM" authorize "$M6" > "$T/auth-day.out" 2>&1; then
    fail 'exhausted free-enabled client authenticated at exactly 07:00'
fi
grep -Eq 'quota|Quota|exhausted|blocked' "$T/auth-day.out" || fail '07:00 denial did not explain quota exhaustion'
pass 'exhausted free-enabled client is denied from exactly 07:00'

if TEST_CLOCK=010000 "$QM" authorize "$M7" > "$T/auth-off.out" 2>&1; then
    fail 'free-OFF exhausted client authenticated during free hours'
fi
grep -Eq 'quota|Quota|exhausted|blocked' "$T/auth-off.out" || fail 'free-OFF denial did not explain quota exhaustion'
pass 'free-OFF exhausted client stays quota-limited at 01:00'

echo "ALL $PASS FREE-WINDOW FUNCTIONAL TESTS PASSED"
