#!/bin/sh
# Isolated tests for returning-device account recognition and portal routing.
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PKG_ROOT=$(CDPATH= cd -- "$HERE/../.." && pwd)
T=$(mktemp -d /tmp/guest-return-test.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin" "$T/requests/metadata"
cp "$HERE/policy-lib.sh" "$HERE/package-shaper.sh" "$HERE/session-policy.sh" "$HERE/package-manager.sh" "$HERE/quota-manager.sh" "$T/"
cp "$PKG_ROOT/root/guest-portal-requests/live-manager.sh" "$T/requests/live-manager.sh"
chmod 700 "$T"/*.sh "$T/requests/live-manager.sh"

MAC=02:00:00:00:bb:01
NOW=$(/bin/date +%s)
printf '%s\n' 'DEFAULT_DOWNLOAD_MIB=1024' 'DEFAULT_UPLOAD_MIB=256' 'DEFAULT_VALIDITY_DAYS=7' 'DEFAULT_UPLOAD_KBPS=64' 'DEFAULT_DOWNLOAD_KBPS=512' 'DEFAULT_FREE_ENABLED=0' 'FREE_WINDOW_START=00:00' 'FREE_WINDOW_END=07:00' 'DEFAULT_RENEWAL_MODE=one_time' 'EXPIRED_ACCOUNT_ACTION=block_until_renewed' 'AUTO_APPROVE_REQUESTS=1' 'AUTO_AUTHENTICATE=1' 'UNASSIGNED_ACCESS_MODE=throttle' 'UNASSIGNED_RATE_KBPS=1' 'UNASSIGNED_SESSION_MINUTES=1440' 'PACKAGE_ACTIVATION_MODE=immediate' 'DEFAULT_AFTER_UPLOAD_KBPS=32' 'DEFAULT_AFTER_DOWNLOAD_KBPS=64' 'DEFAULT_AFTER_QUOTA_ACTION=throttle' > "$T/policy.conf"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/packages.tsv"
printf '%s\t%s\t%s\t%s\t0\t0\t2026-11-01\tactive\t0\t-\t0\t0\n' "$MAC" 0771234567 102400 51200 > "$T/accounts.tsv"
: > "$T/auth.log"; : > "$T/deauth.log"; : > "$T/policy.log"
echo Preauthenticated > "$T/state"

cat > "$T/bin/ndsctl" <<'MOCK_NDS'
#!/bin/sh
case "$1" in
 json)
   mac="$2"; state=$(cat "$NDS_STATE_FILE")
   printf '{"mac":"%s","state":"%s"}\n' "$mac" "$state"
   ;;
 auth)
   printf '%s\n' "$*" >> "$NDS_AUTH_LOG"; echo Authenticated > "$NDS_STATE_FILE"; echo 'authenticated.'
   ;;
 deauth)
   printf '%s\n' "$2" >> "$NDS_DEAUTH_LOG"; echo Preauthenticated > "$NDS_STATE_FILE"; echo 'deauthenticated.'
   ;;
 *) exit 2 ;;
esac
MOCK_NDS
cat > "$T/bin/jsonfilter" <<'MOCK_JSON'
#!/bin/sh
case "$*" in
 *'@.mac'*) sed -n 's/.*"mac":"\([^"]*\)".*/\1/p' ;;
 *'@.state'*) sed -n 's/.*"state":"\([^"]*\)".*/\1/p' ;;
 *) exit 1 ;;
esac
MOCK_JSON
cat > "$T/bin/logger" <<'MOCK_LOGGER'
#!/bin/sh
exit 0
MOCK_LOGGER
cat > "$T/package-shaper.sh" <<'MOCK_SHAPER'
#!/bin/sh
[ "$1" = clear ] || [ "$1" = sync ] || exit 2
echo "$*" >> "$SHAPER_LOG"
exit 0
MOCK_SHAPER
cat > "$T/session-policy.sh" <<'MOCK_POLICY'
#!/bin/sh
mode="$1"; mac="$2"
printf '%s %s\n' "$mode" "$mac" >> "$POLICY_LOG"
. "$QUOTA_DIR/policy-lib.sh"
policy_load
state=$(cat "$NDS_STATE_FILE")
if [ "$AUTO_AUTHENTICATE" != 1 ]; then
 [ "$state" != Authenticated ] || ndsctl deauth "$mac" >/dev/null
 echo 'Auto-authentication is off; device remains unauthenticated.'
 exit 0
fi
if [ "$mode" = package ]; then
 row=$(awk -F '\t' -v m="$mac" '$1==m{print;exit}' "$QUOTA_DIR/packages.tsv")
 [ -n "$row" ] || exit 1
 st=$(printf '%s\n' "$row" | awk -F '\t' '{print $9}')
 exp=$(printf '%s\n' "$row" | awk -F '\t' '{print $4}')
 now=$(/bin/date +%s)
 [ "$st" = active ] && [ "$exp" -gt "$now" ] 2>/dev/null || { [ "$state" != Authenticated ] || ndsctl deauth "$mac" >/dev/null; echo 'Package inactive.'; exit 0; }
 [ "$state" != Authenticated ] || ndsctl deauth "$mac" >/dev/null
 ndsctl auth "$mac" 100 128 512 0 0 dGVzdA== >/dev/null
 echo 'Authorized with package.'
else
 [ "$state" != Authenticated ] || ndsctl deauth "$mac" >/dev/null
 if [ "$UNASSIGNED_ACCESS_MODE" = throttle ]; then
  ndsctl auth "$mac" 1440 "$UNASSIGNED_RATE_KBPS" "$UNASSIGNED_RATE_KBPS" 0 0 dGVzdA== >/dev/null
  echo 'Unassigned device authenticated at temporary rate.'
 else
  echo 'Unassigned access policy is Block.'
 fi
fi
MOCK_POLICY
chmod 700 "$T/bin/"* "$T/session-policy.sh"
export PATH="$T/bin:$PATH" QUOTA_DIR="$T" REQUEST_MANAGER_DIR="$T/requests" REQUEST_MANAGER_QUEUE="$T/requests/pending.tsv" NDS_STATE_FILE="$T/state" NDS_AUTH_LOG="$T/auth.log" NDS_DEAUTH_LOG="$T/deauth.log" POLICY_LOG="$T/policy.log" SHAPER_LOG="$T/shaper.log"
PASS=0
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; PASS=$((PASS+1)); }
set_package(){ exp="$1"; st="${2:-active}"; printf '%s\t7\t%s\t%s\t128\t512\tone_time\t0\t%s\t32\t64\tthrottle\n' "$MAC" "$NOW" "$exp" "$st" > "$T/packages.tsv"; }
reset_state(){ echo Preauthenticated > "$T/state"; : > "$T/auth.log"; : > "$T/deauth.log"; : > "$T/policy.log"; sed -i '/^AUTO_AUTHENTICATE=/d;/^UNASSIGNED_ACCESS_MODE=/d' "$T/policy.conf"; printf '%s\n' 'AUTO_AUTHENTICATE=1' 'UNASSIGNED_ACCESS_MODE=throttle' >> "$T/policy.conf"; }

# Existing account with no package: apply the unassigned hold without creating a request.
reset_state; : > "$T/packages.tsv"; printf '%s\n' '# v3' > "$T/packages.tsv"
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_HOLD_AUTHENTICATED ] || fail "unassigned returning account result: $OUT"
grep -q '^auth ' "$T/auth.log" || fail 'unassigned returning account was not authenticated'
[ ! -s "$T/requests/pending.tsv" ] || fail 'resume created a request row'
pass 'existing unassigned account receives the temporary hold policy without re-registration'

# A returning device can reach the splash while openNDS still reports Authenticated.
# Re-apply the saved policy safely and preserve the same MAC/account.
reset_state; : > "$T/packages.tsv"; printf '%s\n' '# v3' > "$T/packages.tsv"; echo Authenticated > "$T/state"
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_HOLD_AUTHENTICATED ] || fail "already-authenticated return result: $OUT"
grep -Fxq "$MAC" "$T/deauth.log" || fail 'authenticated returning guest was not cleanly rotated through preauth'
grep -q '^auth ' "$T/auth.log" || fail 'authenticated returning guest was not reauthenticated under hold policy'
pass 'already-authenticated returning device is safely revalidated without re-registration'

# Active package: apply package policy without a new request.
reset_state; set_package $((NOW+86400)) active
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_PACKAGE_AUTHENTICATED ] || fail "active package result: $OUT"
grep -q '^package ' "$T/policy.log" || fail 'active package path not used'
pass 'active returning account receives its package policy automatically'

# Expired package never falls back to the unassigned hold policy.
reset_state; set_package $((NOW-1)) active
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_NO_INTERNET ] || fail "expired package result: $OUT"
[ ! -s "$T/auth.log" ] || fail 'expired package fell back to temporary auth'
grep -q '^package ' "$T/policy.log" || fail 'expired package did not use package policy path'
pass 'expired package is blocked and never falls back to unassigned access'

# Pending package must not fall back to unassigned hold.
reset_state; set_package $((NOW+86400)) pending
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_NO_INTERNET ] || fail "pending package result: $OUT"
[ ! -s "$T/auth.log" ] || fail 'pending package fell back to temporary auth'
pass 'pending package remains unauthenticated until activation'

# Unassigned block mode is captive portal only.
reset_state; : > "$T/packages.tsv"; printf '%s\n' '# v3' > "$T/packages.tsv"
sed -i 's/^UNASSIGNED_ACCESS_MODE=.*/UNASSIGNED_ACCESS_MODE=block/' "$T/policy.conf"
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_NO_INTERNET ] || fail "unassigned block result: $OUT"
[ ! -s "$T/auth.log" ] || fail 'block mode authenticated returning account'
pass 'unassigned block policy does not grant internet on reconnect'

# Auto-auth off must leave returning package accounts for administrator action.
reset_state; set_package $((NOW+86400)) active
sed -i 's/^AUTO_AUTHENTICATE=.*/AUTO_AUTHENTICATE=0/' "$T/policy.conf"
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_ADMIN_ACTION ] || fail "auto-auth-off result: $OUT"
[ "$(cat "$T/state")" = Preauthenticated ] || fail 'auto-auth-off left device authenticated'
pass 'Auto-auth Off keeps a returning package guest unauthenticated for admin action'

# Disabled account is always blocked.
reset_state; : > "$T/packages.tsv"; printf '%s\n' '# v3' > "$T/packages.tsv"
awk -F '\t' -v OFS='\t' '{$8="disabled";print}' "$T/accounts.tsv" > "$T/accounts.tmp"; mv "$T/accounts.tmp" "$T/accounts.tsv"
OUT=$("$T/requests/live-manager.sh" resume "$MAC")
[ "$OUT" = RETURN_NO_INTERNET ] || fail "disabled account result: $OUT"
[ ! -s "$T/auth.log" ] || fail 'disabled account was authenticated'
pass 'disabled returning account is blocked'

# Unknown MAC receives the new-device path, and stale auth is revoked.
reset_state; echo Authenticated > "$T/state"
NEW=02:00:00:00:bb:99
OUT=$("$T/requests/live-manager.sh" resume "$NEW")
[ "$OUT" = RETURN_NEW_DEVICE ] || fail "unknown device result: $OUT"
grep -Fxq "$NEW" "$T/deauth.log" || fail 'unknown authenticated MAC was not deauthenticated'
pass 'unknown device receives registration form path and cannot retain stale authentication'

# Theme-level routing: saved account statuses suppress the repeated name/mobile form.
THEME="$PKG_ROOT/usr/lib/opennds/theme_guest-approval-requests.sh"
cat > "$T/fake-return-manager" <<'FAKE_RETURN'
#!/bin/sh
[ "${FAKE_RETURN_FAIL:-0}" = 0 ] || { echo 'mock manager failure'; exit 1; }
printf '%s\n' "$FAKE_RETURN_RESULT"
FAKE_RETURN
chmod 700 "$T/fake-return-manager"
for result in RETURN_NEW_DEVICE RETURN_PACKAGE_AUTHENTICATED RETURN_HOLD_AUTHENTICATED RETURN_ADMIN_ACTION RETURN_NO_INTERNET; do
  OUT=$(GUEST_RETURN_MANAGER="$T/fake-return-manager" FAKE_RETURN_RESULT="$result" clientmac="$MAC" /bin/sh -c '
    . "$1"
    login_form(){ echo REGISTRATION_FORM; }
    footer(){ echo FOOTER; }
    read_terms(){ :; }
    name_email_login
  ' sh "$THEME")
  case "$result" in
    RETURN_NEW_DEVICE) printf '%s' "$OUT" | grep -q REGISTRATION_FORM || fail 'new device did not receive registration form' ;;
    *) printf '%s' "$OUT" | grep -q REGISTRATION_FORM && fail "$result incorrectly displayed registration form" ;;
  esac
done
pass 'portal splash shows registration form only for a device without an existing account'

OUT=$(GUEST_RETURN_MANAGER="$T/fake-return-manager" FAKE_RETURN_FAIL=1 clientmac="$MAC" /bin/sh -c '
  . "$1"
  login_form(){ echo REGISTRATION_FORM; }
  footer(){ echo FOOTER; }
  read_terms(){ :; }
  name_email_login
' sh "$THEME")
printf '%s' "$OUT" | grep -q 'REGISTRATION_FORM' && fail 'manager failure fell back to an unsafe duplicate registration form'
printf '%s' "$OUT" | grep -q 'could not safely apply' || fail 'manager failure did not show a fail-closed message'
pass 'returning-device lookup failure fails closed instead of creating a duplicate registration'

OUT=$(GUEST_RETURN_MANAGER="$T/fake-return-manager" FAKE_RETURN_RESULT=RETURN_NEW_DEVICE clientmac='' /bin/sh -c '
  . "$1"
  login_form(){ echo REGISTRATION_FORM; }
  footer(){ echo FOOTER; }
  read_terms(){ :; }
  name_email_login
' sh "$THEME")
printf '%s' "$OUT" | grep -q REGISTRATION_FORM || fail 'client without MAC did not see the registration form'
pass 'new device without an openNDS client MAC retains the registration form'

echo "ALL $PASS RETURNING-DEVICE TESTS PASSED"
