#!/bin/sh
# Isolated tests for administrator-controlled automatic MAC account enrollment.
set -eu
PKG_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/../../.." && pwd)"
T=$(mktemp -d /tmp/guest-auto-mac-test.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin" "$T/requests"
cp "$PKG_ROOT/root/guest-portal-accounting/policy-lib.sh" "$T/policy-lib.sh"
cp "$PKG_ROOT/root/guest-portal-accounting/quota-manager.sh" "$T/quota-manager.sh"
chmod 700 "$T/quota-manager.sh"
printf '%s\n' '# v3 packages' > "$T/packages.tsv"
: > "$T/accounts.tsv"
: > "$T/session-policy.log"
MAC=c6:7a:68:cd:71:c0
STATE="$T/nds-state"
echo Preauthenticated > "$STATE"
cat > "$T/policy.conf" <<'POLICY'
DEFAULT_DOWNLOAD_MIB=1024
DEFAULT_UPLOAD_MIB=256
DEFAULT_VALIDITY_DAYS=7
DEFAULT_UPLOAD_KBPS=64
DEFAULT_DOWNLOAD_KBPS=512
DEFAULT_AFTER_UPLOAD_KBPS=32
DEFAULT_AFTER_DOWNLOAD_KBPS=64
DEFAULT_AFTER_QUOTA_ACTION=throttle
DEFAULT_FREE_ENABLED=0
FREE_WINDOW_START=00:00
FREE_WINDOW_END=07:00
AUTO_APPROVE_REQUESTS=1
AUTO_AUTHENTICATE=1
UNASSIGNED_ACCESS_MODE=throttle
UNASSIGNED_RATE_KBPS=1
UNASSIGNED_SESSION_MINUTES=1440
PACKAGE_ACTIVATION_MODE=immediate
MAC_AUTO_ENROLL=1
POLICY
cat > "$T/session-policy.sh" <<'SESSION'
#!/bin/sh
printf '%s %s\n' "$1" "$2" >> "$QUOTA_DIR/session-policy.log"
. "$QUOTA_DIR/policy-lib.sh"; policy_load
if [ "$AUTO_AUTHENTICATE" = 1 ] && [ "$UNASSIGNED_ACCESS_MODE" = throttle ]; then
 echo Authenticated > "$NDS_STATE_FILE"
 echo 'Temporary holding policy applied.'
else
 echo Preauthenticated > "$NDS_STATE_FILE"
 echo 'Device remains unauthenticated or blocked.'
fi
SESSION
cat > "$T/bin/ndsctl" <<'NDS'
#!/bin/sh
case "$1" in
 json)
  mac="$2"; state=$(cat "$NDS_STATE_FILE")
  printf '{"mac":"%s","state":"%s"}\n' "$mac" "$state"
  ;;
 *) exit 2 ;;
esac
NDS
cat > "$T/bin/jsonfilter" <<'JSONFILTER'
#!/bin/sh
case "$*" in
 *'@.mac'*) sed -n 's/.*"mac":"\([^"]*\)".*/\1/p' ;;
 *'@.state'*) sed -n 's/.*"state":"\([^"]*\)".*/\1/p' ;;
 *) exit 1 ;;
esac
JSONFILTER
cat > "$T/bin/logger" <<'LOGGER'
#!/bin/sh
exit 0
LOGGER
chmod 700 "$T/session-policy.sh" "$T/bin/ndsctl" "$T/bin/jsonfilter" "$T/bin/logger"
export PATH="$T/bin:$PATH" QUOTA_DIR="$T" NDS_STATE_FILE="$STATE"
MANAGER="$PKG_ROOT/root/guest-portal-requests/live-manager.sh"
OUT=$("$MANAGER" auto-enroll "$MAC")
printf '%s' "$OUT" | grep -q 'AUTO_MAC_ENROLLED_LIMITED' || { echo "FAIL: unexpected auto-enrollment result: $OUT" >&2; exit 1; }
ROW=$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$T/accounts.tsv")
[ -n "$ROW" ] || { echo 'FAIL: account row was not created' >&2; exit 1; }
printf '%s\n' "$ROW" | awk -F '\t' '$2=="-" && $3==1048576 && $4==262144 && $5==0 && $6==0 && $8=="active" {ok=1} END {exit !ok}' || { echo 'FAIL: automatic account did not use independent policy quota defaults or no-phone marker' >&2; exit 1; }
[ "$(cat "$STATE")" = Authenticated ] || { echo 'FAIL: unassigned temporary access policy was not applied' >&2; exit 1; }
[ ! -s "$T/requests/pending.tsv" ] || { echo 'FAIL: auto enrollment unexpectedly created request queue rows' >&2; exit 1; }
echo 'PASS: MAC auto-enrollment creates an account with separate default download/upload allowances, no invented phone number, and the configured temporary access policy'

# Repeated invocation reuses the existing account and does not reset its counters.
awk -F '\t' -v OFS='\t' -v m="$MAC" '$1==m {$5=12345;$6=6789} {print}' "$T/accounts.tsv" > "$T/accounts.tmp" && mv "$T/accounts.tmp" "$T/accounts.tsv"
OUT=$("$MANAGER" auto-enroll "$MAC")
[ "$(awk -F '\t' -v m="$MAC" '$1==m {n++} END {print n+0}' "$T/accounts.tsv")" = 1 ] || { echo 'FAIL: repeat auto-enrollment duplicated the account' >&2; exit 1; }
awk -F '\t' -v m="$MAC" '$1==m && $5==12345 && $6==6789 {ok=1} END {exit !ok}' "$T/accounts.tsv" || { echo 'FAIL: repeat auto-enrollment reset existing usage' >&2; exit 1; }
echo 'PASS: returning MAC reuses the existing account and preserves its recorded usage'

# Policy Off must not create accounts.
NEW=02:11:22:33:44:99
sed -i 's/^MAC_AUTO_ENROLL=.*/MAC_AUTO_ENROLL=0/' "$T/policy.conf"
if "$MANAGER" auto-enroll "$NEW" >/dev/null 2>&1; then echo 'FAIL: disabled auto-enrollment was accepted' >&2; exit 1; fi
! awk -F '\t' -v m="$NEW" '$1==m {found=1} END {exit !found}' "$T/accounts.tsv" || { echo 'FAIL: disabled mode created an account' >&2; exit 1; }
echo 'PASS: Policy Off refuses automatic account creation'

# Policy On with Block creates the account but does not authenticate it.
sed -i 's/^MAC_AUTO_ENROLL=.*/MAC_AUTO_ENROLL=1/;s/^UNASSIGNED_ACCESS_MODE=.*/UNASSIGNED_ACCESS_MODE=block/' "$T/policy.conf"
echo Preauthenticated > "$STATE"
OUT=$("$MANAGER" auto-enroll "$NEW")
printf '%s' "$OUT" | grep -q 'AUTO_MAC_ENROLLED_BLOCKED' || { echo "FAIL: Block policy result incorrect: $OUT" >&2; exit 1; }
[ "$(cat "$STATE")" = Preauthenticated ] || { echo 'FAIL: Block policy authenticated the new device' >&2; exit 1; }
echo 'PASS: automatic enrollment respects Block mode and does not grant internet access'

# Theme integration: an unknown device in auto mode does not render the registration form.
cat > "$T/policy-auto.sh" <<'POLICY_LIB'
MAC_AUTO_ENROLL=1
policy_load(){ :; }
POLICY_LIB
cat > "$T/fake-manager.sh" <<'FAKE'
#!/bin/sh
case "$1" in
 resume) echo RETURN_NEW_DEVICE ;;
 auto-enroll) echo AUTO_MAC_ENROLLED_LIMITED ;;
 *) exit 2 ;;
esac
FAKE
chmod 700 "$T/fake-manager.sh"
OUT=$(GUEST_RETURN_MANAGER="$T/fake-manager.sh" GUEST_POLICY_LIB="$T/policy-auto.sh" clientmac="$MAC" /bin/sh -c '
 . "$1"
 read_terms(){ :; }
 footer(){ echo FOOTER; }
 login_form(){ echo REGISTRATION_FORM; }
 name_email_login
' sh "$PKG_ROOT/usr/lib/opennds/theme_guest-approval-requests.sh")
printf '%s' "$OUT" | grep -q 'Device registered' || { echo 'FAIL: auto-MAC theme message missing' >&2; exit 1; }
printf '%s' "$OUT" | grep -q 'REGISTRATION_FORM' && { echo 'FAIL: auto-MAC mode still showed the guest registration form' >&2; exit 1; }
echo 'PASS: openNDS theme suppresses the name/mobile registration form when automatic MAC enrollment is enabled'

echo 'ALL 5 AUTOMATIC MAC ENROLLMENT CHECKS PASSED'
