#!/bin/sh
# Isolated test of the live Devices tab and quick package preselection.
set -eu
PKG_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/../../.." && pwd)"
CGI="$PKG_ROOT/srv/guest-dashboard/cgi-bin/requests"
PACKAGES_CGI="$PKG_ROOT/srv/guest-dashboard/cgi-bin/packages"
T=$(mktemp -d /tmp/guest-device-inventory-test.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
MAC=c6:7a:68:cd:71:c0
MAC2=02:11:22:33:44:55
NOW=$(date +%s)
EXPIRY=$((NOW+2592000))
mkdir -p "$T/accounting" "$T/requests/metadata" "$T/bin"
cp "$PKG_ROOT/root/guest-portal-accounting/policy-lib.sh" "$T/accounting/policy-lib.sh"
cat > "$T/accounting/policy.conf" <<'POLICY'
DEFAULT_DOWNLOAD_MIB=1024
DEFAULT_UPLOAD_MIB=256
DEFAULT_VALIDITY_DAYS=7
DEFAULT_UPLOAD_KBPS=64
DEFAULT_DOWNLOAD_KBPS=512
DEFAULT_AFTER_UPLOAD_KBPS=32
DEFAULT_AFTER_DOWNLOAD_KBPS=64
DEFAULT_AFTER_QUOTA_ACTION=throttle
DEFAULT_FREE_ENABLED=0
FREE_WINDOW_START=00:00
FREE_WINDOW_END=07:00
AUTO_APPROVE_REQUESTS=1
AUTO_AUTHENTICATE=1
UNASSIGNED_ACCESS_MODE=throttle
UNASSIGNED_RATE_KBPS=1
UNASSIGNED_SESSION_MINUTES=1440
PACKAGE_ACTIVATION_MODE=immediate
MAC_AUTO_ENROLL=0
POLICY
printf '%s\n' '# v3 account test' > "$T/accounting/accounts.tsv"
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$MAC" 0771234567 1048576 262144 104857600 20971520 2026-11-02 active 0 - 0 0 >> "$T/accounting/accounts.tsv"
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$MAC2" - 2097152 524288 10485760 5242880 2026-11-02 active 0 - 0 0 >> "$T/accounting/accounts.tsv"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/accounting/packages.tsv"
printf '%s\t30\t%s\t%s\t128\t2048\tauto_renew\t1\tactive\t32\t64\tthrottle\n' "$MAC2" "$NOW" "$EXPIRY" >> "$T/accounting/packages.tsv"
TOKEN=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
RID=REQ-1793610000-1234
printf '%s\t1793610000\t%s\tAlice Guest\t0771234567\tdGVzdA==\t1440\t64\t512\t1024\t256\tAPPROVED\n' "$RID" "$TOKEN" > "$T/requests/pending.tsv"
printf '%s\t172.16.42.168\tAndroid 14; Pixel 7; Chrome\t%s\n' "$MAC" "$TOKEN" > "$T/requests/metadata/$RID.tsv"
: > "$T/requests/history.tsv"
printf '1793700000 %s 172.16.42.168 pixel-7-wifi *\n' "$MAC" > "$T/dhcp.leases"
printf '%s %s 172.16.42.169 ipad-kitchen *\n' "$EXPIRY" "$MAC2" >> "$T/dhcp.leases"
cat > "$T/allow-client.sh" <<'ALLOW'
#!/bin/sh
exit 0
ALLOW
cat > "$T/live-manager.sh" <<'MANAGER'
#!/bin/sh
[ "$1" = list ] || exit 2
echo 'ID: REQ-1793610000-1234 | Name: Alice Guest | Mobile: 0771234567 | Status: APPROVED'
MANAGER
cat > "$T/bin/ndsctl" <<'NDS'
#!/bin/sh
case "$1" in
 json)
  cat <<'JSON'
{"clients":{"c6:7a:68:cd:71:c0":{"mac":"c6:7a:68:cd:71:c0","ip":"172.16.42.168","state":"Authenticated","session_start":1793610000,"download_this_session":102400,"upload_this_session":20480},"02:11:22:33:44:55":{"mac":"02:11:22:33:44:55","ip":"172.16.42.169","state":"Authenticated","session_start":1793610300,"download_this_session":2048,"upload_this_session":512}}}
JSON
  ;;
 deauth) echo deauthenticated ;;
 *) exit 2 ;;
esac
NDS
chmod 700 "$T/allow-client.sh" "$T/live-manager.sh" "$T/bin/ndsctl"
export PATH="$T/bin:$PATH"
OUT=$(REQUEST_METHOD=GET REMOTE_ADDR=192.168.2.55 \
 QUOTA_DIR="$T/accounting" REQUEST_MANAGER_DIR="$T/requests" \
 REQUEST_MANAGER_QUEUE="$T/requests/pending.tsv" REQUEST_MANAGER="$T/live-manager.sh" \
 QUOTA_CGI_ALLOW="$T/allow-client.sh" DHCP_LEASES_FILE="$T/dhcp.leases" \
 /bin/sh "$CGI")
for expected in 'Connected device inventory' 'Alice Guest' 'pixel-7-wifi' "$MAC" '172.16.42.168' 'Android 14; Pixel 7; Chrome' 'Authenticated' '0771234567' 'Assign package' 'Account download quota' 'Account upload quota' 'DHCP lease expires' 'Portal request status' 'No package settings assigned' 'ipad-kitchen' 'auto_renew' 'Normal upload/download: 128 / 2048 kbps' 'After quota: 32 / 64 kbps (throttle)' 'Free data: On' 'View assigned package'; do
    printf '%s' "$OUT" | grep -Fq "$expected" || { echo "FAIL: device inventory missing: $expected" >&2; exit 1; }
done
printf '%s' "$OUT" | grep -Fq "href=\"/cgi-bin/packages?mac=$MAC\"" || { echo 'FAIL: quick assign-package link missing' >&2; exit 1; }
printf '%s' "$OUT" | grep -Fq "href=\"/cgi-bin/packages?tab=assigned&amp;mac=$MAC2\"" || { echo 'FAIL: quick view assigned-package link missing' >&2; exit 1; }
printf '%s' "$OUT" | grep -q 'id="tab-devices" role="tab" aria-selected="true"' || { echo 'FAIL: Devices tab is not the default selected tab' >&2; exit 1; }
echo 'PASS: Devices tab is the default view and shows unassigned and assigned guest identity, DHCP, session, usage, quota, package speeds, free-window and quick package actions'

# An existing unassigned account must be preselected when opened from Devices.
OUT=$(REQUEST_METHOD=GET QUERY_STRING="mac=$MAC" REMOTE_ADDR=192.168.2.55 \
 QUOTA_DIR="$T/accounting" QUOTA_CGI_ALLOW="$T/allow-client.sh" \
 /bin/sh "$PACKAGES_CGI")
printf '%s' "$OUT" | grep -Fq "<option value=\"$MAC\" selected>" || { echo 'FAIL: Packages did not preselect the connected guest account' >&2; exit 1; }
printf '%s' "$OUT" | grep -Fq "var requestedTab='create'" || { echo 'FAIL: package assignment link did not open the create/attach tab' >&2; exit 1; }
echo 'PASS: Assign package opens Packages with the correct existing account preselected'

echo 'ALL 2 DEVICE INVENTORY CHECKS PASSED'
