#!/bin/sh
# Isolated tests for per-package after-quota throttle/disconnect enforcement.
# All tc and openNDS commands are mocked; the live router is never modified.
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
T=$(mktemp -d /tmp/guest-after-quota-test.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin"
for f in quota-manager.sh package-manager.sh policy-lib.sh session-policy.sh free-enforcer.sh poll-accounting.sh package-shaper.sh; do cp "$HERE/$f" "$T/$f"; done
cp "$HERE/policy.conf.example" "$T/policy.conf"
chmod 700 "$T"/*.sh
: > "$T/accounting.lock"
printf '%s\n' '# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION' > "$T/packages.tsv"

cat > "$T/bin/date" <<'MOCK_DATE'
#!/bin/sh
case "$1" in
    +%H%M) if [ -n "${TEST_CLOCK:-}" ]; then printf '%s\n' "$TEST_CLOCK"; else exec /bin/date +%H%M; fi ;;
    *) exec /bin/date "$@" ;;
esac
MOCK_DATE
cat > "$T/bin/ndsctl" <<'MOCK_NDS'
#!/bin/sh
case "$1" in
    json)
        MAC="$2"
        [ -z "${NDS_JSON_LOG:-}" ] || printf 'json %s\n' "$MAC" >> "$NDS_JSON_LOG"
        printf '{"mac":"%s","state":"%s"}\n' "$MAC" "${NDS_STATE:-Preauthenticated}"
        ;;
    auth) printf '%s\n' "$*" >> "$NDS_AUTH_LOG"; echo 'authenticated.' ;;
    deauth)
        [ "${NDS_STATE:-Preauthenticated}" = Authenticated ] || { echo 'ndsctl deauth only accepts currently authenticated clients' >&2; exit 1; }
        printf '%s\n' "$2" >> "$NDS_DEAUTH_LOG"
        echo 'deauthenticated.'
        ;;
    *) exit 2 ;;
esac
MOCK_NDS
cat > "$T/bin/jsonfilter" <<'MOCK_JSONFILTER'
#!/bin/sh
case "$*" in
    *'@.mac'*) sed -n 's/.*"mac":"\([^"]*\)".*/\1/p' ;;
    *'@.state'*) sed -n 's/.*"state":"\([^"]*\)".*/\1/p' ;;
    *) exit 1 ;;
esac
MOCK_JSONFILTER
cat > "$T/bin/tc" <<'MOCK_TC'
#!/bin/sh
case "$1:$2:$4" in
    qdisc:show:br-guest) echo 'qdisc htb 1: root refcnt 2' ;;
    class:show:br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit' ;;
    qdisc:show:ifb4br-guest) echo 'qdisc htb 1: root refcnt 2' ;;
    class:show:ifb4br-guest) echo 'class htb 1:1 root rate 10Mbit ceil 10Mbit'; echo 'class htb 1:10 parent 1:1 rate 10Mbit ceil 10Mbit' ;;
    filter:show:br-guest)
        case "$*" in
            *ingress*) echo 'mirred redirect to ifb4br-guest' ;;
            *'parent 1:'*)
                if [ "${TC_SHOW_OWN:-0}" = 1 ]; then
                    echo 'filter protocol all pref 0 flower chain 0'
                    echo 'filter protocol all pref 0 flower chain 0 handle 0x4000 classid 1:4000'
                fi
                if [ "${TC_SHOW_FOREIGN:-0}" = 1 ]; then
                    echo 'filter protocol all pref 0 u32 chain 0 handle 0x5'
                fi
                ;;
        esac
        ;;
esac
printf '%s\n' "$*" >> "$TC_LOG"
case "$*" in
    *'class add'*|*'filter replace'*) [ "${TC_FAIL:-0}" = 1 ] && exit 1 ;;
esac
exit 0
MOCK_TC
chmod 700 "$T/bin/"*
export PATH="$T/bin:$PATH" QUOTA_DIR="$T" NDS_AUTH_LOG="$T/auth.log" NDS_DEAUTH_LOG="$T/deauth.log" NDS_JSON_LOG="$T/ndsctl-json.log" TC_LOG="$T/tc.log"

PASS=0
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; PASS=$((PASS+1)); }
set_exhausted() {
    MAC="$1"
    awk -F '\t' -v OFS='\t' -v m="$MAC" '$1==m {$5=$3*1024;$6=$4*1024} {print}' "$T/accounts.tsv" > "$T/accounts.tmp"
    mv "$T/accounts.tmp" "$T/accounts.tsv"
}
run_enforcer() {
    QUOTA_DIR="$T" NDS_STATE="${ENFORCER_NDS_STATE:-Authenticated}" NDS_DEAUTH_LOG="$T/deauth.log" NDS_AUTH_LOG="$T/auth.log" TEST_CLOCK="${1:-120000}" "$T/free-enforcer.sh"
}
blocked(){ awk -F '\t' -v m="$1" '$1==m {print $9;exit}' "$T/accounts.tsv"; }

# A normal package uses openNDS average-rate thresholds; on quota exhaustion,
# volume quotas become unlimited and the separate TC profile is applied.
M1=02:00:00:00:aa:11
: > "$T/auth.log"; : > "$T/deauth.log"; : > "$T/tc.log"
NDS_STATE=Preauthenticated "$T/package-manager.sh" assign "$M1" 0771111222 1 1 7 128 512 32 64 throttle one_time 0 >/dev/null
set_exhausted "$M1"
run_enforcer 120000
[ "$(blocked "$M1")" = 0 ] || fail 'throttle action left the quota block set'
[ ! -s "$T/deauth.log" ] || fail 'throttle action deauthenticated an exhausted guest'
grep -Fq "flower dst_mac $M1 classid 1:4000" "$T/tc.log" || fail 'download after-quota class/filter was not installed'
grep -Fq "flower src_mac $M1 classid 1:4000" "$T/tc.log" || fail 'upload after-quota class/filter was not installed'
grep -Fq 'ceil 64kbit' "$T/tc.log" || fail 'after-quota download ceiling was not applied'
grep -Fq 'ceil 32kbit' "$T/tc.log" || fail 'after-quota upload ceiling was not applied'
TC_SHOW_OWN=1 "$T/package-shaper.sh" check >/dev/null || fail 'shaper rejected its own flower pref-0 filters'
if TC_SHOW_FOREIGN=1 "$T/package-shaper.sh" check >/dev/null 2>&1; then fail 'shaper did not reject a foreign pref-0 filter'; fi
pass 'quota exhaustion keeps guest authenticated and applies separate upload/download caps'
pass 'package shaper safely recognizes its own flower filters and rejects foreign pref-0 filters'

# The openNDS authentication command for throttle packages must use unlimited
# volume counters (zero/zero), not trigger automatic quota deauthentication.
: > "$T/auth.log"
NDS_STATE=Preauthenticated QUOTA_DIR="$T" "$T/session-policy.sh" package-force "$M1" >/dev/null
AUTH_LINE=$(grep -F "auth $M1" "$T/auth.log" | tail -n 1)
printf '%s' "$AUTH_LINE" | grep -Eq "auth $M1 [0-9]+ 128 512 0 0 " || fail 'throttle package did not receive unlimited openNDS volume counters'
pass 'throttle-mode authentication keeps openNDS volume quotas unlimited'

# Direct authorize callers (for example another trusted local admin helper)
# must also install the after-quota profile before auth, not rely on the caller
# having invoked session-policy first.
: > "$T/tc.log"; : > "$T/auth.log"
NDS_STATE=Preauthenticated QUOTA_DIR="$T" "$T/quota-manager.sh" authorize "$M1" >/dev/null
 grep -Fq "flower dst_mac $M1 classid 1:4000" "$T/tc.log" || fail 'direct quota-manager authorization did not synchronize after-quota shaping'
grep -Eq "auth $M1 [0-9]+ 128 512 0 0 " "$T/auth.log" || fail 'direct quota-manager authorization did not retain unlimited volume counters'
pass 'quota-manager central authorization guard applies the after-quota profile for every caller'

# A free-enabled throttle package is released during the free window, then
# throttled again at the configured end boundary.
M2=02:00:00:00:aa:12
: > "$T/tc.log"; : > "$T/deauth.log"
NDS_STATE=Preauthenticated "$T/package-manager.sh" assign "$M2" 0771111223 1 1 7 128 512 24 48 throttle one_time 1 >/dev/null
set_exhausted "$M2"
run_enforcer 080000
grep -Fq "flower dst_mac $M2" "$T/tc.log" || fail 'outside-free-window exhaustion did not apply throttle'
: > "$T/tc.log"
run_enforcer 010000
! grep -Fq "flower dst_mac $M2" "$T/tc.log" || fail 'free window did not remove the throttle profile'
grep -Fq "filter del dev br-guest" "$T/tc.log" || fail 'free-window transition did not clear the package filter'
: > "$T/tc.log"
run_enforcer 070000
grep -Fq "flower dst_mac $M2" "$T/tc.log" || fail 'free-window end did not restore after-quota throttle'
[ "$(blocked "$M2")" = 0 ] || fail 'free-enabled throttle package was quota-blocked'
[ ! -s "$T/deauth.log" ] || fail 'free-window throttle transition deauthenticated the guest'
pass 'free-enabled throttle package restores normal rates during free hours and throttles after the window'

# For throttle action, a zero direction means keep the normal package rate;
# only the finite direction gets a TC class/filter.
M3=02:00:00:00:aa:13
: > "$T/tc.log"
NDS_STATE=Preauthenticated "$T/package-manager.sh" assign "$M3" 0771111224 1 1 7 128 512 40 0 throttle one_time 0 >/dev/null
set_exhausted "$M3"
run_enforcer 120000
grep -Fq "flower src_mac $M3" "$T/tc.log" || fail 'finite upload cap was not applied'
! grep -Fq "flower dst_mac $M3" "$T/tc.log" || fail 'zero after-quota download rate created a redundant class'
pass 'after-quota rates can be independently disabled by direction'

# If TC installation fails, the enforcer must fail closed by setting the
# quota block and deauthenticating rather than leaving the guest unrestricted.
M4=02:00:00:00:aa:14
NDS_STATE=Preauthenticated "$T/package-manager.sh" assign "$M4" 0771111225 1 1 7 128 512 16 16 throttle one_time 0 >/dev/null
set_exhausted "$M4"
: > "$T/deauth.log"; : > "$T/tc.log"
# Export the mock failure switch explicitly. Prefixing a shell function with
# an assignment has subtly different environment behaviour across /bin/shs.
TC_FAIL=1
export TC_FAIL
run_enforcer 120000 || echo 'INFO: enforcer returned non-zero while exercising the expected shaper failure'
unset TC_FAIL
# Confirm that the test reached the mocked TC add/replace failure path.
grep -Eq 'class add|filter replace' "$T/tc.log" || fail 'mock did not exercise a traffic-control failure'
[ "$(blocked "$M4")" = 1 ] || fail 'TC failure did not set a fail-closed quota block'
grep -Fxq "$M4" "$T/deauth.log" || fail 'TC failure did not deauthenticate the client'
pass 'traffic-shaper failure fails closed by blocking and deauthenticating the client'

# Disconnect mode on a free-enabled package must block and deauthenticate at
# the free-window end, preserving the existing block-until-renewed behaviour.
M5=02:00:00:00:aa:15
NDS_STATE=Preauthenticated "$T/package-manager.sh" assign "$M5" 0771111226 1 1 7 128 512 32 64 disconnect one_time 1 >/dev/null
set_exhausted "$M5"
: > "$T/deauth.log"
run_enforcer 070000
[ "$(blocked "$M5")" = 1 ] || fail 'disconnect action did not set quota block at free-window end'
grep -Fxq "$M5" "$T/deauth.log" || fail 'disconnect action did not deauthenticate the exhausted client'
pass 'disconnect action blocks and deauthenticates exhausted free-enabled guests'


# A preauthenticated guest is already blocked from internet access. The
# enforcer must not send ndsctl deauth, which is only valid for authenticated clients.
M6=02:00:00:00:aa:16
NDS_STATE=Preauthenticated "$T/package-manager.sh" assign "$M6" 0771111227 1 1 7 128 512 32 64 disconnect one_time 0 >/dev/null
awk -F '\t' -v OFS='\t' -v m="$M6" '$1==m {$4=1} {print}' "$T/packages.tsv" > "$T/packages.tmp"
mv "$T/packages.tmp" "$T/packages.tsv"
: > "$T/deauth.log"
ENFORCER_NDS_STATE=Preauthenticated run_enforcer 120000 || fail 'expiry enforcer failed for an already-preauthenticated guest'
grep -Fxq "json $M6" "$T/ndsctl-json.log" || fail 'expired package did not reach its client-state check'
! grep -Fxq "$M6" "$T/deauth.log" || fail 'enforcer sent ndsctl deauth to an already-preauthenticated guest'
pass 'expiry enforcement recognizes preauthenticated as already unauthenticated and does not issue redundant deauth'

echo "ALL $PASS AFTER-QUOTA FUNCTIONAL TESTS PASSED"
