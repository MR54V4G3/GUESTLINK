#!/bin/sh
# Isolated tests for the recurring auto-renew scheduler and quota reset path.
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
T="$(mktemp -d /tmp/guest-auto-renew.XXXXXX)"
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin"
for f in auto-renew.sh quota-manager.sh policy-lib.sh; do cp "$HERE/$f" "$T/$f"; done
chmod 700 "$T"/*.sh

cat > "$T/bin/date" <<'MOCK_DATE'
#!/bin/sh
case "${1:-}" in
    +%s) echo "$TEST_NOW" ;;
    +%F) echo "$TEST_DATE" ;;
    *) exec /bin/date "$@" ;;
esac
MOCK_DATE
cat > "$T/bin/logger" <<'MOCK_LOGGER'
#!/bin/sh
printf '%s\n' "$*" >> "$TEST_LOG"
exit 0
MOCK_LOGGER
chmod 700 "$T/bin/"*
export PATH="$T/bin:$PATH" QUOTA_DIR="$T" TEST_NOW=1793577600 TEST_DATE=2026-11-02 TEST_LOG="$T/worker.log"

HEADER='# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION'
printf '%s\n' "$HEADER" > "$T/packages.tsv"
: > "$T/packages.lock"
: > "$T/accounting.lock"

DUE=02:00:00:00:cc:01
CATCHUP=02:00:00:00:cc:02
DISABLED=02:00:00:00:cc:03
PENDING=02:00:00:00:cc:04
ONETIME=02:00:00:00:cc:05
NOW="$TEST_NOW"
PERIOD=$((30*86400))
EXP1=$((NOW-2*86400))
START1=$((EXP1-PERIOD))
EXP2=$((NOW-65*86400))
START2=$((EXP2-PERIOD))

add_account() {
    MAC="$1" STATUS="$2"
    # Quota columns are KiB limits followed by byte usage counters.
    printf '%s\t-\t1048576\t512000\t1234567\t765432\t2026-10-01\t%s\t1\t-\t1000\t2000\n' \
        "$MAC" "$STATUS" >> "$T/accounts.tsv"
}
: > "$T/accounts.tsv"
add_account "$DUE" active
add_account "$CATCHUP" active
add_account "$DISABLED" disabled
add_account "$PENDING" active
add_account "$ONETIME" active

printf '%s\t30\t%s\t%s\t64\t512\tauto_renew\t0\tactive\t32\t64\tthrottle\n' "$DUE" "$START1" "$EXP1" >> "$T/packages.tsv"
printf '%s\t30\t%s\t%s\t64\t512\tauto_renew\t1\tactive\t32\t64\tdisconnect\n' "$CATCHUP" "$START2" "$EXP2" >> "$T/packages.tsv"
printf '%s\t30\t%s\t%s\t64\t512\tauto_renew\t0\tactive\t32\t64\tdisconnect\n' "$DISABLED" "$START1" "$EXP1" >> "$T/packages.tsv"
printf '%s\t30\t0\t0\t64\t512\tauto_renew\t0\tpending\t32\t64\tdisconnect\n' "$PENDING" >> "$T/packages.tsv"
printf '%s\t30\t%s\t%s\t64\t512\tone_time\t0\tactive\t32\t64\tdisconnect\n' "$ONETIME" "$START1" "$EXP1" >> "$T/packages.tsv"

pass_count=0
fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; pass_count=$((pass_count+1)); }
package_field() { awk -F '\t' -v m="$1" -v n="$2" '$1==m {print $n;exit}' "$T/packages.tsv"; }
account_field() { awk -F '\t' -v m="$1" -v n="$2" '$1==m {print $n;exit}' "$T/accounts.tsv"; }

"$T/auto-renew.sh" > "$T/run.out"
[ "$(package_field "$DUE" 3)" = "$EXP1" ] || fail 'first renewal did not set start to the prior expiry boundary'
[ "$(package_field "$DUE" 4)" = "$((EXP1+PERIOD))" ] || fail 'first renewal did not advance expiry by 30 days'
[ "$(account_field "$DUE" 5)" = 0 ] && [ "$(account_field "$DUE" 6)" = 0 ] || fail 'first renewal did not reset separate download and upload usage'
[ "$(account_field "$DUE" 7)" = "$TEST_DATE" ] || fail 'quota reset date was not updated'
[ "$(account_field "$DUE" 9)" = 0 ] || fail 'renewal did not clear the exhausted-quota block'
[ "$(package_field "$DUE" 8)" = 0 ] || fail 'renewal unexpectedly changed per-account free-data setting'
pass 'due package renews both independent quota counters and preserves package settings'

EXPECTED_CATCH_START=$((EXP2+2*PERIOD))
EXPECTED_CATCH_EXP=$((EXP2+3*PERIOD))
[ "$(package_field "$CATCHUP" 3)" = "$EXPECTED_CATCH_START" ] || fail 'offline catch-up did not advance to the current billing period start'
[ "$(package_field "$CATCHUP" 4)" = "$EXPECTED_CATCH_EXP" ] || fail 'offline catch-up did not choose the next future period boundary'
[ "$EXPECTED_CATCH_EXP" -gt "$NOW" ] || fail 'catch-up expiry is not in the future'
[ "$(account_field "$CATCHUP" 5)" = 0 ] && [ "$(account_field "$CATCHUP" 6)" = 0 ] || fail 'catch-up did not reset usage'
pass 'multi-period router downtime is caught up with one quota reset and a future expiry'

[ "$(package_field "$DISABLED" 4)" = "$EXP1" ] || fail 'disabled account package was auto-renewed'
[ "$(account_field "$DISABLED" 8)" = disabled ] || fail 'auto-renew reactivated a disabled account'
[ "$(package_field "$PENDING" 9)" = pending ] || fail 'pending package status changed'
[ "$(package_field "$ONETIME" 4)" = "$EXP1" ] || fail 'one-time package was automatically renewed'
pass 'disabled accounts, pending packages and one-time packages are not automatically renewed'

# Run a second time after adding usage: the already-advanced expiries are not due,
# so the worker must not reset the newly accumulated traffic again.
awk -F '\t' -v OFS='\t' -v m="$DUE" '$1==m {$5=9876;$6=5432} {print}' "$T/accounts.tsv" > "$T/accounts.tmp"
mv "$T/accounts.tmp" "$T/accounts.tsv"
BEFORE_EXP="$(package_field "$DUE" 4)"
"$T/auto-renew.sh" > "$T/run2.out"
[ "$(package_field "$DUE" 4)" = "$BEFORE_EXP" ] || fail 'second worker pass advanced a not-yet-due expiry'
[ "$(account_field "$DUE" 5)" = 9876 ] && [ "$(account_field "$DUE" 6)" = 5432 ] || fail 'second worker pass reset usage twice'
pass 'repeated once-per-minute runs are idempotent between expiry boundaries'

echo "ALL $pass_count AUTOMATIC RENEWAL CHECKS PASSED"
