#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
T=$(mktemp -d /tmp/guest-ndsctl-retry.XXXXXX)
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T/bin"
cp "$HERE/policy-lib.sh" "$T/policy-lib.sh"
cat > "$T/bin/ndsctl" <<'MOCK'
#!/bin/sh
count=0
[ ! -f "$NDS_CALL_COUNT" ] || count=$(cat "$NDS_CALL_COUNT")
count=$((count + 1))
printf '%s\n' "$count" > "$NDS_CALL_COUNT"
if [ "$count" -le "${NDS_BUSY_UNTIL:-0}" ]; then
    echo 'ndsctl thread is busy, please try later.'
    exit 4
fi
if [ "${NDS_FAIL_CODE:-0}" -ne 0 ]; then
    echo 'mock non-busy failure'
    exit "$NDS_FAIL_CODE"
fi
case "$1" in
    status) echo 'Managed interface: br-guest' ;;
    json) printf '{"mac":"%s","state":"Preauthenticated"}\n' "${2:-}" ;;
    *) echo "mock command $*" ;;
esac
exit 0
MOCK
chmod 700 "$T/bin/ndsctl"
fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

# Two busy responses must be retried; the third response is returned intact.
rm -f "$T/count"
OUT=$(PATH="$T/bin:$PATH" NDS_CALL_COUNT="$T/count" NDS_BUSY_UNTIL=2 \
    GUEST_NDSCTL_RETRIES=5 GUEST_NDSCTL_RETRY_DELAY=0 \
    QUOTA_DIR="$T" /bin/sh -c '. "$1"; policy_ndsctl json 02:00:00:00:00:01' sh "$T/policy-lib.sh")
printf '%s' "$OUT" | grep -Fq '"state":"Preauthenticated"' || fail 'successful JSON output was not returned after a busy retry'
[ "$(cat "$T/count")" = 3 ] || fail 'busy command was not retried exactly until success'
pass 'exit code 4 is retried and a later successful client lookup is returned'

# Exhaustion returns 4, not success and not a misleading missing-client result.
rm -f "$T/count"
if PATH="$T/bin:$PATH" NDS_CALL_COUNT="$T/count" NDS_BUSY_UNTIL=9 \
    GUEST_NDSCTL_RETRIES=3 GUEST_NDSCTL_RETRY_DELAY=0 \
    QUOTA_DIR="$T" /bin/sh -c '. "$1"; policy_ndsctl json 02:00:00:00:00:01' sh "$T/policy-lib.sh" >"$T/out" 2>"$T/err"; then
    fail 'permanently busy ndsctl incorrectly returned success'
else
    rc=$?
fi
[ "$rc" -eq 4 ] || fail "busy exhaustion returned $rc instead of 4"
[ "$(cat "$T/count")" = 3 ] || fail 'retry count did not respect configured maximum'
grep -Fq 'no client state was assumed' "$T/err" || fail 'busy exhaustion did not report the safe failure reason'
pass 'persistent contention fails closed after the configured retry limit'

# Errors other than 4 are not retried or rewritten.
rm -f "$T/count"
if PATH="$T/bin:$PATH" NDS_CALL_COUNT="$T/count" NDS_BUSY_UNTIL=0 NDS_FAIL_CODE=5 \
    GUEST_NDSCTL_RETRIES=5 GUEST_NDSCTL_RETRY_DELAY=0 \
    QUOTA_DIR="$T" /bin/sh -c '. "$1"; policy_ndsctl status' sh "$T/policy-lib.sh" >"$T/out" 2>"$T/err"; then
    fail 'non-busy error incorrectly returned success'
else
    rc=$?
fi
[ "$rc" -eq 5 ] || fail "non-busy error returned $rc instead of 5"
[ "$(cat "$T/count")" = 1 ] || fail 'non-busy error was retried'
pass 'non-busy ndsctl errors preserve their original exit status without retries'

# The accounting poller holds accounting.lock. This single-shot helper must
# return rc=4 immediately instead of sleeping/retrying while that lock is held.
rm -f "$T/count"
if PATH="$T/bin:$PATH" NDS_CALL_COUNT="$T/count" NDS_BUSY_UNTIL=9 \
    GUEST_NDSCTL_RETRIES=5 GUEST_NDSCTL_RETRY_DELAY=0 \
    QUOTA_DIR="$T" /bin/sh -c '. "$1"; policy_ndsctl_once json' sh "$T/policy-lib.sh" >"$T/out" 2>"$T/err"; then
    fail 'single-shot helper incorrectly returned success while ndsctl was busy'
else
    rc=$?
fi
[ "$rc" -eq 4 ] || fail "single-shot helper returned $rc instead of 4"
[ "$(cat "$T/count")" = 1 ] || fail 'single-shot helper retried while its caller may hold accounting.lock'
pass 'accounting-lock callers use a single-shot ndsctl query to avoid lock-order deadlock'

# Exercise the exact portal resume path that previously displayed the false
# "not in client list" message whenever ndsctl returned rc=4.
mkdir -p "$T/manager" "$T/manager/metadata" "$T/accounting"
cp "$HERE/../guest-portal-requests/live-manager.sh" "$T/manager/live-manager.sh"
cp "$T/policy-lib.sh" "$T/accounting/policy-lib.sh"
: > "$T/manager/pending.tsv"
: > "$T/accounting/accounts.tsv"
: > "$T/accounting/packages.tsv"
printf '%s\n' 'AUTO_AUTHENTICATE=1' > "$T/accounting/policy.conf"
chmod 700 "$T/manager/live-manager.sh"
rm -f "$T/count"
if PATH="$T/bin:$PATH" NDS_CALL_COUNT="$T/count" NDS_BUSY_UNTIL=99 \
    GUEST_NDSCTL_RETRIES=5 GUEST_NDSCTL_RETRY_DELAY=0 \
    QUOTA_DIR="$T/accounting" REQUEST_MANAGER_DIR="$T/manager" \
    REQUEST_MANAGER_QUEUE="$T/manager/pending.tsv" \
    /bin/sh "$T/manager/live-manager.sh" resume 02:00:00:00:00:01 >"$T/resume.out" 2>&1; then
    fail 'portal resume incorrectly succeeded while openNDS remained busy'
else
    rc=$?
fi
[ "$rc" -eq 1 ] || fail "portal resume returned $rc instead of a fail-closed error"
grep -Fq 'openNDS control remained busy after retries' "$T/resume.out" || fail 'portal resume did not identify ndsctl contention'
! grep -Fq 'Returning device is not in the openNDS client list' "$T/resume.out" || fail 'portal resume still misreported a busy ndsctl response as a missing client'
[ "$(cat "$T/count")" = 5 ] || fail 'portal resume did not retry the busy client lookup exactly five times'
pass 'portal returning-device resume reports ndsctl contention accurately and does not mislabel a listed client as missing'

echo 'ALL NDSCTL RETRY TESTS PASSED'
