#!/bin/sh
# Reauthorize known guest devices on reconnect without waiting for a captive
# portal splash. It watches neighbour entries on openNDS's managed interface;
# ndsctl auth independently verifies that the IP is on that interface.
set -u

DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
REQUEST_DIR="${REQUEST_MANAGER_DIR:-/root/guest-portal-requests}"
MANAGER="$REQUEST_DIR/live-manager.sh"
LEASES="${DHCP_LEASES_FILE:-/tmp/dhcp.leases}"
LOCK="${RETURN_AUTH_LOCK:-/var/lock/guest-return-auth.lock}"
ATTEMPTS="${RETURN_AUTH_ATTEMPTS:-/tmp/guest-return-auth-attempts.tsv}"
ATTEMPTS_LOCK="${RETURN_AUTH_ATTEMPT_LOCK:-/var/lock/guest-return-auth-attempts.lock}"
INTERVAL="${RETURN_AUTH_INTERVAL:-5}"
COOLDOWN="${RETURN_AUTH_COOLDOWN:-5}"

log() { logger -t guest-return-auth "$*" 2>/dev/null || :; }

attempt_recent() {
    M="$1" NOW="$2"
    LAST="$(awk -F '\t' -v m="$M" '$2==m {v=$1} END {print v+0}' "$ATTEMPTS" 2>/dev/null)"
    [ -n "$LAST" ] || LAST=0
    [ $((NOW - LAST)) -lt "$COOLDOWN" ]
}

record_attempt() {
    M="$1" NOW="$2"
    (
        mkdir -p "$(dirname "$ATTEMPTS_LOCK")" || exit 1
        exec 5>"$ATTEMPTS_LOCK" || exit 1
        flock -x 5 || exit 1
        TMP="$(mktemp "${ATTEMPTS}.XXXXXX")" || exit 1
        awk -F '\t' -v m="$M" '$2!=m {print}' "$ATTEMPTS" 2>/dev/null > "$TMP" || : > "$TMP"
        printf '%s\t%s\n' "$NOW" "$M" >> "$TMP"
        chmod 600 "$TMP" && mv "$TMP" "$ATTEMPTS"
    )
}

process_one() {
    CLIENT_IP="$1"
    printf '%s\n' "$CLIENT_IP" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || return 0
    MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
    case "$MAC" in
        [0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]) ;;
        *) return 0 ;;
    esac
    NOW="$(date +%s 2>/dev/null || echo 0)"
    case "$NOW" in ''|*[!0-9]*) return 0 ;; esac
    policy_return_auth_is_denied "$MAC" && return 0
    attempt_recent "$MAC" "$NOW" && return 0

    if CLIENT_JSON="$(policy_ndsctl_optional json "$MAC" 2>/dev/null)"; then
        :
    else
        NDS_RC=$?
        case "$NDS_RC" in
            4) log "ndsctl busy after retries; skip returning-device scan mac=$MAC"; return 0 ;;
            126|127) log "ndsctl unavailable (exit=$NDS_RC); skip returning-device scan mac=$MAC"; return 0 ;;
            *) CLIENT_JSON="" ;;
        esac
    fi
    CLIENT_MAC="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.mac' 2>/dev/null | head -n 1)"
    CLIENT_STATE="$(printf '%s\n' "$CLIENT_JSON" | jsonfilter -e '@.state' 2>/dev/null | head -n 1)"
    [ "$CLIENT_MAC" = "$MAC" ] && [ "$CLIENT_STATE" = Authenticated ] && return 0

    ACCOUNT_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$DIR/accounts.tsv" 2>/dev/null)"
    if [ -n "$ACCOUNT_ROW" ]; then
        ACCOUNT_STATUS="$(printf '%s\n' "$ACCOUNT_ROW" | awk -F '\t' '{print $8}')"
        [ "$ACCOUNT_STATUS" = active ] || return 0
        PACKAGE_ROW="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$DIR/packages.tsv" 2>/dev/null)"
        if [ -n "$PACKAGE_ROW" ]; then
            P_STATUS="$(printf '%s\n' "$PACKAGE_ROW" | awk -F '\t' '{print $9}')"
            P_EXPIRY="$(printf '%s\n' "$PACKAGE_ROW" | awk -F '\t' '{print $4}')"
            [ "$P_STATUS" = active ] || return 0
            case "$P_EXPIRY" in ''|*[!0-9]*) return 0 ;; esac
            [ "$P_EXPIRY" -gt "$NOW" ] || return 0
        else
            policy_mac_has_pending_request "$MAC" && return 0
            [ "$UNASSIGNED_ACCESS_MODE" = throttle ] || return 0
        fi
    else
        # Unknown devices are untouched unless the separate MAC-enrolment
        # policy is enabled. The manager additionally requires a matching
        # DHCP lease before creating an account (so a static AP management
        # neighbour is not silently enrolled).
        [ "$MAC_AUTO_ENROLL" = 1 ] || return 0
    fi

    case "$CLIENT_STATE" in
        Authenticated) return 0 ;;
        Preauthenticated|"") ;;
        *) return 0 ;;
    esac

    record_attempt "$MAC" "$NOW"
    if [ -n "$CLIENT_STATE" ]; then
        OUT="$(QUOTA_DIR="$DIR" REQUEST_MANAGER_DIR="$REQUEST_DIR" "$MANAGER" resume-preemptive "$MAC" "$CLIENT_IP" "$MANAGED_IFACE" 2>&1)"
    else
        OUT="$(QUOTA_DIR="$DIR" REQUEST_MANAGER_DIR="$REQUEST_DIR" "$MANAGER" resume-preemptive "$MAC" "$CLIENT_IP" "$MANAGED_IFACE" 2>&1)"
    fi
    case "$OUT" in
        RETURN_PREEMPTIVE_PACKAGE_AUTHENTICATED|RETURN_PREEMPTIVE_HOLD_AUTHENTICATED|RETURN_ALREADY_AUTHENTICATED|RETURN_PACKAGE_AUTHENTICATED|RETURN_HOLD_AUTHENTICATED|AUTO_MAC_ENROLLED_LIMITED)
            log "authorized returning guest mac=$MAC ip=$CLIENT_IP result=$OUT"
            ;;
        RETURN_NEW_DEVICE|RETURN_NO_INTERNET|RETURN_ADMIN_ACTION|RETURN_POLICY_BLOCKED)
            :
            ;;
        *)
            [ -n "$OUT" ] && log "returning guest not authenticated mac=$MAC ip=$CLIENT_IP result=$OUT"
            ;;
    esac
}

run_once() {
    . "$DIR/policy-lib.sh" || return 1
    policy_load
    [ "$AUTO_AUTHENTICATE" = 1 ] || return 0
    [ -x "$MANAGER" ] && [ -r "$DIR/accounts.tsv" ] && [ -r "$DIR/packages.tsv" ] || return 1
    command -v ndsctl >/dev/null 2>&1 || return 1
    command -v jsonfilter >/dev/null 2>&1 || return 1
    command -v ip >/dev/null 2>&1 || return 1

    NDS_STATUS="$(policy_ndsctl status 2>/dev/null)" || return 1
    printf '%s\n' "$NDS_STATUS" | grep -Fq 'Preemptive Authentication is Enabled' || return 1
    MANAGED_IFACE="$(printf '%s\n' "$NDS_STATUS" | sed -n 's/^Managed interface: //p' | head -n 1)"
    [ -n "$MANAGED_IFACE" ] || return 1

    ip neigh show dev "$MANAGED_IFACE" 2>/dev/null | awk '
        {
            ip=$1; mac=""; state=$NF
            for (i=1; i<NF; i++) if ($i=="lladdr") {mac=tolower($(i+1)); break}
            if (mac ~ /^([0-9a-f][0-9a-f]:){5}[0-9a-f][0-9a-f]$/ && (state=="REACHABLE" || state=="DELAY"))
                print ip "\t" mac
        }
    ' | while IFS="$(printf '\t')" read -r IP MAC; do
        [ -n "$IP" ] && [ -n "$MAC" ] || continue
        process_one "$IP" "$MAC"
    done
}

case "${1:-once}" in
    once)
        mkdir -p "$(dirname "$LOCK")"
        exec 9>"$LOCK"
        flock -n 9 || exit 0
        run_once
        ;;
    daemon)
        while :; do
            "$0" once || log "returning-device scan failed"
            sleep "$INTERVAL"
        done
        ;;
    *) echo "Usage: $0 {once|daemon}" >&2; exit 2 ;;
esac
