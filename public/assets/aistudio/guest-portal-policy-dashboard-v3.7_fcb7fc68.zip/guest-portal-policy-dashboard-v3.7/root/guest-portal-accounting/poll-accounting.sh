#!/bin/sh

DIR=/root/guest-portal-accounting
. "$DIR/policy-lib.sh" || exit 1
LOCK="$DIR/accounting.lock"

# Run the poller under the accounting lock, then run the enforcer only after
# releasing it. This avoids deadlock when ndsctl deauth invokes BinAuth.
if [ "$1" != "--locked" ]; then
    flock -x "$LOCK" /bin/sh "$0" --locked
    RC=$?
    # The renewal worker takes packages.lock then accounting.lock. It must run
    # only after the poller's accounting lock has been released, and before
    # free-enforcer evaluates package expiry.
    if [ -x "$DIR/auto-renew.sh" ]; then
        "$DIR/auto-renew.sh" || logger -t guest-quota "auto_renew_failed"
    fi
    if [ -x "$DIR/free-enforcer.sh" ]; then
        "$DIR/free-enforcer.sh" || logger -t guest-quota "free_enforcer_failed"
    fi
    exit "$RC"
fi
shift

STATE="$DIR/session-state.tsv"
LEDGER="$DIR/daily-usage.tsv"
TMP="$DIR/session-state.tmp"
TMP2="$DIR/session-state.old.tmp"

umask 077
# Capture the previous state-file mtime before touch; it is the migration
# fallback for existing four-column state rows without a sample epoch.
STATE_MTIME=$(stat -c %Y "$STATE" 2>/dev/null)
touch "$STATE" "$LEDGER" || exit 1
rm -f "$TMP" "$TMP2"
: > "$TMP" || exit 1

NOW=$(date +%s) || exit 1
case "$STATE_MTIME" in ''|*[!0-9]*) STATE_MTIME=$((NOW-60)) ;; esac
today=$(date +%Y-%m-%d) || exit 1

NDS_CLIENTS_JSON="$(policy_ndsctl_once json 2>/dev/null)" || {
    NDS_RC=$?
    logger -t guest-quota "poll_opennds_client_list_failed rc=$NDS_RC; accounting snapshot was not replaced (single-shot while accounting.lock is held)"
    exit "$NDS_RC"
}
printf '%s\n' "$NDS_CLIENTS_JSON" | jsonfilter -e '@.clients.*' |
while IFS= read -r client; do
    mac=$(printf '%s\n' "$client" | jsonfilter -e '@.mac')
    started=$(printf '%s\n' "$client" | jsonfilter -e '@.session_start')
    down=$(printf '%s\n' "$client" | jsonfilter -e '@.download_this_session')
    up=$(printf '%s\n' "$client" | jsonfilter -e '@.upload_this_session')
    state=$(printf '%s\n' "$client" | jsonfilter -e '@.state')

    case "$mac" in
        [0-9a-fA-F][0-9a-fA-F]:*) ;;
        *) continue ;;
    esac
    case "$started:$down:$up" in
        *[!0-9:]*|'') continue ;;
    esac
    [ "$state" = "Authenticated" ] || continue

    down_bytes=$((down * 1024))
    up_bytes=$((up * 1024))

    old=$(awk -F '\t' -v m="$mac" -v s="$started" \
        '$1 == m && $2 == s { print $3 "\t" $4 "\t" $5; exit }' "$STATE")
    if [ -z "$old" ]; then
        old_down=0
        old_up=0
        prev_sample="$STATE_MTIME"
        HAS_OLD=0
    else
        old_down=$(printf '%s\n' "$old" | cut -f1)
        old_up=$(printf '%s\n' "$old" | cut -f2)
        prev_sample=$(printf '%s\n' "$old" | cut -f3)
        case "$prev_sample" in ''|*[!0-9]*) prev_sample="$STATE_MTIME" ;; esac
        HAS_OLD=1
    fi
    [ "$prev_sample" -lt "$started" ] && prev_sample="$started"
    [ "$prev_sample" -gt "$NOW" ] && prev_sample="$NOW"

    if [ -x "$DIR/quota-manager.sh" ]; then
        QUOTA_DIR="$DIR" "$DIR/quota-manager.sh" --locked sample \
            "$mac" "$started" "$down_bytes" "$up_bytes" "$prev_sample" "$NOW" || \
            logger -t guest-quota "poll_sample_failed mac=$mac"
    fi

    if [ "$HAS_OLD" -eq 0 ]; then
        printf '%s\t%s\t%s\t%s\t%s\n' \
            "$mac" "$started" "$down_bytes" "$up_bytes" "$NOW" >> "$TMP"
        printf 'BASELINE %s download=%s upload=%s bytes\n' \
            "$mac" "$down_bytes" "$up_bytes"
        continue
    fi

    delta_down=0
    delta_up=0
    if [ "$down_bytes" -ge "$old_down" ]; then
        delta_down=$((down_bytes - old_down))
    fi
    if [ "$up_bytes" -ge "$old_up" ]; then
        delta_up=$((up_bytes - old_up))
    fi

    if [ "$delta_down" -gt 0 ] || [ "$delta_up" -gt 0 ]; then
        printf '%s\t%s\t%s\t%s\n' \
            "$today" "$mac" "$delta_down" "$delta_up" >> "$LEDGER"
    fi

    printf '%s\t%s\t%s\t%s\t%s\n' \
        "$mac" "$started" "$down_bytes" "$up_bytes" "$NOW" >> "$TMP"

    printf 'RECORDED %s download_delta=%s upload_delta=%s bytes\n' \
        "$mac" "$delta_down" "$delta_up"
done

# Retain state for sessions not currently visible.
awk -F '\t' '
    FILENAME == ARGV[1] { active[$1 SUBSEP $2] = 1; next }
    !(($1 SUBSEP $2) in active) { print }
' "$TMP" "$STATE" > "$TMP2" || exit 1

cat "$TMP2" >> "$TMP" || exit 1
chmod 600 "$TMP"
mv "$TMP" "$STATE" || exit 1
rm -f "$TMP2"
exit 0
