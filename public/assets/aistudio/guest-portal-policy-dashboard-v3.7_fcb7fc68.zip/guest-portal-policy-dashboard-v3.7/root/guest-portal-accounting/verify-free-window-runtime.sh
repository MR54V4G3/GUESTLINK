#!/bin/sh
# Read-only check for free-window enforcement and the configurable policy dashboard.
set -u
DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
CRON_FILE="${QUOTA_CRONTAB:-/etc/crontabs/root}"
DASH="${GUEST_DASHBOARD_CGI:-/srv/guest-dashboard/cgi-bin}"
REQUEST_DIR="${REQUEST_MANAGER_DIR:-/root/guest-portal-requests}"
OPENNDS_LIB="${OPENNDS_LIB_DIR:-/usr/lib/opennds}"
INITD_DIR="${GUEST_INITD_DIR:-/etc/init.d}"
FAILS=0 WARNS=0
pass(){ printf 'PASS: %s\n' "$*"; }
fail(){ printf 'FAIL: %s\n' "$*"; FAILS=$((FAILS+1)); }
warn(){ printf 'WARN: %s\n' "$*"; WARNS=$((WARNS+1)); }

printf '%s\n' '=== Guest policy / free-window runtime verification (read-only) ==='
LOCAL_TIME="$(unset TZ; date '+%Y-%m-%d %H:%M:%S %Z %z' 2>/dev/null || date)"
LOCAL_OFFSET="$(unset TZ; date +%z 2>/dev/null || true)"
printf 'System local time: %s\n' "$LOCAL_TIME"
ZONE="$(uci -q get system.@system[0].zonename 2>/dev/null || true)"
[ "$ZONE" = Asia/Colombo ] && pass 'OpenWrt timezone label is Asia/Colombo' || fail "OpenWrt timezone label is '${ZONE:-unknown}', expected Asia/Colombo"
[ "$LOCAL_OFFSET" = +0530 ] && pass 'system local clock uses Sri Lanka UTC+05:30 offset' || fail "system local UTC offset is '${LOCAL_OFFSET:-unknown}', expected +0530"

for f in quota-manager.sh package-manager.sh package-shaper.sh auto-renew.sh poll-accounting.sh free-enforcer.sh returning-auth.sh session-end.sh policy-lib.sh session-policy.sh; do
    if [ -x "$DIR/$f" ]; then pass "$f exists and is executable"; else fail "$DIR/$f missing or not executable"; fi
done
[ -r "$DIR/policy.conf" ] && pass 'editable policy.conf exists' || fail 'policy.conf is missing'
if [ -r "$DIR/policy.conf" ] && [ -x "$DIR/policy-lib.sh" ]; then
    . "$DIR/policy-lib.sh"
    policy_load
    if policy_valid_time "$FREE_WINDOW_START" && policy_valid_time "$FREE_WINDOW_END" && [ "$FREE_WINDOW_START_MIN" -ne "$FREE_WINDOW_END_MIN" ]; then
        pass "configured free window is $FREE_WINDOW_START–$FREE_WINDOW_END using system local time"
    else
        fail 'configured free-window start/end are invalid or equal'
    fi
    pass "new-package defaults: download=${DEFAULT_DOWNLOAD_MIB}MiB upload=${DEFAULT_UPLOAD_MIB}MiB validity=${DEFAULT_VALIDITY_DAYS}d"
    pass "normal speed defaults: upload=${DEFAULT_UPLOAD_KBPS}kbps download=${DEFAULT_DOWNLOAD_KBPS}kbps"
    pass "after-quota defaults: action=$DEFAULT_AFTER_QUOTA_ACTION upload=${DEFAULT_AFTER_UPLOAD_KBPS}kbps download=${DEFAULT_AFTER_DOWNLOAD_KBPS}kbps"
    pass "request policy: auto_approve=$AUTO_APPROVE_REQUESTS auto_auth=$AUTO_AUTHENTICATE unassigned=$UNASSIGNED_ACCESS_MODE ${UNASSIGNED_RATE_KBPS}kbps activation=$PACKAGE_ACTIVATION_MODE MAC_auto_enroll=$MAC_AUTO_ENROLL"
else
    :
fi

if [ -x "$DIR/poll-accounting.sh" ] && grep -q 'free-enforcer.sh' "$DIR/poll-accounting.sh"; then
    pass 'poll-accounting.sh invokes free-enforcer.sh after accounting'
else
    fail 'poll-accounting.sh is not connected to free-enforcer.sh'
fi
HEADER='# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION'
if [ -f "$DIR/packages.tsv" ] && [ "$(sed -n '1p' "$DIR/packages.tsv")" = "$HEADER" ]; then
    pass 'packages.tsv uses the v3 per-account package and after-quota schema'
else
    fail 'packages.tsv is missing or has an unexpected v3 schema header'
fi
if [ -f "$DIR/packages.tsv" ] && awk -F '\t' '
    NR==1 {next}
    /^#/ || NF==0 {next}
    NF!=12 {bad=1; exit 1}
    $10 !~ /^[0-9]+$/ || $11 !~ /^[0-9]+$/ || ($12!="throttle" && $12!="disconnect") {bad=1; exit 1}
    END {if (bad) exit 1}
' "$DIR/packages.tsv"; then
    pass 'all package rows contain valid after-quota rates and action values'
else
    fail 'one or more package rows are malformed or missing after-quota fields'
fi

if [ -x "$DIR/auto-renew.sh" ] && grep -q 'auto-renew.sh' "$DIR/poll-accounting.sh" && grep -q 'free-enforcer.sh' "$DIR/poll-accounting.sh"; then
    if awk '/auto-renew\.sh/ {a=NR} /free-enforcer\.sh/ {f=NR} END {exit !(a>0 && f>a)}' "$DIR/poll-accounting.sh"; then
        pass 'automatic renewal runs after accounting lock release and before package expiry enforcement'
    else
        fail 'automatic renewal is not ordered before package expiry enforcement'
    fi
else
    fail 'automatic renewal worker is missing or not connected to poll-accounting.sh'
fi

if [ -x "$DIR/package-shaper.sh" ] && command -v tc >/dev/null 2>&1; then
    if "$DIR/package-shaper.sh" check >/dev/null 2>&1; then
        pass 'per-client package shaper recognizes the existing SQM HTB/IFB hierarchy without modifying it'
    else
        fail 'per-client package shaper cannot verify the current SQM HTB/IFB hierarchy'
    fi
else
    fail 'package-shaper.sh or tc is unavailable'
fi

if [ -x "$INITD_DIR/guest-return-auth" ] && /bin/sh -n "$INITD_DIR/guest-return-auth"; then
    pass 'guest-return-auth init service is installed (installer preserves its existing enabled/running state)'
else
    fail 'guest-return-auth init service is missing or invalid'
fi
NDS_STATUS="$(policy_ndsctl status 2>/dev/null || true)"
if grep -q '^policy_ndsctl()' "$DIR/policy-lib.sh" && grep -q 'P_NDSCTL_RC.*-ne 4' "$DIR/policy-lib.sh"; then
    pass 'shared ndsctl helper retries only the openNDS busy exit code'
else
    fail 'shared ndsctl busy retry helper is missing or does not target exit code 4'
fi
if grep -q 'policy_ndsctl_once json' "$DIR/poll-accounting.sh"; then
    pass 'accounting poller uses a single-shot ndsctl query while accounting.lock is held'
else
    fail 'accounting poller may wait/retry ndsctl while holding accounting.lock'
fi
if printf '%s\n' "$NDS_STATUS" | grep -Fq 'Preemptive Authentication is Enabled'; then
    pass 'openNDS preemptive authentication is enabled for seamless returning-device login'
else
    fail 'openNDS preemptive authentication is not enabled; returning-device watcher cannot authorize before portal detection'
fi
MANAGED_IFACE="$(printf '%s\n' "$NDS_STATUS" | sed -n 's/^Managed interface: //p' | head -n 1)"
[ -n "$MANAGED_IFACE" ] && pass "returning-device watcher uses openNDS managed interface: $MANAGED_IFACE" || fail 'openNDS managed interface is unavailable'
if [ -r "$DIR/policy-lib.sh" ] && grep -q 'policy_mac_has_pending_request' "$DIR/policy-lib.sh" && grep -q 'policy_mac_has_pending_request' "$DIR/returning-auth.sh"; then
    pass 'returning-device watcher will not bypass a still-pending manual approval request'
else
    fail 'pending-request approval guard is missing from the returning-device watcher'
fi
if [ -x "$DIR/returning-auth.sh" ] && grep -q 'policy_return_auth_is_denied' "$DIR/returning-auth.sh"; then
    pass 'returning-device watcher honours administrator disconnect/delete suppression'
else
    fail 'returning-device watcher does not honour administrator return-deny markers'
fi
if [ -x "$REQUEST_DIR/live-manager.sh" ] && grep -q 'rejected_request' "$REQUEST_DIR/live-manager.sh"; then
    pass 'manually rejected requests suppress automatic returning-device authentication'
else
    fail 'request rejection does not set the automatic return-auth denial marker'
fi

if command -v flock >/dev/null 2>&1 && command -v ndsctl >/dev/null 2>&1 && command -v jsonfilter >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
    pass 'flock, ndsctl, jsonfilter and jq are available'
else
    fail 'one or more required commands (flock, ndsctl, jsonfilter, jq) are unavailable'
fi
BINAUTH="$(printf '%s\n' "$NDS_STATUS" | sed -n 's/^Binauth Script: //p' | head -n 1)"
if [ -n "$BINAUTH" ] && [ -r "$BINAUTH" ] && grep -q 'session-end.sh' "$BINAUTH"; then
    pass "openNDS BinAuth ($BINAUTH) calls session-end.sh"
else
    fail 'could not verify session-end.sh integration in active openNDS BinAuth'
fi

for f in live-manager.sh submit-request.sh; do
    if [ -x "$REQUEST_DIR/$f" ]; then pass "request workflow $f exists and is executable"; else fail "request workflow $REQUEST_DIR/$f missing or not executable"; fi
done
if [ -x "$REQUEST_DIR/live-manager.sh" ] && grep -q 'ACTION = resume\|ACTION" = resume\|ACTION.*resume' "$REQUEST_DIR/live-manager.sh" && grep -q 'return_manager.*live-manager.sh' "$OPENNDS_LIB/theme_guest-approval-requests.sh" && grep -q 'resume' "$OPENNDS_LIB/theme_guest-approval-requests.sh"; then
    pass 'returning-device lookup is connected to the initial captive-portal splash'
else
    fail 'returning-device login is not connected to the captive-portal splash'
fi
if [ -x "$REQUEST_DIR/live-manager.sh" ] && grep -q 'delete-device' "$REQUEST_DIR/live-manager.sh" && grep -q 'delete_device' "$DASH/requests" && grep -q 'Permanently delete portal records' "$DASH/requests" && grep -q 'function decode' "$DASH/requests"; then
    pass 'portal-only permanent deletion is connected and URL-decodes browser-encoded MAC addresses'
else
    fail 'portal-only permanent deletion is missing from the Requests dashboard or manager'
fi
if [ -x "$REQUEST_DIR/live-manager.sh" ] && grep -q 'revoke-device' "$REQUEST_DIR/live-manager.sh" && grep -q 'restore-device' "$REQUEST_DIR/live-manager.sh" && grep -q 'Revoke access — keep history' "$DASH/requests" && grep -q 'Restore approval' "$DASH/requests"; then
    pass 'Requests dashboard offers preserve-history revoke and restore actions'
else
    fail 'preserve-history revoke/restore actions are missing from the Requests dashboard or manager'
fi
if [ -x "$REQUEST_DIR/live-manager.sh" ] && grep -q 'ACTION.*auto-enroll' "$REQUEST_DIR/live-manager.sh" && grep -q 'auto-enroll' "$OPENNDS_LIB/theme_guest-approval-requests.sh" && grep -q 'MAC_AUTO_ENROLL' "$DIR/policy-lib.sh"; then
    pass 'automatic MAC enrollment is connected to Policy and the openNDS new-device path'
else
    fail 'automatic MAC enrollment is missing from Policy, manager or openNDS theme'
fi
if [ -x "$OPENNDS_LIB/theme_guest-approval-requests.sh" ] && grep -q 'AUTO_APPROVED_LIMITED' "$OPENNDS_LIB/theme_guest-approval-requests.sh"; then
    pass 'openNDS request splash reports the automatic approval/holding-speed result'
else
    fail 'openNDS request splash is not connected to automatic request handling'
fi
if [ -r "$OPENNDS_LIB/theme_guest-approval-requests.sh" ] && grep -q 'live-manager.sh promo' "$OPENNDS_LIB/theme_guest-approval-requests.sh" && ! grep -q 'auth_log' "$OPENNDS_LIB/theme_guest-approval-requests.sh"; then
    pass 'promo-code entry is routed through the shared access-policy manager without direct auth_log'
else
    fail 'promo-code entry may bypass the shared access-policy manager'
fi
if [ -r "$DASH/requests" ] && grep -q 'Connected device inventory' "$DASH/requests" && grep -q 'DHCP device name' "$DASH/requests" && grep -q 'Assign package' "$DASH/requests"; then
    pass 'Requests dashboard includes connected-device inventory, DHCP names and quick package assignment'
else
    fail 'connected-device inventory or quick package assignment is missing'
fi
if [ -r "$DASH/packages" ] && grep -q 'PREFILL_MAC' "$DASH/packages" && grep -q 'selected' "$DASH/packages"; then
    pass 'Packages page supports direct preselection from the device inventory'
else
    fail 'Packages page does not support device-to-package preselection'
fi

for page in requests packages quotas policy; do
    if [ -x "$DASH/$page" ]; then pass "dashboard page $page exists and is executable"; else fail "dashboard page $DASH/$page missing or not executable"; fi
done
if [ -r "$DASH/requests" ] && [ -r "$DASH/packages" ] && [ -r "$DASH/quotas" ]; then
    grep -q '/cgi-bin/policy' "$DASH/requests" && grep -q '/cgi-bin/policy' "$DASH/packages" && grep -q '/cgi-bin/policy' "$DASH/quotas" \
        && pass 'Requests, Packages and Quotas pages link to Policy' || fail 'Policy navigation link is missing from one or more pages'
fi
if [ -r "$DASH/packages" ] && grep -q 'package-editor' "$DASH/packages" && grep -q 'action" value="remove' "$DASH/packages"; then
    pass 'Packages page includes edit and remove controls for assigned packages'
else
    fail 'Packages page is missing assigned-package edit/remove controls'
fi
if [ -r "$DASH/packages" ] && grep -q 'after_upload_kbps' "$DASH/packages" && grep -q 'after_download_kbps' "$DASH/packages" && grep -q 'after_quota_action' "$DASH/packages"; then
    pass 'Packages page exposes separate after-quota upload/download rates and action controls'
else
    fail 'Packages page is missing one or more after-quota controls'
fi
if [ -r "$DASH/policy" ] && grep -q 'auto_approve_requests' "$DASH/policy" && grep -q 'auto_authenticate' "$DASH/policy" && grep -q 'unassigned_access_mode' "$DASH/policy"; then
    pass 'Policy page exposes request approval, auto-authentication and unassigned-access controls'
else
    fail 'Policy page is missing request/access controls'
fi
if [ -r "$DASH/policy" ] && grep -q 'default_after_upload_kbps' "$DASH/policy" && grep -q 'default_after_download_kbps' "$DASH/policy" && grep -q 'default_after_quota_action' "$DASH/policy"; then
    pass 'Policy page exposes defaults for after-quota upload/download rates and throttle/disconnect action'
else
    fail 'Policy page is missing after-quota default controls'
fi
if [ -r "$DIR/session-end.sh" ] && grep -q 'quota_deauth_callback_ignored_for_throttle_package' "$DIR/session-end.sh"; then
    pass 'BinAuth quota callback preserves throttle-mode sessions without setting disconnect lock'
else
    fail 'session-end.sh is missing throttle-mode quota callback handling'
fi

ACTIVE_FREE=0
[ -r "$DIR/packages.tsv" ] && ACTIVE_FREE="$(awk -F '\t' '$8==1 && $9=="active" {n++} END {print n+0}' "$DIR/packages.tsv")"
printf 'Active free-window packages: %s\n' "$ACTIVE_FREE"
AUTO_RENEW=0
[ -r "$DIR/packages.tsv" ] && AUTO_RENEW="$(awk -F '\t' '$7=="auto_renew" && $9=="active" {n++} END {print n+0}' "$DIR/packages.tsv")"
if [ "$AUTO_RENEW" -eq 0 ]; then
    pass 'no active auto-renew packages currently assigned'
else
    pass "$AUTO_RENEW active auto-renew package(s) will be processed by the connected renewal worker"
fi

CRON_OK=0
if [ -r "$CRON_FILE" ] && awk '
    /^[[:space:]]*#/ || NF < 6 { next }
    ($1 == "*" || $1 == "*/1") && $2 == "*" && $3 == "*" && $4 == "*" && $5 == "*" && /poll-accounting\.sh/ { found=1 }
    END { exit !found }
' "$CRON_FILE"; then CRON_OK=1; fi
[ "$CRON_OK" -eq 1 ] && pass 'a once-per-minute poll-accounting.sh cron entry is present' || warn "no once-per-minute poll-accounting.sh entry found in $CRON_FILE; verify another scheduler before enabling free-window packages"
printf '\nSummary: %s failure(s), %s warning(s).\n' "$FAILS" "$WARNS"
[ "$FAILS" -eq 0 ] || exit 1
[ "$WARNS" -eq 0 ] || exit 2
exit 0
