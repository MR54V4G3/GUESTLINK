#!/bin/sh
# Per-client after-quota HTB shaper attached below existing SQM root classes.
# It never replaces SQM root qdiscs, the existing classes, or the existing filters.
set -eu

DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
PKG="$DIR/packages.tsv"
ACCOUNTS="$DIR/accounts.tsv"
MAP="$DIR/package-shaper-map.tsv"
LOCK="$DIR/package-shaper.lock"
ACCOUNT_LOCK="$DIR/accounting.lock"
TC="${TC_BIN:-tc}"
DOWN_DEV="${GUEST_SHAPER_DOWN_DEV:-br-guest}"
UP_DEV="${GUEST_SHAPER_UP_DEV:-ifb4br-guest}"
CLASS_FIRST=16384       # 0x4000; private class-ID range for this script
CLASS_LAST=20479        # 0x4fff
FILTER_PREF=0           # SQM simple.qos currently uses preferences 1..9 and 999

fail() { echo "ERROR: $*" >&2; exit 1; }
valid_mac() { printf '%s\n' "$1" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'; }
valid_rate() { case "$1" in ''|*[!0-9]*) return 1 ;; esac; [ "$1" -le 100000 ] 2>/dev/null; }

require_sqm_tree() {
    command -v "$TC" >/dev/null 2>&1 || fail "tc is not installed"
    DOWN_Q="$("$TC" qdisc show dev "$DOWN_DEV" 2>/dev/null || true)"
    DOWN_C="$("$TC" class show dev "$DOWN_DEV" 2>/dev/null || true)"
    UP_Q="$("$TC" qdisc show dev "$UP_DEV" 2>/dev/null || true)"
    UP_C="$("$TC" class show dev "$UP_DEV" 2>/dev/null || true)"
    printf '%s\n' "$DOWN_Q" | grep -Eq 'qdisc htb 1: root' || fail "$DOWN_DEV does not have the expected SQM HTB root"
    printf '%s\n' "$DOWN_C" | grep -Eq 'class htb 1:1 root' || fail "$DOWN_DEV SQM parent class 1:1 is missing"
    printf '%s\n' "$UP_Q" | grep -Eq 'qdisc htb 1: root' || fail "$UP_DEV does not have the expected SQM HTB root"
    printf '%s\n' "$UP_C" | grep -Eq 'class htb 1:1 root' || fail "$UP_DEV SQM parent class 1:1 is missing"
    INGRESS="$("$TC" filter show dev "$DOWN_DEV" ingress 2>/dev/null || true)"
    printf '%s\n' "$INGRESS" | grep -Fq "$UP_DEV" || fail "$DOWN_DEV ingress is not redirected to $UP_DEV"
    # Refuse to take over any priority-zero filter outside our private handle range.
    for DEV in "$DOWN_DEV" "$UP_DEV"; do
        FILTERS="$("$TC" filter show dev "$DEV" parent 1: 2>/dev/null || true)"
        BAD_PREF0="$(printf '%s\n' "$FILTERS" | awk '
            /pref 0/ {
                # tc prints flower headers and handle lines separately; accept
                # only handles from this scripts reserved 0x4000-0x4fff range.
                if ($0 ~ /flower/ && $0 !~ /handle/) next
                if ($0 ~ /flower/ && $0 ~ /handle 0x4[0-9a-f][0-9a-f][0-9a-f]/) next
                print
            }
        ')"
        [ -z "$BAD_PREF0" ] || fail "$DEV already has a priority-zero filter outside the package-shaper range; refusing to collide"
    done
}

class_hex() { printf '%x' "$1"; }
map_lookup() { awk -F '\t' -v m="$1" '$1==m {print $2;exit}' "$MAP" 2>/dev/null; }

map_allocate_locked() {
    MAC="$1"
    ID="$(map_lookup "$MAC")"
    [ -n "$ID" ] && { printf '%s\n' "$ID"; return 0; }
    N="$CLASS_FIRST"
    while [ "$N" -le "$CLASS_LAST" ]; do
        if ! awk -F '\t' -v n="$N" '$2==n {found=1} END {exit !found}' "$MAP" 2>/dev/null; then
            HEX="$(class_hex "$N")"
            if ! printf '%s\n' "$("$TC" class show dev "$DOWN_DEV" 2>/dev/null || true)" "$("$TC" class show dev "$UP_DEV" 2>/dev/null || true)" | grep -Eiq "class htb 1:${HEX}([[:space:]]|$)"; then
                printf '%s\t%s\n' "$MAC" "$N" >> "$MAP" || return 1
                chmod 600 "$MAP" 2>/dev/null || :
                printf '%s\n' "$N"
                return 0
            fi
        fi
        N=$((N+1))
    done
    return 1
}

filter_delete() {
    DEV="$1"; HEX="$2"
    "$TC" filter del dev "$DEV" parent 1: protocol all pref "$FILTER_PREF" handle "0x$HEX" 2>/dev/null || :
}
class_delete() {
    DEV="$1"; HEX="$2"
    "$TC" class del dev "$DEV" classid "1:$HEX" 2>/dev/null || :
}
clear_id_locked() {
    HEX="$1"
    filter_delete "$DOWN_DEV" "$HEX"
    filter_delete "$UP_DEV" "$HEX"
    class_delete "$DOWN_DEV" "$HEX"
    class_delete "$UP_DEV" "$HEX"
}

clear_locked() {
    MAC="$1"
    ID="$(map_lookup "$MAC")"
    [ -n "$ID" ] || return 0
    HEX="$(class_hex "$ID")"
    clear_id_locked "$HEX"
    TMP="$(mktemp "$DIR/package-shaper-map.tmp.XXXXXX")" || return 1
    awk -F '\t' -v m="$MAC" '$1!=m {print}' "$MAP" > "$TMP" || { rm -f "$TMP"; return 1; }
    chmod 600 "$TMP" && mv "$TMP" "$MAP"
}

ensure_direction() {
    DEV="$1"; PARENT="$2"; HEX="$3"; MAC="$4"; RATE="$5"; MATCH="$6"
    if [ "$RATE" -eq 0 ]; then
        filter_delete "$DEV" "$HEX"
        class_delete "$DEV" "$HEX"
        return 0
    fi
    CLASS_LINE="$("$TC" class show dev "$DEV" 2>/dev/null | grep -E "class htb 1:${HEX}([[:space:]]|$)" | head -n 1 || true)"
    if [ -n "$CLASS_LINE" ]; then
        "$TC" class change dev "$DEV" parent "$PARENT" classid "1:$HEX" htb rate 1kbit ceil "${RATE}kbit" burst 1600b cburst 1600b prio 2 || return 1
    else
        "$TC" class add dev "$DEV" parent "$PARENT" classid "1:$HEX" htb rate 1kbit ceil "${RATE}kbit" burst 1600b cburst 1600b prio 2 || return 1
    fi
    QDISC_LINE="$("$TC" qdisc show dev "$DEV" 2>/dev/null | grep -E "parent 1:${HEX}([[:space:]]|$)" | head -n 1 || true)"
    if [ -z "$QDISC_LINE" ]; then
        "$TC" qdisc add dev "$DEV" parent "1:$HEX" handle "${HEX}:" fq_codel || return 1
    fi
    "$TC" filter replace dev "$DEV" parent 1: protocol all pref "$FILTER_PREF" handle "0x$HEX" flower "$MATCH" "$MAC" classid "1:$HEX" || return 1
}

apply_locked() {
    MAC="$1"; AFTER_UP="$2"; AFTER_DOWN="$3"
    valid_mac "$MAC" || return 1
    valid_rate "$AFTER_UP" || return 1
    valid_rate "$AFTER_DOWN" || return 1
    if [ "$AFTER_UP" -eq 0 ] && [ "$AFTER_DOWN" -eq 0 ]; then
        clear_locked "$MAC"
        return $?
    fi
    require_sqm_tree || return 1
    [ -f "$MAP" ] || : > "$MAP"
    chmod 600 "$MAP" 2>/dev/null || :
    ID="$(map_allocate_locked "$MAC")" || return 1
    HEX="$(class_hex "$ID")"
    # Both directions are sibling classes under the existing 10 Mbps HTB root
    # class 1:1. On IFB this deliberately avoids replacing the existing 1:10
    # class's FQ-CoDel leaf qdisc. The SQM aggregate root cap remains in force.
    if ! ensure_direction "$DOWN_DEV" 1:1 "$HEX" "$MAC" "$AFTER_DOWN" dst_mac; then
        clear_id_locked "$HEX"
        return 1
    fi
    if ! ensure_direction "$UP_DEV" 1:1 "$HEX" "$MAC" "$AFTER_UP" src_mac; then
        clear_id_locked "$HEX"
        return 1
    fi
    logger -t guest-package-shaper "after_quota_shape mac=$MAC upload_kbps=$AFTER_UP download_kbps=$AFTER_DOWN class=$HEX"
}

clear_mac() {
    MAC="$1"
    valid_mac "$MAC" || return 1
    mkdir -p "$DIR"
    exec 9>"$LOCK"
    flock -x 9
    clear_locked "$MAC" || return 1
    echo "Removed package shaper for $MAC"
}

apply_mac() {
    MAC="$1"; UP="$2"; DOWN="$3"
    valid_mac "$MAC" || return 1
    valid_rate "$UP" || return 1
    valid_rate "$DOWN" || return 1
    mkdir -p "$DIR"
    exec 9>"$LOCK"
    flock -x 9
    apply_locked "$MAC" "$UP" "$DOWN" || { echo "Could not apply per-client HTB limits for $MAC; SQM hierarchy was not replaced" >&2; return 1; }
    echo "Applied after-quota shaping for $MAC (upload=${UP} kbps, download=${DOWN} kbps)"
}

snapshot_rows() {
    NOW="$(date +%s)" || return 1
    FREE_NOW=0
    policy_is_free_now && FREE_NOW=1
    TMP="$(mktemp "$DIR/package-shaper-snapshot.XXXXXX")" || return 1
    exec 8>"$ACCOUNT_LOCK"
    flock -x 8 || { rm -f "$TMP"; return 1; }
    cp "$PKG" "$TMP.pkg" 2>/dev/null || { flock -u 8; rm -f "$TMP" "$TMP.pkg"; return 1; }
    cp "$ACCOUNTS" "$TMP.acc" 2>/dev/null || { flock -u 8; rm -f "$TMP" "$TMP.pkg" "$TMP.acc"; return 1; }
    flock -u 8
    awk -F '\t' -v now="$NOW" -v free_now="$FREE_NOW" '
        FNR==NR { if ($1 !~ /^#/ && NF>=12) account[$1]=$0; next }
        $1 !~ /^#/ {
            m=$1
            if (!(m in account)) { print m "\tCLEAR"; next }
            split(account[m], a, "\t")
            free_period=($8==1 && free_now==1)
            valid=($9=="active" && a[8]=="active" && ($4+0)>now && ($7=="one_time" || $7=="auto_renew"))
            exhausted=0
            if (!free_period) {
                if (a[3]!="unlimited" && a[5] >= (a[3]+0)*1024) exhausted=1
                if (a[4]!="unlimited" && a[6] >= (a[4]+0)*1024) exhausted=1
                if (a[9]==1) exhausted=1
            }
            action=$12
            if (!valid || action!="throttle" || !exhausted) print m "\tCLEAR"
            else {
                up=$10; down=$11
                if (up !~ /^[0-9]+$/) up=0
                if (down !~ /^[0-9]+$/) down=0
                print m "\tAPPLY\t" up "\t" down
            }
        }
    ' "$TMP.acc" "$TMP.pkg" > "$TMP.rows" || { rm -f "$TMP" "$TMP.pkg" "$TMP.acc" "$TMP.rows"; return 1; }
    rm -f "$TMP" "$TMP.pkg" "$TMP.acc"
    printf '%s\n' "$TMP.rows"
}

sync_mac() {
    MAC="$1"
    valid_mac "$MAC" || fail "Invalid MAC address"
    [ -f "$PKG" ] && [ -f "$ACCOUNTS" ] || { clear_mac "$MAC"; return 0; }
    ROWS="$(snapshot_rows)" || fail "Could not snapshot package/account records"
    LINE="$(awk -F '\t' -v m="$MAC" '$1==m {print;exit}' "$ROWS")"
    rm -f "$ROWS"
    MODE="$(printf '%s\n' "$LINE" | cut -f2)"
    if [ "$MODE" = APPLY ]; then
        UP="$(printf '%s\n' "$LINE" | cut -f3)"
        DOWN="$(printf '%s\n' "$LINE" | cut -f4)"
        apply_mac "$MAC" "$UP" "$DOWN" || fail "Could not apply after-quota shaping for $MAC"
    else
        clear_mac "$MAC" || fail "Could not clear package shaping for $MAC"
    fi
}

reconcile() {
    [ -f "$PKG" ] && [ -f "$ACCOUNTS" ] || return 0
    ROWS="$(snapshot_rows)" || fail "Could not snapshot package/account records"
    ACTIVE="$(mktemp "$DIR/package-shaper-active.XXXXXX")" || { rm -f "$ROWS"; fail "Could not create active list"; }
    : > "$ACTIVE"
    RC=0
    while IFS="$(printf '\t')" read -r MAC MODE UP DOWN; do
        [ -n "$MAC" ] || continue
        case "$MODE" in
            APPLY)
                printf '%s\n' "$MAC" >> "$ACTIVE"
                if ! apply_mac "$MAC" "$UP" "$DOWN"; then echo "FAILED $MAC"; RC=1; fi
                ;;
            CLEAR)
                if ! clear_mac "$MAC" >/dev/null 2>&1; then RC=1; fi
                ;;
        esac
    done < "$ROWS"
    if [ -f "$MAP" ]; then
        while IFS="$(printf '\t')" read -r MAC ID; do
            [ -n "$MAC" ] || continue
            if ! grep -Fxq "$MAC" "$ACTIVE"; then clear_mac "$MAC" >/dev/null 2>&1 || RC=1; fi
        done < "$MAP"
    fi
    rm -f "$ROWS" "$ACTIVE"
    return "$RC"
}

case "${1:-}" in
    check)
        require_sqm_tree
        echo "SQM HTB/IFB hierarchy is compatible; no root qdisc, existing class, filter, or packet mark was changed."
        ;;
    apply)
        [ "$#" -eq 4 ] || fail "Usage: $0 apply MAC AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS"
        apply_mac "$(printf '%s' "$2" | tr 'A-F' 'a-f')" "$3" "$4" || fail "Could not apply package shaper"
        ;;
    clear)
        [ "$#" -eq 2 ] || fail "Usage: $0 clear MAC"
        clear_mac "$(printf '%s' "$2" | tr 'A-F' 'a-f')" || fail "Could not clear package shaper"
        ;;
    sync)
        [ "$#" -eq 2 ] || fail "Usage: $0 sync MAC"
        . "$DIR/policy-lib.sh"
        policy_load
        sync_mac "$(printf '%s' "$2" | tr 'A-F' 'a-f')"
        ;;
    reconcile)
        . "$DIR/policy-lib.sh"
        policy_load
        reconcile
        ;;
    *)
        echo "Usage: $0 {check|apply MAC UPLOAD_KBPS DOWNLOAD_KBPS|clear MAC|sync MAC|reconcile}" >&2
        exit 2
        ;;
esac
