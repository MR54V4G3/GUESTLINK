#!/bin/sh
# Enforces package expiry, quota disconnect, and per-client after-quota throttling.
# Accounting decisions are snapshotted under accounting.lock; openNDS actions run
# after the lock is released because BinAuth callbacks reacquire that lock.
DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
. "$DIR/policy-lib.sh" || exit 1
policy_load
LOCK="$DIR/accounting.lock"
QM="$DIR/quota-manager.sh"
SHAPER="$DIR/package-shaper.sh"
PKG="$DIR/packages.tsv"
ACCOUNTS="$DIR/accounts.tsv"
[ -f "$PKG" ] && [ -f "$ACCOUNTS" ] && [ -x "$QM" ] || exit 0

NOW="$(date +%s)" || exit 1
FREE_NOW=0
policy_is_free_now && FREE_NOW=1
TMP="$(mktemp "$DIR/free-enforce.XXXXXX")" || exit 1
trap 'rm -f "$TMP" "$TMP.shaper"' EXIT HUP INT TERM

# Output: MAC ACTION AFTER_ACTION AFTER_UPLOAD AFTER_DOWNLOAD
# ACTION is DENY, DISCONNECT, THROTTLE or NORMAL.
flock -x "$LOCK" awk -F '\t' -v now="$NOW" -v free_now="$FREE_NOW" '
    FNR==NR {
        if ($1 !~ /^#/ && NF>=9) package[$1]=$0
        next
    }
    {
        m=$1
        if (!(m in package)) next
        split(package[m], p, "\t")
        after_action=p[12]
        if (after_action!="throttle" && after_action!="disconnect") after_action="disconnect"
        after_up=p[10]; after_down=p[11]
        if (after_up !~ /^[0-9]+$/) after_up=0
        if (after_down !~ /^[0-9]+$/) after_down=0
        free_period=(p[8]=="1" && free_now==1)
        valid=(p[9]=="active" && (p[7]=="one_time" || p[7]=="auto_renew") && (p[4]+0)>now && $8=="active")
        exhausted=0
        if (!free_period) {
            if ($9=="1") exhausted=1
            if ($3!="unlimited" && $5 >= ($3+0)*1024) exhausted=1
            if ($4!="unlimited" && $6 >= ($4+0)*1024) exhausted=1
        }
        if (!valid) print m "\tDENY\t" after_action "\t" after_up "\t" after_down
        else if (free_period || !exhausted) print m "\tNORMAL\t" after_action "\t" after_up "\t" after_down
        else if (after_action=="throttle") print m "\tTHROTTLE\t" after_action "\t" after_up "\t" after_down
        else if (p[8]=="1") print m "\tDISCONNECT\t" after_action "\t" after_up "\t" after_down
        else print m "\tNORMAL\t" after_action "\t" after_up "\t" after_down
    }
' "$PKG" "$ACCOUNTS" > "$TMP" || exit 1

client_state() {
    if J="$(policy_ndsctl_optional json "$1" 2>/dev/null)"; then
        :
    else
        return $?
    fi
    printf '%s\n' "$J" | jsonfilter -e '@.state' 2>/dev/null | head -n 1
}
client_deauth() {
    MAC="$1"
    if STATE="$(client_state "$MAC")"; then
        :
    else
        RC=$?
        [ "$RC" -eq 4 ] && logger -t guest-quota "enforcer_client_lookup_busy mac=$MAC; deauthentication deferred"
        return "$RC"
    fi
    if [ "$STATE" = Authenticated ]; then
        policy_ndsctl deauth "$MAC" >/dev/null 2>&1 || { logger -t guest-quota "enforcer_deauth_failed mac=$MAC"; return 1; }
    fi
    # Preauthenticated already means the client has no authorized session.
    # ndsctl deauth is defined for currently authenticated clients only.
    return 0
}

while IFS="$(printf '\t')" read -r MAC ACTION AFTER_ACTION AFTER_UP AFTER_DOWN; do
    [ -n "$MAC" ] || continue
    case "$ACTION" in
        DENY)
            client_deauth "$MAC" || continue
            [ ! -x "$SHAPER" ] || "$SHAPER" clear "$MAC" >/dev/null 2>&1 || :
            logger -t guest-quota "package_access_denied mac=$MAC (inactive, expired, or disabled)"
            ;;
        DISCONNECT)
            QUOTA_DIR="$DIR" "$QM" block "$MAC" >/dev/null 2>&1 || {
                logger -t guest-quota "enforcer_block_failed mac=$MAC"
                continue
            }
            client_deauth "$MAC" || continue
            [ ! -x "$SHAPER" ] || "$SHAPER" clear "$MAC" >/dev/null 2>&1 || :
            logger -t guest-quota "quota_exhausted_disconnect mac=$MAC"
            ;;
        THROTTLE)
            # Defer clearing a quota lock until package-shaper reconcile has
            # successfully installed the per-client limits below. This keeps
            # a TC failure from briefly returning an exhausted guest to full
            # package speed before the fail-closed block is applied.
            ;;
        NORMAL)
            [ ! -x "$SHAPER" ] || "$SHAPER" clear "$MAC" >/dev/null 2>&1 || :
            if [ "$AFTER_ACTION" = throttle ]; then
                QUOTA_DIR="$DIR" "$QM" unblock "$MAC" >/dev/null 2>&1 || logger -t guest-quota "enforcer_unblock_failed mac=$MAC"
            fi
            ;;
    esac
done < "$TMP"

# Reconcile the persistent class map. This also removes stale classes after a
# package is deleted. Failure is fail-closed: block and deauthenticate each
# package whose after-quota shaper could not be installed.
HAS_THROTTLE="$(awk -F '\t' '$1 !~ /^#/ && $12=="throttle" && $9=="active" {n++} END {print n+0}' "$PKG")"
if [ -x "$SHAPER" ]; then
    if ! "$SHAPER" reconcile > "$TMP.shaper" 2>&1; then
        FAILED_LIST="$(sed -n 's/^FAILED //p' "$TMP.shaper")"
        if [ -z "$FAILED_LIST" ]; then
            # A snapshot or global TC failure may not identify an individual MAC.
            FAILED_LIST="$(awk -F '\t' '$2=="THROTTLE" {print $1}' "$TMP")"
        fi
        printf '%s\n' "$FAILED_LIST" | while IFS= read -r BAD_MAC; do
            [ -n "$BAD_MAC" ] || continue
            QUOTA_DIR="$DIR" "$QM" block "$BAD_MAC" >/dev/null 2>&1 || :
            client_deauth "$BAD_MAC"
            logger -t guest-quota "after_quota_shaper_failed_fail_closed mac=$BAD_MAC"
        done
        [ "$HAS_THROTTLE" = 0 ] || logger -t guest-quota "package_shaper_reconcile_failed"
    else
        # The throttle profile is now confirmed in the kernel. Only now clear
        # any stale quota block, so there is no unshaped-access gap on failure.
        while IFS="$(printf '\t')" read -r MAC ACTION AFTER_ACTION AFTER_UP AFTER_DOWN; do
            [ "$ACTION" = THROTTLE ] || continue
            QUOTA_DIR="$DIR" "$QM" unblock "$MAC" >/dev/null 2>&1 || {
                logger -t guest-quota "enforcer_unblock_failed mac=$MAC"
                client_deauth "$MAC"
            }
        done < "$TMP"
    fi
elif [ "$HAS_THROTTLE" != 0 ]; then
    # New throttle packages are not permitted without the shaper executable.
    while IFS="$(printf '\t')" read -r MAC ACTION AFTER_ACTION AFTER_UP AFTER_DOWN; do
        [ "$ACTION" = THROTTLE ] || continue
        QUOTA_DIR="$DIR" "$QM" block "$MAC" >/dev/null 2>&1 || :
        client_deauth "$MAC"
        logger -t guest-quota "package_shaper_missing_fail_closed mac=$MAC"
    done < "$TMP"
fi
