#!/bin/sh
# Renew active auto_renew packages when their current validity period expires.
# Called by poll-accounting.sh after releasing accounting.lock and before
# free-enforcer.sh. Lock order is packages.lock then accounting.lock, matching
# package-manager.sh -> quota-manager.sh.
set -eu

DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
PKG="$DIR/packages.tsv"
ACCOUNTS="$DIR/accounts.tsv"
QM="$DIR/quota-manager.sh"
PACKAGE_LOCK="$DIR/packages.lock"
ACCOUNT_LOCK="$DIR/accounting.lock"
HEADER='# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION'

log() {
    logger -t guest-auto-renew "$*" 2>/dev/null || :
}

[ -f "$PKG" ] && [ -f "$ACCOUNTS" ] && [ -x "$QM" ] || exit 0
[ "$(sed -n '1p' "$PKG")" = "$HEADER" ] || {
    log "renewal_skipped reason=unexpected_packages_schema"
    exit 1
}

NOW="$(date +%s)" || exit 1
case "$NOW" in ''|*[!0-9]*) log "renewal_skipped reason=invalid_clock"; exit 1 ;; esac
umask 077

DUE_FILE="$(mktemp "$DIR/auto-renew-due.XXXXXX")" || exit 1
PKG_TMP=""
cleanup() {
    rm -f "$DUE_FILE"
    [ -z "$PKG_TMP" ] || rm -f "$PKG_TMP"
}
trap cleanup EXIT HUP INT TERM

# The poller has already released accounting.lock before invoking this script.
# Hold locks in the same order as package-manager.sh to avoid lock inversion.
exec 9>"$PACKAGE_LOCK"
flock -x 9
exec 8>"$ACCOUNT_LOCK"
flock -x 8

awk -F '\t' -v now="$NOW" '
    NR == 1 || $1 ~ /^#/ || NF == 0 { next }
    $7 == "auto_renew" && $9 == "active" &&
    $2 ~ /^[0-9]+$/ && $2 >= 1 && $2 <= 3650 &&
    $4 ~ /^[0-9]+$/ && $4 > 0 && ($4 + 0) <= now {
        print $1 "\t" $2 "\t" $3 "\t" $4
    }
' "$PKG" > "$DUE_FILE" || exit 1

TAB="$(printf '\t')"
while IFS="$TAB" read -r MAC DAYS START EXPIRY; do
    [ -n "$MAC" ] || continue
    case "$MAC" in
        [0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]) ;;
        *) log "renewal_skipped reason=invalid_mac mac=$MAC"; continue ;;
    esac
    case "$DAYS:$EXPIRY" in ''|*[!0-9:]*) log "renewal_skipped reason=invalid_period mac=$MAC"; continue ;; esac
    [ "$DAYS" -ge 1 ] && [ "$DAYS" -le 3650 ] && [ "$EXPIRY" -gt 0 ] || {
        log "renewal_skipped reason=invalid_period mac=$MAC"
        continue
    }

    ACCOUNT_ROW="$(awk -F '\t' -v m="$MAC" '$1 == m { print; exit }' "$ACCOUNTS")"
    ACCOUNT_STATUS="$(printf '%s\n' "$ACCOUNT_ROW" | awk -F '\t' 'NF >= 8 {print $8}')"
    if [ "$ACCOUNT_STATUS" != active ]; then
        log "renewal_skipped reason=account_not_active mac=$MAC status=${ACCOUNT_STATUS:-missing}"
        continue
    fi

    PERIOD=$((DAYS * 86400))
    # Advance from the previous expiry, not from the router's current time.
    # If the router was offline for several periods, skip missed periods and
    # perform one quota reset into the currently applicable billing period.
    CYCLES=$(((NOW - EXPIRY) / PERIOD + 1))
    NEW_START=$((EXPIRY + (CYCLES - 1) * PERIOD))
    NEW_EXPIRY=$((EXPIRY + CYCLES * PERIOD))

    # Prepare the package table before resetting counters. The rename is atomic
    # on the accounting filesystem and the locks prevent concurrent edits.
    PKG_TMP="$(mktemp "$DIR/packages.auto-renew.XXXXXX")" || exit 1
    if ! awk -F '\t' -v OFS='\t' -v m="$MAC" -v s="$NEW_START" -v e="$NEW_EXPIRY" '
        $1 == m && $7 == "auto_renew" && $9 == "active" {
            $3 = s; $4 = e; updated++
        }
        { print }
        END { if (updated != 1) exit 1 }
    ' "$PKG" > "$PKG_TMP"; then
        rm -f "$PKG_TMP"; PKG_TMP=""
        log "renewal_failed reason=package_metadata_prepare mac=$MAC"
        continue
    fi
    chmod 600 "$PKG_TMP"

    # --locked is required because this worker already holds accounting.lock.
    if ! QUOTA_DIR="$DIR" "$QM" --locked renew "$MAC" >/dev/null 2>&1; then
        rm -f "$PKG_TMP"; PKG_TMP=""
        log "renewal_failed reason=quota_reset mac=$MAC"
        continue
    fi

    if mv "$PKG_TMP" "$PKG"; then
        PKG_TMP=""
        log "renewed mac=$MAC days=$DAYS periods_caught_up=$CYCLES new_start=$NEW_START new_expiry=$NEW_EXPIRY"
        printf 'RENEWED %s %s %s\n' "$MAC" "$NEW_START" "$NEW_EXPIRY"
    else
        # A same-filesystem rename should not fail after the staged file has
        # been written. If it does, report loudly; the next run will retry.
        rm -f "$PKG_TMP"; PKG_TMP=""
        log "renewal_failed reason=package_metadata_commit mac=$MAC"
    fi
done < "$DUE_FILE"

exit 0
