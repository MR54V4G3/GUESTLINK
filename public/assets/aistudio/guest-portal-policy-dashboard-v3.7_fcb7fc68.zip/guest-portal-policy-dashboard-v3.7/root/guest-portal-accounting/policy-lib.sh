#!/bin/sh
# Shared policy reader and free-window calculation for STARLINK Guest Portal.
# Values are stored as plain KEY=VALUE lines; all accepted values are validated.

POLICY_FILE="${GUEST_POLICY_FILE:-${QUOTA_DIR:-/root/guest-portal-accounting}/policy.conf}"


# Single-shot command for code that already holds accounting.lock. The
# accounting poller must not sleep while holding that lock: ndsctl deauth can
# hold openNDS's control lock while BinAuth waits for accounting.lock. Returning
# rc=4 immediately lets the poller release accounting.lock and breaks that
# lock-order cycle. Use policy_ndsctl() everywhere else for bounded retries.
policy_ndsctl_once() {
    command -v ndsctl >/dev/null 2>&1 || {
        echo "ERROR: ndsctl is unavailable" >&2
        return 127
    }
    if P_NDSCTL_ONCE_OUTPUT="$(ndsctl "$@" 2>&1)"; then
        P_NDSCTL_ONCE_RC=0
    else
        P_NDSCTL_ONCE_RC=$?
    fi
    if [ "$P_NDSCTL_ONCE_RC" -eq 0 ]; then
        [ -z "$P_NDSCTL_ONCE_OUTPUT" ] || printf '%s\n' "$P_NDSCTL_ONCE_OUTPUT"
        return 0
    fi
    [ -z "$P_NDSCTL_ONCE_OUTPUT" ] || printf '%s\n' "$P_NDSCTL_ONCE_OUTPUT" >&2
    return "$P_NDSCTL_ONCE_RC"
}

# ndsctl is protected by openNDS's global ndsctl.lock. A concurrent command
# returns exit status 4; this means "busy", not "client missing". Retry only
# that transient status and preserve every other exit code.
policy_ndsctl() {
    command -v ndsctl >/dev/null 2>&1 || {
        echo "ERROR: ndsctl is unavailable" >&2
        return 127
    }

    P_NDSCTL_MAX="${GUEST_NDSCTL_RETRIES:-5}"
    P_NDSCTL_DELAY="${GUEST_NDSCTL_RETRY_DELAY:-1}"
    case "$P_NDSCTL_MAX" in ''|*[!0-9]*) P_NDSCTL_MAX=5 ;; esac
    [ "$P_NDSCTL_MAX" -ge 1 ] 2>/dev/null || P_NDSCTL_MAX=5
    case "$P_NDSCTL_DELAY" in ''|*[!0-9.]*|.*|*.*.*) P_NDSCTL_DELAY=1 ;; esac
    [ "$(printf '%s\n' "$P_NDSCTL_MAX" | awk '{print ($1+0)}')" -le 10 ] 2>/dev/null || P_NDSCTL_MAX=10

    P_NDSCTL_TRY=1
    while [ "$P_NDSCTL_TRY" -le "$P_NDSCTL_MAX" ]; do
        if P_NDSCTL_OUTPUT="$(ndsctl "$@" 2>&1)"; then
            P_NDSCTL_RC=0
        else
            P_NDSCTL_RC=$?
        fi
        if [ "$P_NDSCTL_RC" -eq 0 ]; then
            [ -z "$P_NDSCTL_OUTPUT" ] || printf '%s\n' "$P_NDSCTL_OUTPUT"
            return 0
        fi
        if [ "$P_NDSCTL_RC" -ne 4 ]; then
            [ -z "$P_NDSCTL_OUTPUT" ] || printf '%s\n' "$P_NDSCTL_OUTPUT" >&2
            return "$P_NDSCTL_RC"
        fi
        if [ "$P_NDSCTL_TRY" -lt "$P_NDSCTL_MAX" ]; then
            sleep "$P_NDSCTL_DELAY"
        fi
        P_NDSCTL_TRY=$((P_NDSCTL_TRY + 1))
    done

    P_NDSCTL_COMMAND="${1:-unknown}"
    logger -t guest-portal-control "ndsctl_busy_retry_exhausted attempts=$P_NDSCTL_MAX command=$P_NDSCTL_COMMAND" 2>/dev/null || :
    echo "ERROR: openNDS control is busy after $P_NDSCTL_MAX attempts; no client state was assumed." >&2
    return 4
}

# Optional client lookups may legitimately fail when a MAC has not yet been
# added to the openNDS client list (the preemptive-auth path). Preserve that
# historical behaviour for ordinary errors, but never hide rc=4 after retries.
policy_ndsctl_optional() {
    if P_NDSCTL_OPTIONAL_OUTPUT="$(policy_ndsctl "$@")"; then
        [ -z "$P_NDSCTL_OPTIONAL_OUTPUT" ] || printf '%s\n' "$P_NDSCTL_OPTIONAL_OUTPUT"
        return 0
    else
        P_NDSCTL_OPTIONAL_RC=$?
        case "$P_NDSCTL_OPTIONAL_RC" in
            4|126|127) return "$P_NDSCTL_OPTIONAL_RC" ;;
            *) return 0 ;;
        esac
    fi
}

policy_return_auth_attempt_file() {
    printf '%s\n' "${RETURN_AUTH_ATTEMPTS:-/tmp/guest-return-auth-attempts.tsv}"
}

policy_return_auth_clear_attempt() {
    P_ATTEMPT_MAC="$(printf '%s' "${1:-}" | tr 'A-F' 'a-f')"
    printf '%s\n' "$P_ATTEMPT_MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || return 1
    P_ATTEMPT_FILE="$(policy_return_auth_attempt_file)"
    [ -e "$P_ATTEMPT_FILE" ] || return 0
    [ -f "$P_ATTEMPT_FILE" ] && [ ! -L "$P_ATTEMPT_FILE" ] || return 1
    P_ATTEMPT_LOCK="${RETURN_AUTH_ATTEMPT_LOCK:-/var/lock/guest-return-auth-attempts.lock}"
    mkdir -p "$(dirname "$P_ATTEMPT_LOCK")" || return 1
    exec 5>"$P_ATTEMPT_LOCK" || return 1
    flock -x 5 || return 1
    P_ATTEMPT_TMP="$(mktemp "${P_ATTEMPT_FILE}.XXXXXX")" || return 1
    awk -F '\t' -v m="$P_ATTEMPT_MAC" '$2!=m {print}' "$P_ATTEMPT_FILE" > "$P_ATTEMPT_TMP" || { rm -f "$P_ATTEMPT_TMP"; return 1; }
    chmod 600 "$P_ATTEMPT_TMP" && mv "$P_ATTEMPT_TMP" "$P_ATTEMPT_FILE"
}

policy_read_value() {
    [ -r "$POLICY_FILE" ] || return 0
    awk -F= -v key="$1" '$1 == key { sub(/^[^=]*=/, ""); gsub(/[\r\"]/, ""); print; exit }' "$POLICY_FILE" 2>/dev/null
}

policy_valid_uint() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    [ "${#1}" -le 7 ] && [ "$1" -le "$2" ] 2>/dev/null
}

policy_valid_time() {
    printf '%s\n' "$1" | grep -Eq '^([01][0-9]|2[0-3]):[0-5][0-9]$'
}

policy_time_minutes() {
    awk -F: -v t="$1" 'BEGIN { if (t !~ /^[0-9][0-9]:[0-9][0-9]$/) exit 1; print (substr(t,1,2)+0)*60 + (substr(t,4,2)+0) }'
}

# Verify a live neighbour belongs to openNDS's own managed interface before
# allowing a preemptive authorization attempt. ndsctl performs a second,
# independent gateway-interface check when it processes the auth command.
# Return success when this MAC still has a PENDING request. This keeps the
# preemptive watcher from bypassing manual approval for an account enrolled by
# an administrator while its request is waiting in the queue.
policy_mac_has_pending_request() {
    P_REQ_MAC="$(printf '%s' "${1:-}" | tr 'A-F' 'a-f')"
    printf '%s\n' "$P_REQ_MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || return 1
    P_REQ_BASE="${REQUEST_MANAGER_DIR:-/root/guest-portal-requests}"
    P_REQ_QUEUE="${REQUEST_MANAGER_QUEUE:-$P_REQ_BASE/pending.tsv}"
    P_REQ_META="$P_REQ_BASE/metadata"
    [ -f "$P_REQ_QUEUE" ] && [ -d "$P_REQ_META" ] || return 1
    for P_REQ_FILE in "$P_REQ_META"/REQ-*.tsv; do
        [ -f "$P_REQ_FILE" ] && [ ! -L "$P_REQ_FILE" ] || continue
        P_REQ_META_MAC="$(awk -F '\t' 'NR==1 {print tolower($1); exit}' "$P_REQ_FILE")"
        [ "$P_REQ_META_MAC" = "$P_REQ_MAC" ] || continue
        P_REQ_ID="${P_REQ_FILE##*/}"
        P_REQ_ID="${P_REQ_ID%.tsv}"
        P_REQ_STATUS="$(awk -F '\t' -v id="$P_REQ_ID" '$1==id {print $12; exit}' "$P_REQ_QUEUE")"
        [ "$P_REQ_STATUS" = PENDING ] && return 0
    done
    return 1
}

# A manual dashboard disconnect or permanent device deletion must not be
# immediately undone by the background returning-device authenticator.
# This small tombstone list is independent from quota blocked/status fields.
policy_return_auth_deny_file() {
    printf '%s\n' "${GUEST_RETURN_AUTH_DENY_FILE:-${QUOTA_DIR:-/root/guest-portal-accounting}/return-auth-deny.tsv}"
}

policy_return_auth_is_denied() {
    P_DENY_MAC="$(printf '%s' "${1:-}" | tr 'A-F' 'a-f')"
    printf '%s\n' "$P_DENY_MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || return 1
    P_DENY_FILE="$(policy_return_auth_deny_file)"
    [ -f "$P_DENY_FILE" ] || return 1
    awk -F '\t' -v m="$P_DENY_MAC" 'tolower($1)==m {found=1} END {exit !found}' "$P_DENY_FILE"
}

policy_return_auth_mark_denied() {
    P_DENY_MAC="$(printf '%s' "${1:-}" | tr 'A-F' 'a-f')"
    P_DENY_REASON="${2:-administrator}"
    printf '%s\n' "$P_DENY_MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || return 1
    printf '%s\n' "$P_DENY_REASON" | grep -Eq '^[A-Za-z0-9_-]{1,32}$' || return 1
    P_DENY_FILE="$(policy_return_auth_deny_file)"
    P_DENY_DIR="$(dirname "$P_DENY_FILE")"
    mkdir -p "$P_DENY_DIR" || return 1
    exec 6>"$P_DENY_FILE.lock" || return 1
    flock -x 6 || return 1
    P_DENY_TMP="$(mktemp "$P_DENY_FILE.XXXXXX")" || return 1
    if [ -f "$P_DENY_FILE" ]; then
        awk -F '\t' -v m="$P_DENY_MAC" 'tolower($1)!=m {print}' "$P_DENY_FILE" > "$P_DENY_TMP" || { rm -f "$P_DENY_TMP"; return 1; }
    fi
    printf '%s\t%s\t%s\n' "$P_DENY_MAC" "$(date +%s)" "$P_DENY_REASON" >> "$P_DENY_TMP" || { rm -f "$P_DENY_TMP"; return 1; }
    chmod 600 "$P_DENY_TMP" && mv "$P_DENY_TMP" "$P_DENY_FILE"
}

policy_return_auth_clear_denied() {
    P_DENY_MAC="$(printf '%s' "${1:-}" | tr 'A-F' 'a-f')"
    printf '%s\n' "$P_DENY_MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || return 1
    P_DENY_FILE="$(policy_return_auth_deny_file)"
    [ -f "$P_DENY_FILE" ] || return 0
    exec 6>"$P_DENY_FILE.lock" || return 1
    flock -x 6 || return 1
    P_DENY_TMP="$(mktemp "$P_DENY_FILE.XXXXXX")" || return 1
    awk -F '\t' -v m="$P_DENY_MAC" 'tolower($1)!=m {print}' "$P_DENY_FILE" > "$P_DENY_TMP" || { rm -f "$P_DENY_TMP"; return 1; }
    chmod 600 "$P_DENY_TMP" && mv "$P_DENY_TMP" "$P_DENY_FILE"
}

policy_verify_preemptive_neighbour() {
    P_MAC="$(printf '%s' "${1:-}" | tr 'A-F' 'a-f')"
    P_IP="${2:-}"
    P_IFACE="${3:-}"
    printf '%s\n' "$P_MAC" | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || return 1
    printf '%s\n' "$P_IP" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || return 1
    printf '%s\n' "$P_IFACE" | grep -Eq '^[A-Za-z0-9_.:-]{1,32}$' || return 1
    if ! awk -F. 'NF!=4 {exit 1} {for(i=1;i<=4;i++) if($i !~ /^[0-9]+$/ || $i<0 || $i>255) exit 1}' <<EOF_IP
$P_IP
EOF_IP
    then
        return 1
    fi
    P_NDS_STATUS="$(policy_ndsctl status 2>/dev/null)" || return 1
    printf '%s\n' "$P_NDS_STATUS" | grep -Fq 'Preemptive Authentication is Enabled' || return 1
    P_MANAGED="$(printf '%s\n' "$P_NDS_STATUS" | sed -n 's/^Managed interface: //p' | head -n 1)"
    [ "$P_MANAGED" = "$P_IFACE" ] || return 1
    command -v ip >/dev/null 2>&1 || return 1
    ip neigh show dev "$P_IFACE" 2>/dev/null | awk -v ip="$P_IP" -v mac="$P_MAC" '
        $1 == ip {
            seen_mac=""
            for (i=1; i<NF; i++) if ($i == "lladdr") { seen_mac=tolower($(i+1)); break }
            state=$NF
            if (seen_mac == mac && (state == "REACHABLE" || state == "DELAY")) found=1
        }
        END { exit !found }
    '
}

policy_load() {
    # Defaults preserve the current package form and current 00:00–07:00 rule.
    DEFAULT_DOWNLOAD_MIB=1024
    DEFAULT_UPLOAD_MIB=256
    DEFAULT_VALIDITY_DAYS=7
    DEFAULT_UPLOAD_KBPS=64
    DEFAULT_DOWNLOAD_KBPS=512
    DEFAULT_AFTER_UPLOAD_KBPS=32
    DEFAULT_AFTER_DOWNLOAD_KBPS=64
    DEFAULT_AFTER_QUOTA_ACTION=throttle
    DEFAULT_FREE_ENABLED=0
    FREE_WINDOW_START=00:00
    FREE_WINDOW_END=07:00
    DEFAULT_RENEWAL_MODE=one_time
    EXPIRED_ACCOUNT_ACTION=block_until_renewed
    AUTO_APPROVE_REQUESTS=1
    AUTO_AUTHENTICATE=1
    UNASSIGNED_ACCESS_MODE=throttle
    UNASSIGNED_RATE_KBPS=1
    UNASSIGNED_SESSION_MINUTES=1440
    PACKAGE_ACTIVATION_MODE=immediate
    MAC_AUTO_ENROLL=0

    V=$(policy_read_value DEFAULT_DOWNLOAD_MIB); policy_valid_uint "$V" 1048576 && [ "$V" -ge 1 ] && DEFAULT_DOWNLOAD_MIB="$V"
    V=$(policy_read_value DEFAULT_UPLOAD_MIB); policy_valid_uint "$V" 1048576 && [ "$V" -ge 1 ] && DEFAULT_UPLOAD_MIB="$V"
    V=$(policy_read_value DEFAULT_VALIDITY_DAYS); policy_valid_uint "$V" 3650 && [ "$V" -ge 1 ] && DEFAULT_VALIDITY_DAYS="$V"
    V=$(policy_read_value DEFAULT_UPLOAD_KBPS); policy_valid_uint "$V" 100000 && DEFAULT_UPLOAD_KBPS="$V"
    V=$(policy_read_value DEFAULT_DOWNLOAD_KBPS); policy_valid_uint "$V" 100000 && DEFAULT_DOWNLOAD_KBPS="$V"
    V=$(policy_read_value DEFAULT_AFTER_UPLOAD_KBPS); policy_valid_uint "$V" 100000 && DEFAULT_AFTER_UPLOAD_KBPS="$V"
    V=$(policy_read_value DEFAULT_AFTER_DOWNLOAD_KBPS); policy_valid_uint "$V" 100000 && DEFAULT_AFTER_DOWNLOAD_KBPS="$V"
    V=$(policy_read_value DEFAULT_AFTER_QUOTA_ACTION); case "$V" in throttle|disconnect) DEFAULT_AFTER_QUOTA_ACTION="$V" ;; esac
    V=$(policy_read_value DEFAULT_FREE_ENABLED); case "$V" in 0|1) DEFAULT_FREE_ENABLED="$V" ;; esac
    V=$(policy_read_value FREE_WINDOW_START); policy_valid_time "$V" && FREE_WINDOW_START="$V"
    V=$(policy_read_value FREE_WINDOW_END); policy_valid_time "$V" && FREE_WINDOW_END="$V"
    V=$(policy_read_value DEFAULT_RENEWAL_MODE); [ "$V" = one_time ] && DEFAULT_RENEWAL_MODE=one_time
    V=$(policy_read_value EXPIRED_ACCOUNT_ACTION); [ "$V" = block_until_renewed ] && EXPIRED_ACCOUNT_ACTION=block_until_renewed
    V=$(policy_read_value AUTO_APPROVE_REQUESTS); case "$V" in 0|1) AUTO_APPROVE_REQUESTS="$V" ;; esac
    V=$(policy_read_value AUTO_AUTHENTICATE); case "$V" in 0|1) AUTO_AUTHENTICATE="$V" ;; esac
    V=$(policy_read_value UNASSIGNED_ACCESS_MODE); case "$V" in throttle|block) UNASSIGNED_ACCESS_MODE="$V" ;; esac
    V=$(policy_read_value UNASSIGNED_RATE_KBPS); policy_valid_uint "$V" 100000 && [ "$V" -ge 1 ] && UNASSIGNED_RATE_KBPS="$V"
    V=$(policy_read_value UNASSIGNED_SESSION_MINUTES); policy_valid_uint "$V" 10080 && [ "$V" -ge 1 ] && UNASSIGNED_SESSION_MINUTES="$V"
    V=$(policy_read_value PACKAGE_ACTIVATION_MODE); case "$V" in immediate|manual) PACKAGE_ACTIVATION_MODE="$V" ;; esac
    V=$(policy_read_value MAC_AUTO_ENROLL); case "$V" in 0|1) MAC_AUTO_ENROLL="$V" ;; esac

    FREE_WINDOW_START_MIN=$(policy_time_minutes "$FREE_WINDOW_START") || FREE_WINDOW_START_MIN=0
    FREE_WINDOW_END_MIN=$(policy_time_minutes "$FREE_WINDOW_END") || FREE_WINDOW_END_MIN=420
    if [ "$FREE_WINDOW_START_MIN" -eq "$FREE_WINDOW_END_MIN" ]; then
        FREE_WINDOW_START=00:00
        FREE_WINDOW_END=07:00
        FREE_WINDOW_START_MIN=0
        FREE_WINDOW_END_MIN=420
    fi

    SYSTEM_TZ_OFFSET=$(unset TZ; date +%z 2>/dev/null || echo +0000)
    case "$SYSTEM_TZ_OFFSET" in
        [+-][0-9][0-9][0-9][0-9]) ;;
        *) SYSTEM_TZ_OFFSET=+0000 ;;
    esac
    SYSTEM_TZ_OFFSET_SECONDS=$(awk -v z="$SYSTEM_TZ_OFFSET" 'BEGIN { s=substr(z,1,1)=="-"?-1:1; h=substr(z,2,2)+0; m=substr(z,4,2)+0; print s*(h*3600+m*60) }')
}

policy_is_free_now() {
    [ -n "${FREE_WINDOW_START_MIN:-}" ] || policy_load
    CLOCK=$(unset TZ; date +%H%M 2>/dev/null || echo 0000)
    CURRENT_MIN=$(awk -v c="$CLOCK" 'BEGIN { print (substr(c,1,2)+0)*60 + (substr(c,3,2)+0) }')
    if [ "$FREE_WINDOW_START_MIN" -lt "$FREE_WINDOW_END_MIN" ]; then
        [ "$CURRENT_MIN" -ge "$FREE_WINDOW_START_MIN" ] && [ "$CURRENT_MIN" -lt "$FREE_WINDOW_END_MIN" ]
    else
        [ "$CURRENT_MIN" -ge "$FREE_WINDOW_START_MIN" ] || [ "$CURRENT_MIN" -lt "$FREE_WINDOW_END_MIN" ]
    fi
}

policy_bill_bytes() {
    # Args: previous epoch, current epoch, download delta, upload delta.
    # Allocates bytes proportionally to the non-free portion of the interval.
    S="$1" E="$2" BD="$3" BU="$4"
    awk -v s="$S" -v e="$E" -v bd="$BD" -v bu="$BU" \
        -v off="${SYSTEM_TZ_OFFSET_SECONDS:-0}" \
        -v fs="${FREE_WINDOW_START_MIN:-0}" \
        -v fe="${FREE_WINDOW_END_MIN:-420}" ' 
        function mn(a,b) { return a < b ? a : b }
        function mx(a,b) { return a > b ? a : b }
        function charge(s,e,b, dur, first,last,d,ds,de,ov,free,seconds,v) {
            if (e <= s) return b
            dur=e-s
            # Include the preceding local day as well for a window crossing midnight.
            first=int((s+off)/86400)-1
            last=int((e+off)/86400)
            free=0
            for (d=first; d<=last; d++) {
                ds=d*86400-off+fs*60
                de=d*86400-off+fe*60
                if (fe <= fs) de+=86400
                ov=mn(e,de)-mx(s,ds)
                if (ov>0) free+=ov
            }
            seconds=dur-free
            if (seconds < 0) seconds=0
            v=b*seconds/dur
            return int(v+0.999999)
        }
        BEGIN { printf "%.0f %.0f", charge(s,e,bd), charge(s,e,bu) }
    '
}
