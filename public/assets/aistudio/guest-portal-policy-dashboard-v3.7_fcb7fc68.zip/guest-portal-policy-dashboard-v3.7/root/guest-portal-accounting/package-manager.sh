#!/bin/sh
# Guest package manager for OpenWrt/openNDS.
# Stores per-account package settings. Free-window accounting is performed by
# quota-manager.sh; active-session enforcement is run by poll-accounting.sh.
# This script does not install or schedule the accounting poller.
set -eu

DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
. "$DIR/policy-lib.sh" || { echo "ERROR: policy library is missing" >&2; exit 1; }
policy_load
PKG="$DIR/packages.tsv"
LOCK="$DIR/packages.lock"
QM="$DIR/quota-manager.sh"
POLL="$DIR/poll-accounting.sh"
ENFORCER="$DIR/free-enforcer.sh"
SESSION_POLICY="$DIR/session-policy.sh"
HEADER='# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION'

fail() { echo "ERROR: $*" >&2; exit 1; }

clear_return_auth_deny() {
    policy_return_auth_clear_denied "$1" || fail "Could not clear the administrator return block for $1"
}

normalize_mac() {
    printf '%s\n' "$1" | tr 'A-F' 'a-f' | grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'
}

valid_uint() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    [ "$1" -ge 0 ] 2>/dev/null
}

valid_mib() {
    [ "$1" = unlimited ] && return 0
    valid_uint "$1" && [ "$1" -ge 1 ] && [ "$1" -le 1048576 ]
}

valid_rate() {
    valid_uint "$1" && [ "$1" -le 100000 ]
}

check_after_quota_ready() {
    [ "$1" = throttle ] || return 0
    [ -x "$DIR/package-shaper.sh" ] || fail "After-quota throttle requires package-shaper.sh"
    "$DIR/package-shaper.sh" check >/dev/null 2>&1 || fail "After-quota throttle is unavailable: the existing SQM HTB/IFB hierarchy could not be verified"
}

validate_after_rates() {
    AU="$1"; AD="$2"; NORMAL_U="$3"; NORMAL_D="$4"; ACTION="$5"
    valid_rate "$AU" || fail "After-quota upload speed must be 0-100000 kbps"
    valid_rate "$AD" || fail "After-quota download speed must be 0-100000 kbps"
    case "$ACTION" in throttle|disconnect) ;; *) fail "After-quota action must be throttle or disconnect" ;; esac
    # After-quota is a reduced profile: 0 means keep the normal package rate.
    if [ "$ACTION" = throttle ]; then
        [ "$NORMAL_U" -eq 0 ] || [ "$AU" -eq 0 ] || [ "$AU" -le "$NORMAL_U" ] || fail "After-quota upload speed cannot exceed the normal upload speed"
        [ "$NORMAL_D" -eq 0 ] || [ "$AD" -eq 0 ] || [ "$AD" -le "$NORMAL_D" ] || fail "After-quota download speed cannot exceed the normal download speed"
    fi
    check_after_quota_ready "$ACTION"
}

check_files() {
    [ -x "$QM" ] || fail "Quota manager is missing or not executable: $QM"
    [ -f "$PKG" ] || fail "Package file is missing: $PKG"
    [ "$(head -n 1 "$PKG")" = "$HEADER" ] || fail "Unexpected packages.tsv header; no changes made"
}

check_free_window_ready() {
    [ "$1" = "1" ] || return 0
    [ -x "$POLL" ] || fail "Free data cannot be enabled: poll-accounting.sh is missing or not executable"
    [ -x "$ENFORCER" ] || fail "Free data cannot be enabled: free-enforcer.sh is missing or not executable"
    [ -x "$DIR/policy-lib.sh" ] || fail "Free data cannot be enabled: policy-lib.sh is missing or not executable"
    grep -q 'free-enforcer.sh' "$POLL" || fail "Free data cannot be enabled: poll-accounting.sh is not connected to free-enforcer.sh"
}

find_package() {
    awk -F '\t' -v m="$1" '$1 == m { print; found=1; exit } END { if (!found) exit 1 }' "$PKG"
}

write_update() {
    # Args: MAC DAYS START EXPIRY NORMAL_UP NORMAL_DOWN AFTER_UP AFTER_DOWN AFTER_ACTION MODE FREE STATUS
    M="$1" D="$2" S="$3" E="$4" U="$5" DN="$6" AU="$7" AD="$8" A="$9" R="${10}" F="${11}" ST="${12}"
    TMP="$(mktemp "$DIR/packages.tmp.XXXXXX")" || return 1
    awk -F '\t' -v m="$M" '$1 != m { print }' "$PKG" > "$TMP" || { rm -f "$TMP"; return 1; }
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$M" "$D" "$S" "$E" "$U" "$DN" "$R" "$F" "$ST" "$AU" "$AD" "$A" >> "$TMP" || { rm -f "$TMP"; return 1; }
    chmod 600 "$TMP" && mv "$TMP" "$PKG"
}

show_one() {
    ROW="$(find_package "$1")" || { echo "No package for $1"; return 1; }
    OLDIFS="$IFS"; IFS="$(printf '\t')"
    read -r M D S E U DN R F ST AU AD A <<EOF_ROW
$ROW
EOF_ROW
    IFS="$OLDIFS"
    echo "MAC: $M"
    echo "Validity: $D days"
    echo "Starts: ${S:-0} (Unix epoch)"
    echo "Expires: ${E:-0} (Unix epoch)"
    echo "Normal upload speed: $U kbps (0 = unlimited)"
    echo "Normal download speed: $DN kbps (0 = unlimited)"
    echo "After-quota upload speed: $AU kbps (0 = normal package rate)"
    echo "After-quota download speed: $AD kbps (0 = normal package rate)"
    echo "After-quota action: $A"
    echo "Renewal: $R"
    echo "Free data ${FREE_WINDOW_START}-${FREE_WINDOW_END}: $F (1 = enabled)"
    echo "Package status: $ST"
}

[ -d "$DIR" ] || fail "Accounting directory not found: $DIR"
check_files

ACTION="${1:-}"
case "$ACTION" in
    assign)
        [ "$#" -eq 13 ] || fail "Usage: $0 assign MAC PHONE DOWNLOAD_MiB UPLOAD_MiB DAYS NORMAL_UPLOAD_KBPS NORMAL_DOWNLOAD_KBPS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS throttle|disconnect one_time|auto_renew 0|1"
        MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
        normalize_mac "$MAC" || fail "Invalid MAC address"
        PHONE="$3"; DOWN="$4"; UP="$5"; DAYS="$6"; URATE="$7"; DRATE="$8"; AFTER_UP="$9"; AFTER_DOWN="${10}"; AFTER_ACTION="${11}"; MODE="${12}"; FREE="${13}"
        valid_mib "$DOWN" || fail "Invalid download allowance in MiB"
        valid_mib "$UP" || fail "Invalid upload allowance in MiB"
        valid_uint "$DAYS" && [ "$DAYS" -ge 1 ] && [ "$DAYS" -le 3650 ] || fail "Validity must be 1-3650 days"
        valid_rate "$URATE" || fail "Upload speed must be 0-100000 kbps"
        valid_rate "$DRATE" || fail "Download speed must be 0-100000 kbps"
        validate_after_rates "$AFTER_UP" "$AFTER_DOWN" "$URATE" "$DRATE" "$AFTER_ACTION"
        case "$MODE" in one_time|auto_renew) ;; *) fail "Renewal mode must be one_time or auto_renew" ;; esac
        case "$FREE" in 0|1) ;; *) fail "Free period must be 0 (off) or 1 (on)" ;; esac
        check_free_window_ready "$FREE"
        exec 9>"$LOCK"; flock -x 9
        if awk -F '\t' -v m="$MAC" '$1 == m { found=1 } END { exit !found }' "$PKG"; then
            fail "A package already exists for $MAC"
        fi
        QUOTA_DIR="$DIR" "$QM" add "$MAC" "$PHONE" "$DOWN" "$UP"
        NEW_STATUS=pending; NEW_START=0; NEW_EXPIRY=0
        if [ "$PACKAGE_ACTIVATION_MODE" = immediate ]; then
            NEW_START=$(date +%s); NEW_EXPIRY=$((NEW_START + DAYS * 86400)); NEW_STATUS=active
        fi
        write_update "$MAC" "$DAYS" "$NEW_START" "$NEW_EXPIRY" "$URATE" "$DRATE" "$AFTER_UP" "$AFTER_DOWN" "$AFTER_ACTION" "$MODE" "$FREE" "$NEW_STATUS" || fail "Account created, but package metadata could not be saved; do not retry assignment until checked"
        clear_return_auth_deny "$MAC"
        if [ "$NEW_STATUS" = active ]; then
            "$SESSION_POLICY" package "$MAC" || logger -t guest-package "package_active_but_live_apply_failed mac=$MAC"
            echo "Package assigned and ACTIVE for $MAC. Validity started immediately."
        else
            echo "Package assigned in PENDING state for $MAC. Activate it when ready."
        fi
        ;;

    attach)
        [ "$#" -eq 12 ] || fail "Usage: $0 attach MAC DOWNLOAD_MiB UPLOAD_MiB DAYS NORMAL_UPLOAD_KBPS NORMAL_DOWNLOAD_KBPS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS throttle|disconnect one_time|auto_renew 0|1"
        MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"
        normalize_mac "$MAC" || fail "Invalid MAC address"
        DOWN="$3"; UP="$4"; DAYS="$5"; URATE="$6"; DRATE="$7"; AFTER_UP="$8"; AFTER_DOWN="$9"; AFTER_ACTION="${10}"; MODE="${11}"; FREE="${12}"
        valid_mib "$DOWN" || fail "Invalid download allowance in MiB"
        valid_mib "$UP" || fail "Invalid upload allowance in MiB"
        valid_uint "$DAYS" && [ "$DAYS" -ge 1 ] && [ "$DAYS" -le 3650 ] || fail "Validity must be 1-3650 days"
        valid_rate "$URATE" || fail "Upload speed must be 0-100000 kbps"
        valid_rate "$DRATE" || fail "Download speed must be 0-100000 kbps"
        validate_after_rates "$AFTER_UP" "$AFTER_DOWN" "$URATE" "$DRATE" "$AFTER_ACTION"
        case "$MODE" in one_time|auto_renew) ;; *) fail "Renewal mode must be one_time or auto_renew" ;; esac
        case "$FREE" in 0|1) ;; *) fail "Free period must be 0 (off) or 1 (on)" ;; esac
        check_free_window_ready "$FREE"
        exec 9>"$LOCK"; flock -x 9
        if awk -F '\t' -v m="$MAC" '$1 == m { found=1 } END { exit !found }' "$PKG"; then
            fail "A package already exists for $MAC"
        fi
        # quota-manager set preserves existing usage counters.
        QUOTA_DIR="$DIR" "$QM" set "$MAC" "$DOWN" "$UP"
        NEW_STATUS=pending; NEW_START=0; NEW_EXPIRY=0
        if [ "$PACKAGE_ACTIVATION_MODE" = immediate ]; then
            NEW_START=$(date +%s); NEW_EXPIRY=$((NEW_START + DAYS * 86400)); NEW_STATUS=active
        fi
        write_update "$MAC" "$DAYS" "$NEW_START" "$NEW_EXPIRY" "$URATE" "$DRATE" "$AFTER_UP" "$AFTER_DOWN" "$AFTER_ACTION" "$MODE" "$FREE" "$NEW_STATUS" || fail "Quota limits updated, but package metadata could not be saved; inspect before retrying"
        clear_return_auth_deny "$MAC"
        if [ "$NEW_STATUS" = active ]; then
            "$SESSION_POLICY" package "$MAC" || logger -t guest-package "package_active_but_live_apply_failed mac=$MAC"
            echo "Package attached and ACTIVE for $MAC. Existing usage was preserved; validity started now."
        else
            echo "Package settings attached to existing account $MAC. Existing usage was preserved. Package is PENDING until activated."
        fi
        ;;

    activate)
        [ "$#" -eq 2 ] || fail "Usage: $0 activate MAC"
        MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"; normalize_mac "$MAC" || fail "Invalid MAC address"
        exec 9>"$LOCK"; flock -x 9
        ROW="$(find_package "$MAC")" || fail "No package exists for $MAC"
        OLDIFS="$IFS"; IFS="$(printf '\t')"; read -r M D S E U DN R F ST AU AD A <<EOF_ROW
$ROW
EOF_ROW
        IFS="$OLDIFS"
        [ "$ST" = pending ] || fail "Only a pending package can be activated (current status: $ST)"
        START="$(date +%s)"; EXPIRY=$((START + D * 86400))
        write_update "$M" "$D" "$START" "$EXPIRY" "$U" "$DN" "$AU" "$AD" "$A" "$R" "$F" active || fail "Could not activate package"
        clear_return_auth_deny "$MAC"
        "$SESSION_POLICY" package "$MAC" || logger -t guest-package "package_activated_live_apply_failed mac=$MAC"
        echo "Package activated for $MAC. Expiry epoch: $EXPIRY"
        ;;

    renew)
        [ "$#" -eq 2 ] || fail "Usage: $0 renew MAC"
        MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"; normalize_mac "$MAC" || fail "Invalid MAC address"
        exec 9>"$LOCK"; flock -x 9
        ROW="$(find_package "$MAC")" || fail "No package exists for $MAC"
        OLDIFS="$IFS"; IFS="$(printf '\t')"; read -r M D S E U DN R F ST AU AD A <<EOF_ROW
$ROW
EOF_ROW
        IFS="$OLDIFS"
        [ "$ST" != pending ] || fail "Activate the package before renewing it"
        QUOTA_DIR="$DIR" "$QM" renew "$MAC"
        START="$(date +%s)"; EXPIRY=$((START + D * 86400))
        write_update "$M" "$D" "$START" "$EXPIRY" "$U" "$DN" "$AU" "$AD" "$A" "$R" "$F" active || fail "Quota renewed but package metadata update failed; inspect before retrying"
        clear_return_auth_deny "$MAC"
        "$SESSION_POLICY" package "$MAC" || logger -t guest-package "package_renewed_live_apply_failed mac=$MAC"
        echo "Package renewed for $MAC. Existing separate upload/download limits retained; usage reset."
        ;;

    edit)
        [ "$#" -eq 12 ] || fail "Usage: $0 edit MAC DOWNLOAD_MiB UPLOAD_MiB DAYS NORMAL_UPLOAD_KBPS NORMAL_DOWNLOAD_KBPS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS throttle|disconnect one_time|auto_renew 0|1"
        MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"; normalize_mac "$MAC" || fail "Invalid MAC address"
        DOWN="$3"; UP="$4"; DAYS="$5"; URATE="$6"; DRATE="$7"; AFTER_UP="$8"; AFTER_DOWN="$9"; AFTER_ACTION="${10}"; MODE="${11}"; FREE="${12}"
        valid_mib "$DOWN" || fail "Invalid download allowance in MiB"
        valid_mib "$UP" || fail "Invalid upload allowance in MiB"
        valid_uint "$DAYS" && [ "$DAYS" -ge 1 ] && [ "$DAYS" -le 3650 ] || fail "Validity must be 1-3650 days"
        valid_rate "$URATE" || fail "Upload speed must be 0-100000 kbps"
        valid_rate "$DRATE" || fail "Download speed must be 0-100000 kbps"
        validate_after_rates "$AFTER_UP" "$AFTER_DOWN" "$URATE" "$DRATE" "$AFTER_ACTION"
        case "$MODE" in one_time|auto_renew) ;; *) fail "Renewal mode must be one_time or auto_renew" ;; esac
        case "$FREE" in 0|1) ;; *) fail "Free period must be 0 (off) or 1 (on)" ;; esac
        check_free_window_ready "$FREE"
        exec 9>"$LOCK"; flock -x 9
        ROW="$(find_package "$MAC")" || fail "No package exists for $MAC"
        OLDIFS="$IFS"; IFS="$(printf '\t')"
        read -r M OLD_D S E OLD_U OLD_DN OLD_R OLD_F ST OLD_AU OLD_AD OLD_A <<EOF_EDIT
$ROW
EOF_EDIT
        IFS="$OLDIFS"
        # Package edits preserve activation start/status and usage counters. For active
        # packages, validity is recalculated from the original start epoch.
        if [ "$S" -gt 0 ] 2>/dev/null; then E=$((S + DAYS * 86400)); else E=0; fi
        QUOTA_DIR="$DIR" "$QM" set "$MAC" "$DOWN" "$UP"
        write_update "$MAC" "$DAYS" "$S" "$E" "$URATE" "$DRATE" "$AFTER_UP" "$AFTER_DOWN" "$AFTER_ACTION" "$MODE" "$FREE" "$ST" || fail "Limits updated but package metadata save failed; inspect package before retrying"
        clear_return_auth_deny "$MAC"
        if [ "$ST" = active ]; then
            "$ENFORCER" || logger -t guest-package "post_edit_enforcer_failed mac=$MAC"
            "$SESSION_POLICY" package "$MAC" || logger -t guest-package "post_edit_live_apply_failed mac=$MAC"
        fi
        echo "Package edited for $MAC. Usage counters were preserved; expiry is based on the original activation time."
        ;;

    remove)
        [ "$#" -eq 2 ] || fail "Usage: $0 remove MAC"
        MAC="$(printf '%s' "$2" | tr 'A-F' 'a-f')"; normalize_mac "$MAC" || fail "Invalid MAC address"
        exec 9>"$LOCK"; flock -x 9
        find_package "$MAC" >/dev/null || fail "No package exists for $MAC"
        TMP="$(mktemp "$DIR/packages.tmp.XXXXXX")" || fail "Could not prepare package removal"
        awk -F '\t' -v m="$MAC" '$1 != m {print}' "$PKG" > "$TMP" || { rm -f "$TMP"; fail "Could not stage package removal"; }
        chmod 600 "$TMP" && mv "$TMP" "$PKG" || { rm -f "$TMP"; fail "Could not remove package metadata"; }
        "$SESSION_POLICY" hold "$MAC" || logger -t guest-package "package_removed_live_hold_failed mac=$MAC"
        echo "Package removed for $MAC. The quota account and its usage history were kept. The device was moved to the unassigned-access policy."
        ;;

    status)
        shift
        if [ "$#" -eq 1 ]; then
            MAC="$(printf '%s' "$1" | tr 'A-F' 'a-f')"; normalize_mac "$MAC" || fail "Invalid MAC address"
            show_one "$MAC"
        elif [ "$#" -eq 0 ]; then
            while IFS="$(printf '\t')" read -r MAC REST; do
                case "$MAC" in ''|\#*) continue ;; esac
                show_one "$MAC" || true
                echo
            done < "$PKG"
        else
            fail "Usage: $0 status [MAC]"
        fi
        ;;

    *)
        cat <<HELP
Package manager
  $0 assign MAC PHONE DOWNLOAD_MiB UPLOAD_MiB DAYS NORMAL_UP_KBPS NORMAL_DOWN_KBPS AFTER_UP_KBPS AFTER_DOWN_KBPS throttle|disconnect one_time|auto_renew 0|1
  $0 attach MAC DOWNLOAD_MiB UPLOAD_MiB DAYS NORMAL_UP_KBPS NORMAL_DOWN_KBPS AFTER_UP_KBPS AFTER_DOWN_KBPS throttle|disconnect one_time|auto_renew 0|1
  $0 activate MAC
  $0 renew MAC
  $0 edit MAC DOWNLOAD_MiB UPLOAD_MiB DAYS NORMAL_UP_KBPS NORMAL_DOWN_KBPS AFTER_UP_KBPS AFTER_DOWN_KBPS throttle|disconnect one_time|auto_renew 0|1
  $0 remove MAC
  $0 status [MAC]

Use assign for a new account; use attach for an existing quota account (usage is preserved).
Normal speed 0 kbps means unlimited. After-quota speed 0 means keep that direction at the normal package speed.
The after-quota action is either throttle (remain connected at the after-quota speeds) or disconnect.
Existing v2 packages are migrated with disconnect as their after-quota action to preserve their previous behaviour.
Free period 1 means the administrator-configured local-time window is selected for that account.
Per-account free setting:
  0 = charge all traffic against the normal quota, all day.
  1 = exclude the configured free-window hours from the normal quota.

For free-enabled packages, poll-accounting.sh must run every minute. It records
usage through quota-manager.sh and then runs free-enforcer.sh to enforce daytime
quota exhaustion and package expiry. This command does not install that schedule.
one_time packages require administrator renewal. auto_renew packages renew their independent upload and download allowances after each configured validity period.
Package edits preserve usage. Removing a package keeps the underlying quota account.
HELP
        exit 1
        ;;
esac
