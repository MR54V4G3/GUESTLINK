#!/bin/sh

DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
. "$DIR/policy-lib.sh" || { echo "ERROR: policy library is missing" >&2; exit 1; }
policy_load
ACCOUNTS="$DIR/accounts.tsv"
LOCK="$DIR/accounting.lock"
TODAY=$(date +%F) || exit 1

mkdir -p "$DIR" || exit 1

if [ "${1:-}" != "--locked" ]; then
    # authorize-preemptive uses the same package/quota path as authorize, but
    # explicitly allows ndsctl's supported preemptive client lookup. The caller
    # must provide a verified live neighbour on openNDS's managed interface.
    if [ "${1:-}" = authorize-preemptive ]; then
        [ "$#" -eq 2 ] || { echo "ERROR: Usage: quota-manager.sh authorize-preemptive MAC" >&2; exit 1; }
        export QUOTA_ALLOW_PREEMPTIVE_AUTH=1
        set -- authorize "$2"
    fi
    # Synchronize per-client after-quota shaping BEFORE taking accounting.lock.
    # package-shaper.sh snapshots accounts.tsv under that same lock, so calling
    # it from the locked authorize branch would deadlock on recursive flock.
    if [ "${1:-}" = authorize ]; then
        [ "$#" -eq 2 ] || { echo "ERROR: Usage: quota-manager.sh authorize MAC" >&2; exit 1; }
        AUTH_MAC=$(printf '%s' "$2" | tr 'ABCDEF' 'abcdef')
        if [ -x "$DIR/package-shaper.sh" ]; then
            QUOTA_DIR="$DIR" "$DIR/package-shaper.sh" sync "$AUTH_MAC" >/dev/null 2>&1 || {
                echo "ERROR: Could not apply/clear the per-client after-quota profile; authorization refused" >&2
                exit 1
            }
        elif [ -f "$DIR/packages.tsv" ] && awk -F '\t' -v m="$AUTH_MAC" '$1==m && $12=="throttle" {found=1} END {exit !found}' "$DIR/packages.tsv"; then
            echo "ERROR: After-quota throttle requires package-shaper.sh; authorization refused" >&2
            exit 1
        fi
    fi
    exec flock -x "$LOCK" "$0" --locked "$@"
fi
shift

umask 077
touch "$ACCOUNTS" "$LOCK" || exit 1

die() {
    echo "ERROR: $*" >&2
    exit 1
}

normalize_mac() {
    MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
    printf '%s\n' "$MAC" |
        grep -Eq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'
}

quota_kib() {
    case "$1" in
        unlimited) printf 'unlimited\n'; return 0 ;;
        ''|*[!0-9]*|0) return 1 ;;
    esac

    awk -v n="$1" 'BEGIN {
        if (n < 1 || n > 1048576) exit 1
        printf "%.0f\n", n * 1024
    }'
}

find_row() {
    awk -F '\t' -v m="$MAC" '$1 == m { print; exit }' "$ACCOUNTS"
}

load_row() {
    ROW=$(find_row)
    [ -n "$ROW" ] || return 1

    OLDIFS=$IFS
    IFS="$(printf '\t')"
    read -r A_MAC A_PHONE A_DOWN A_UP A_USED_DOWN A_USED_UP \
        A_RESET A_STATUS A_BLOCKED A_START A_LAST_DOWN A_LAST_UP <<EOF
$ROW
EOF
    IFS=$OLDIFS
}

save_row() {
    TMP=$(mktemp "$DIR/accounts.tmp.XXXXXX") || return 1

    awk -F '\t' -v m="$MAC" '$1 != m { print }' \
        "$ACCOUNTS" > "$TMP" || {
            rm -f "$TMP"
            return 1
        }

    printf '%s\n' "$ROW_NEW" >> "$TMP" || {
        rm -f "$TMP"
        return 1
    }

    chmod 600 "$TMP" &&
        mv "$TMP" "$ACCOUNTS"
}

usage_bytes() {
    printf '%s\t%s\n' "$A_USED_DOWN" "$A_USED_UP"
}

show_status() {
    MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
    load_row || {
        echo "No account for $MAC"
        return 1
    }

    echo "MAC:       $A_MAC"
    echo "Phone:     $A_PHONE"
    echo "Status:    $A_STATUS"
    echo "Blocked:   $A_BLOCKED"
    echo "Renewed:   $A_RESET"

    awk -v l="$A_DOWN" -v u="$A_USED_DOWN" 'BEGIN {
        if (l == "unlimited")
            printf "Download:  unlimited (used %.3f MiB)\n", u/1048576
        else {
            r=l*1024-u
            if (r < 0) r=0
            printf "Download:  limit %.3f MiB; used %.3f MiB; remaining %.3f MiB\n",
                   l/1024, u/1048576, r/1048576
        }
    }'

    awk -v l="$A_UP" -v u="$A_USED_UP" 'BEGIN {
        if (l == "unlimited")
            printf "Upload:    unlimited (used %.3f MiB)\n", u/1048576
        else {
            r=l*1024-u
            if (r < 0) r=0
            printf "Upload:    limit %.3f MiB; used %.3f MiB; remaining %.3f MiB\n",
                   l/1024, u/1048576, r/1048576
        }
    }'
}

case "${1:-}" in
    add)
        shift
        [ "$#" -ge 4 ] && [ "$#" -le 4 ] ||
            die "Usage: quota-manager.sh add MAC PHONE DOWNLOAD_MiB UPLOAD_MiB"

        normalize_mac "$1" || die "Invalid MAC address"
        MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
        PHONE="$2"

        if [ "$PHONE" != "-" ]; then
            printf '%s\n' "$PHONE" |
                grep -Eq '^\+?[0-9]{7,15}$' ||
                die "Phone must be digits with an optional leading +, or -"
        fi

        DOWN=$(quota_kib "$3") || die "Invalid download limit"
        UP=$(quota_kib "$4") || die "Invalid upload limit"

        [ -z "$(find_row)" ] || die "Account already exists; use set or renew"

        ROW_NEW=$(printf '%s\t%s\t%s\t%s\t0\t0\t%s\tactive\t0\t-\t0\t0' \
            "$MAC" "$PHONE" "$DOWN" "$UP" "$TODAY")

        save_row || die "Could not save account"
        echo "Account created for $MAC"
        ;;

    status)
        shift
        if [ "$#" -eq 1 ]; then
            normalize_mac "$1" || die "Invalid MAC address"
            show_status "$1"
        elif [ "$#" -eq 0 ]; then
            while IFS="$(printf '\t')" read -r LINE_MAC REST; do
                [ -n "$LINE_MAC" ] || continue
                show_status "$LINE_MAC"
                echo
            done < "$ACCOUNTS"
        else
            die "Usage: quota-manager.sh status [MAC]"
        fi
        ;;

    set)
        shift
        [ "$#" -eq 3 ] || die "Usage: quota-manager.sh set MAC DOWNLOAD_MiB UPLOAD_MiB"
        normalize_mac "$1" || die "Invalid MAC address"
        MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
        load_row || die "Account not found"
        DOWN=$(quota_kib "$2") || die "Invalid download limit"
        UP=$(quota_kib "$3") || die "Invalid upload limit"

        NEW_BLOCKED="$A_BLOCKED"
        if [ "$A_BLOCKED" = 1 ]; then
            STILL_EXHAUSTED=$(awk -v d="$DOWN" -v u="$UP" -v ud="$A_USED_DOWN" -v uu="$A_USED_UP" 'BEGIN {
                exhausted=0
                if (d != "unlimited" && ud >= d*1024) exhausted=1
                if (u != "unlimited" && uu >= u*1024) exhausted=1
                print exhausted
            }')
            [ "$STILL_EXHAUSTED" = 1 ] || NEW_BLOCKED=0
        fi
        ROW_NEW=$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' \
            "$MAC" "$A_PHONE" "$DOWN" "$UP" "$A_USED_DOWN" "$A_USED_UP" \
            "$A_RESET" "$A_STATUS" "$NEW_BLOCKED" "$A_START" \
            "$A_LAST_DOWN" "$A_LAST_UP")
        save_row || die "Could not update account"
        echo "Limits updated. Existing usage was preserved."
        ;;

    renew)
        shift
        [ "$#" -eq 1 ] || [ "$#" -eq 3 ] ||
            die "Usage: quota-manager.sh renew MAC [DOWNLOAD_MiB UPLOAD_MiB]"
        normalize_mac "$1" || die "Invalid MAC address"
        MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
        load_row || die "Account not found"

        DOWN="$A_DOWN"
        UP="$A_UP"
        if [ "$#" -eq 3 ]; then
            DOWN=$(quota_kib "$2") || die "Invalid download limit"
            UP=$(quota_kib "$3") || die "Invalid upload limit"
        fi

        ROW_NEW=$(printf '%s\t%s\t%s\t%s\t0\t0\t%s\tactive\t0\t%s\t%s\t%s' \
            "$MAC" "$A_PHONE" "$DOWN" "$UP" "$TODAY" "$A_START" \
            "$A_LAST_DOWN" "$A_LAST_UP")
        save_row || die "Could not renew account"
        echo "Quota renewed for $MAC; usage reset to zero."
        ;;

    disable|enable)
        CMD="$1"
        shift
        [ "$#" -eq 1 ] || die "Usage: quota-manager.sh $CMD MAC"
        normalize_mac "$1" || die "Invalid MAC address"
        MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
        load_row || die "Account not found"

        NEW_STATUS=active
        [ "$CMD" = disable ] && NEW_STATUS=disabled

        ROW_NEW=$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' \
            "$MAC" "$A_PHONE" "$A_DOWN" "$A_UP" "$A_USED_DOWN" "$A_USED_UP" \
            "$A_RESET" "$NEW_STATUS" "$A_BLOCKED" "$A_START" \
            "$A_LAST_DOWN" "$A_LAST_UP")
        save_row || die "Could not change account status"
        echo "Account status: $NEW_STATUS"
        ;;

    sample)
        shift
        [ "$#" -eq 4 ] || [ "$#" -eq 6 ] || die "Usage: sample MAC SESSION_START DOWNLOAD_BYTES UPLOAD_BYTES [PREVIOUS_SAMPLE_EPOCH CURRENT_SAMPLE_EPOCH]"
        SAMPLE_ARG_COUNT="$#"
        normalize_mac "$1" || die "Invalid sample MAC"
        MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
        START="$2"
        DOWN_NOW="$3"
        UP_NOW="$4"
        PREV_EPOCH="${5:-0}"
        NOW_EPOCH="${6:-0}"

        for N in "$START" "$DOWN_NOW" "$UP_NOW"; do
            case "$N" in ''|*[!0-9]*) die "Invalid sample counter" ;; esac
        done
        if [ "$SAMPLE_ARG_COUNT" -eq 6 ]; then
            for N in "$PREV_EPOCH" "$NOW_EPOCH"; do
                case "$N" in ''|*[!0-9]*) die "Invalid sample timestamps" ;; esac
            done
        fi

        # Only registered accounts need quota usage updated.
        load_row || exit 0

        OLD_DOWN=0
        OLD_UP=0
        if [ "$A_START" = "$START" ]; then
            OLD_DOWN="$A_LAST_DOWN"
            OLD_UP="$A_LAST_UP"
        fi

        # Counter regressions are treated as zero delta, never negative usage.
        set -- $(awk -v nd="$DOWN_NOW" -v od="$OLD_DOWN" \
                     -v nu="$UP_NOW" -v ou="$OLD_UP" 'BEGIN {
            if (nd < od) nd=od
            if (nu < ou) nu=ou
            printf "%.0f %.0f %.0f %.0f", nd-od, nu-ou, nd, nu
        }')
        DELTA_DOWN="$1"
        DELTA_UP="$2"
        NEW_DOWN="$3"
        NEW_UP="$4"
        BILL_DOWN="$DELTA_DOWN"
        BILL_UP="$DELTA_UP"

        # Free-window accounts are billed only for the portion of each sample
        # interval outside 00:00-07:00 Asia/Colombo. Traffic is apportioned by
        # elapsed seconds between samples; this is a short-interval estimate.
        PACKAGE_FREE="$(awk -F '\t' -v m="$MAC" '$1 == m { print $8; exit }' "$DIR/packages.tsv" 2>/dev/null)"
        if [ "$PACKAGE_FREE" = "1" ]; then
            if [ "$SAMPLE_ARG_COUNT" -eq 6 ]; then
                set -- $(policy_bill_bytes "$PREV_EPOCH" "$NOW_EPOCH" "$DELTA_DOWN" "$DELTA_UP")
                BILL_DOWN="$1"
                BILL_UP="$2"
            else
                # Old/manual internal callers lack timing data: fail safe by
                # charging the full delta rather than accidentally giving free data.
                logger -t guest-quota "free_window_missing_timestamps mac=$MAC; full_delta_charged"
            fi
        fi

        set -- $(awk -v d="$A_USED_DOWN" -v u="$A_USED_UP" \
                     -v dd="$BILL_DOWN" -v du="$BILL_UP" 'BEGIN {
            printf "%.0f %.0f", d+dd, u+du
        }')
        USED_DOWN="$1"
        USED_UP="$2"

        ROW_NEW=$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' \
            "$MAC" "$A_PHONE" "$A_DOWN" "$A_UP" "$USED_DOWN" "$USED_UP" \
            "$A_RESET" "$A_STATUS" "$A_BLOCKED" "$START" \
            "$NEW_DOWN" "$NEW_UP")

        save_row || die "Could not record quota usage"
        ;;
    block|unblock)
        CMD="$1"
        shift
        [ "$#" -eq 1 ] || die "Invalid $CMD arguments"
        normalize_mac "$1" || die "Invalid $CMD MAC"
        MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
        load_row || exit 0
        NEW_BLOCKED=1
        [ "$CMD" = unblock ] && NEW_BLOCKED=0
        ROW_NEW=$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' \
            "$MAC" "$A_PHONE" "$A_DOWN" "$A_UP" "$A_USED_DOWN" "$A_USED_UP" \
            "$A_RESET" "$A_STATUS" "$NEW_BLOCKED" "$A_START" "$A_LAST_DOWN" "$A_LAST_UP")
        save_row || die "Could not $CMD account"
        echo "Quota block: $NEW_BLOCKED"
        ;;

    authorize)
        shift
        [ "$#" -eq 1 ] || die "Usage: quota-manager.sh authorize MAC"
        normalize_mac "$1" || die "Invalid MAC address"
        MAC=$(printf '%s' "$1" | tr 'ABCDEF' 'abcdef')
        load_row || die "Account not found"
        AUTH_SESSION="${QUOTA_AUTH_SESSION:-0}"
        AUTH_UP_RATE="${QUOTA_AUTH_UP_RATE:-0}"
        AUTH_DOWN_RATE="${QUOTA_AUTH_DOWN_RATE:-0}"
        AUTH_CUSTOM="${QUOTA_AUTH_CUSTOM:-cXVvdGEtbWFuYWdlZA==}"
        EXPECTED_PHONE="${QUOTA_EXPECT_PHONE:-}"
        # PACKAGE_POLICY_AUTH_BEGIN
        # Existing accounts without package metadata retain legacy behavior.
        PACKAGE_FREE_ACTIVE=0
        PACKAGE_FREE_NOW=0
        PACKAGE_FILE="$DIR/packages.tsv"
        if [ -f "$PACKAGE_FILE" ]; then
            PACKAGE_ROW=$(awk -F '\t' -v m="$MAC" '$1 == m { print; exit }' "$PACKAGE_FILE")
            if [ -n "$PACKAGE_ROW" ]; then
                OLDIFS="$IFS"
                IFS="$(printf '\t')"
                read -r P_MAC P_DAYS P_START P_EXPIRY P_UP_RATE P_DOWN_RATE P_MODE P_FREE P_STATUS P_AFTER_UP P_AFTER_DOWN P_AFTER_ACTION <<EOF_PACKAGE
$PACKAGE_ROW
EOF_PACKAGE
                IFS="$OLDIFS"
                # v2 rows are migrated by the installer; missing trailing fields
                # remain fail-safe and preserve the historical disconnect behaviour.
                [ -n "${P_AFTER_ACTION:-}" ] || P_AFTER_ACTION=disconnect
                [ -n "${P_AFTER_UP:-}" ] || P_AFTER_UP=0
                [ -n "${P_AFTER_DOWN:-}" ] || P_AFTER_DOWN=0

                [ "$P_MAC" = "$MAC" ] || die "Package MAC mismatch"
                case "$P_DAYS:$P_START:$P_EXPIRY:$P_UP_RATE:$P_DOWN_RATE" in
                    ''|*[!0-9:]*) die "Invalid package metadata for $MAC" ;;
                esac
                case "$P_MODE" in
                    one_time|auto_renew) ;;
                    *) die "Invalid package renewal mode for $MAC" ;;
                esac
                case "$P_FREE" in
                    0) ;;
                    1) PACKAGE_FREE_ACTIVE=1 ;;
                    *) die "Invalid package free-period setting for $MAC" ;;
                esac
                case "$P_AFTER_ACTION" in throttle|disconnect) ;; *) die "Invalid after-quota action for $MAC" ;; esac
                for value in "$P_AFTER_UP" "$P_AFTER_DOWN"; do
                    case "$value" in ''|*[!0-9]*) die "Invalid after-quota rate for $MAC" ;; esac
                    [ "$value" -le 100000 ] 2>/dev/null || die "Invalid after-quota rate for $MAC"
                done
                [ "$P_STATUS" = active ] || die "Package is not active (status: $P_STATUS)"
                NOW_EPOCH=$(date +%s) || die "Could not read current time"
                [ "$P_EXPIRY" -gt "$NOW_EPOCH" ] || die "Package validity has expired; administrator renewal required"
                REMAINING_SECONDS=$((P_EXPIRY - NOW_EPOCH))
                AUTH_SESSION=$(((REMAINING_SECONDS + 59) / 60))
                [ "$AUTH_SESSION" -ge 1 ] || AUTH_SESSION=1
                AUTH_UP_RATE="$P_UP_RATE"
                AUTH_DOWN_RATE="$P_DOWN_RATE"
                PACKAGE_AFTER_ACTION="$P_AFTER_ACTION"

                if [ "$PACKAGE_FREE_ACTIVE" = "1" ] && policy_is_free_now; then
                    PACKAGE_FREE_NOW=1
                fi
                logger -t guest-quota "package_auth mac=$MAC session_min=$AUTH_SESSION upload_kbps=$AUTH_UP_RATE download_kbps=$AUTH_DOWN_RATE free_window=$PACKAGE_FREE_NOW expiry=$P_EXPIRY"
            fi
        fi
        # PACKAGE_POLICY_AUTH_END
        for value in "$AUTH_SESSION" "$AUTH_UP_RATE" "$AUTH_DOWN_RATE"; do
            case "$value" in
                ""|*[!0-9]*) die "Invalid session or rate override" ;;
            esac
        done
        printf "%s" "$AUTH_CUSTOM" | grep -Eq "^[A-Za-z0-9+/=]+$" || die "Invalid custom data"
        if [ -n "$EXPECTED_PHONE" ]; then
            REQUEST_PHONE_DIGITS=$(printf "%s" "$EXPECTED_PHONE" | tr -cd 0123456789)
            ACCOUNT_PHONE_DIGITS=$(printf "%s" "$A_PHONE" | tr -cd 0123456789)
            [ -n "$REQUEST_PHONE_DIGITS" ] && [ "$REQUEST_PHONE_DIGITS" = "$ACCOUNT_PHONE_DIGITS" ] || die "Request phone does not match quota account"
        fi

        [ "$A_STATUS" = active ] || die "Account is disabled"

        calc_remaining() {
            if [ "$1" = unlimited ]; then
                printf '0\n'
            else
                awk -v l="$1" -v used="$2" 'BEGIN {
                    r=int(l-used/1024)
                    if (r < 0) r=0
                    printf "%.0f\n", r
                }'
            fi
        }

        DOWN_LEFT=$(calc_remaining "$A_DOWN" "$A_USED_DOWN")
        UP_LEFT=$(calc_remaining "$A_UP" "$A_USED_UP")

        if [ "${PACKAGE_AFTER_ACTION:-disconnect}" = throttle ]; then
            # Keep openNDS volume counters unlimited. poll-accounting/free-enforcer
            # detects exhaustion and applies per-client TC caps without deauth.
            # Clear a stale quota lock left by an earlier disconnect-mode package.
            if [ "$A_BLOCKED" = 1 ]; then
                ROW_NEW=$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t0\t%s\t%s\t%s' \
                    "$MAC" "$A_PHONE" "$A_DOWN" "$A_UP" "$A_USED_DOWN" "$A_USED_UP" \
                    "$A_RESET" "$A_STATUS" "$A_START" "$A_LAST_DOWN" "$A_LAST_UP")
                save_row || die "Could not clear an old quota block for throttle-mode package"
                A_BLOCKED=0
            fi
            UP_LEFT=0
            DOWN_LEFT=0
        elif [ "$PACKAGE_FREE_ACTIVE" = "1" ]; then
            # Disconnect-mode free packages use the external time-aware enforcer.
            # openNDS volume quotas stay unlimited during both free and billed periods.
            if [ "$PACKAGE_FREE_NOW" != "1" ]; then
                [ "$A_BLOCKED" = 0 ] || die "Quota is exhausted or account is blocked; renew or wait for the free period"
                [ "$A_DOWN" = unlimited ] || [ "$DOWN_LEFT" -gt 0 ] || die "Download quota exhausted; renew the account first"
                [ "$A_UP" = unlimited ] || [ "$UP_LEFT" -gt 0 ] || die "Upload quota exhausted; renew the account first"
            fi
            UP_LEFT=0
            DOWN_LEFT=0
        else
            [ "$A_BLOCKED" = 0 ] || die "Quota deauthentication lock is set; renew the account first"
            [ "$A_DOWN" = unlimited ] || [ "$DOWN_LEFT" -gt 0 ] || die "Download quota exhausted; renew the account first"
            [ "$A_UP" = unlimited ] || [ "$UP_LEFT" -gt 0 ] || die "Upload quota exhausted; renew the account first"
        fi

        # Every normal authorize invocation synchronized the after-quota
        # profile in the outer wrapper before acquiring accounting.lock. Do not
        # call package-shaper from this locked section: it needs the same lock
        # to read a consistent accounts/packages snapshot.
        if [ "${PACKAGE_AFTER_ACTION:-disconnect}" = throttle ]; then
            [ -x "$DIR/package-shaper.sh" ] || die "After-quota throttle requires package-shaper.sh; authentication refused"
        fi

        if CLIENT_JSON=$(policy_ndsctl_optional json "$MAC" 2>/dev/null); then
            :
        else
            NDS_RC=$?
            [ "$NDS_RC" -eq 4 ] && die "openNDS control remained busy after retries; authorization was refused without assuming the client was missing"
            CLIENT_JSON=""
        fi
        CLIENT_MAC=$(printf '%s\n' "$CLIENT_JSON" |
            jsonfilter -e '@.mac' 2>/dev/null | head -n 1)
        CLIENT_STATE=$(printf '%s\n' "$CLIENT_JSON" |
            jsonfilter -e '@.state' 2>/dev/null | head -n 1)

        if [ "$CLIENT_STATE" = Preauthenticated ] && [ "$CLIENT_MAC" = "$MAC" ]; then
            : # Normal captive-portal authentication path.
        elif [ "${QUOTA_ALLOW_PREEMPTIVE_AUTH:-0}" = 1 ] && [ -z "$CLIENT_STATE" ]; then
            policy_verify_preemptive_neighbour "$MAC" "${QUOTA_PREEMPTIVE_IP:-}" "${QUOTA_PREEMPTIVE_IFACE:-}" ||
                die "Device is not a verified live neighbour on openNDS's managed guest interface"
        else
            die "Device state is '${CLIENT_STATE:-not-listed}', not Preauthenticated; no changes made"
        fi

        AUTH_OUT="$(policy_ndsctl auth "$MAC" "$AUTH_SESSION" "$AUTH_UP_RATE" "$AUTH_DOWN_RATE" "$UP_LEFT" "$DOWN_LEFT" "$AUTH_CUSTOM" 2>&1)" ||
            die "openNDS authentication failed: $AUTH_OUT"
        printf "%s" "$AUTH_OUT" | grep -Fq "authenticated." ||
            die "openNDS did not confirm authentication: $AUTH_OUT"

        logger -t guest-quota "authorized mac=$MAC download_kib=$DOWN_LEFT upload_kib=$UP_LEFT"
        echo "Authorized $MAC with remaining download=${DOWN_LEFT} kB, upload=${UP_LEFT} kB"
        ;;

    *)
        cat <<'HELP'
Quota manager commands:
  add MAC PHONE DOWNLOAD_MiB UPLOAD_MiB
      Create an account. Use "unlimited" for a direction, or "-" for unknown phone.
  status [MAC]
      Show registered accounts and consumed/remaining allowances.
  set MAC DOWNLOAD_MiB UPLOAD_MiB
      Change limits without resetting existing usage.
  renew MAC [DOWNLOAD_MiB UPLOAD_MiB]
      Reset usage and remove the quota-deauthentication lock.
  disable MAC
  enable MAC
  authorize MAC
      Apply the remaining quota to a Preauthenticated openNDS client.
  authorize-preemptive MAC
      Apply package quota to a verified live guest-interface neighbour using openNDS preemptive authentication.

Internal commands used by accounting hooks:
  --locked sample MAC SESSION_START DOWNLOAD_BYTES UPLOAD_BYTES
  --locked block MAC
  --locked unblock MAC

Quota values are MiB. Session limits are passed to openNDS in kB.
A quota of "unlimited" maps to openNDS value 0.
HELP
        exit 1
        ;;
esac
