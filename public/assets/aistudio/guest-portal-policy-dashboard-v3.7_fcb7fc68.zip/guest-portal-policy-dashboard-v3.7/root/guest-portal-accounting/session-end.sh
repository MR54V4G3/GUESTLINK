#!/bin/sh
DIR="${ACCOUNTING_DIR:-/root/guest-portal-accounting}"
LOCK="$DIR/accounting.lock"
if [ "$1" != "--locked" ]; then
    exec flock -x "$LOCK" /bin/sh "$0" --locked "$@"
fi
shift

action="$1"
method="$2"
mac="$3"
incoming="$4"
outgoing="$5"
started="$6"
ended="$7"

[ "$action" = deauth ] || exit 0
case "$mac" in
    [0-9a-fA-F][0-9a-fA-F]:*) ;;
    *) exit 1 ;;
esac
for value in "$incoming" "$outgoing" "$started" "$ended"; do
    case "$value" in ''|*[!0-9]*) exit 1 ;; esac
done

STATE="$DIR/session-state.tsv"
LEDGER="$DIR/daily-usage.tsv"
EVENTS="$DIR/session-events.tsv"
STATE_MTIME=$(stat -c %Y "$STATE" 2>/dev/null)
touch "$STATE" "$LEDGER" "$EVENTS" || exit 1

# Ignore an identical callback if it has already been recorded.
if awk -F '\t' -v e="$ended" -v m="$mac" \
    -v i="$incoming" -v o="$outgoing" \
    -v s="$started" -v method="$method" \
    '$1==e && $2==m && $3==i && $4==o && $5==s && $6==method {found=1}
     END {exit !found}' "$EVENTS"; then
    exit 0
fi

# The poller stores its last sample epoch in column 5. If this is an older
# four-column state row, fall back to the state file modification time.
prev_sample=$(awk -F '\t' -v m="$mac" -v s="$started" \
    '$1==m && $2==s {print $5; exit}' "$STATE")
case "$prev_sample" in
    ''|*[!0-9]*)
        prev_sample="$STATE_MTIME"
        case "$prev_sample" in ''|*[!0-9]*) prev_sample="$started" ;; esac
        ;;
esac
[ "$prev_sample" -lt "$started" ] && prev_sample="$started"
[ "$prev_sample" -gt "$ended" ] && prev_sample="$ended"

# BinAuth reports final session totals; pass the sample interval so free-window
# accounts only pay for the time outside 00:00-07:00 Asia/Colombo.
if [ -x "$DIR/quota-manager.sh" ]; then
    QUOTA_DIR="$DIR" "$DIR/quota-manager.sh" --locked sample \
        "$mac" "$started" "$incoming" "$outgoing" "$prev_sample" "$ended" || \
        logger -t guest-quota "session_sample_failed mac=$mac method=$method"
    case "$method" in
        upquota_deauth|downquota_deauth)
            AFTER_ACTION="$(awk -F '\t' -v m="$mac" '$1==m {if (NF>=12 && $12!="") print $12; else print "disconnect"; exit}' "$DIR/packages.tsv" 2>/dev/null)"
            if [ "$AFTER_ACTION" != throttle ]; then
                QUOTA_DIR="$DIR" "$DIR/quota-manager.sh" --locked block "$mac" || \
                    logger -t guest-quota "quota_block_failed mac=$mac method=$method"
            else
                logger -t guest-quota "quota_deauth_callback_ignored_for_throttle_package mac=$mac method=$method"
            fi
            ;;
    esac
fi

# State columns: MAC, start epoch, downloaded bytes, uploaded bytes, last sample epoch.
old=$(awk -F '\t' -v m="$mac" -v s="$started" \
    '$1==m && $2==s {print $3 "\t" $4; exit}' "$STATE")
if [ -n "$old" ]; then
    old_down=$(printf '%s\n' "$old" | cut -f1)
    old_up=$(printf '%s\n' "$old" | cut -f2)
    case "$old_down:$old_up" in *[!0-9:]*|'') exit 1 ;; esac
    down_delta=0
    up_delta=0
    [ "$incoming" -lt "$old_down" ] || down_delta=$((incoming - old_down))
    [ "$outgoing" -lt "$old_up" ] || up_delta=$((outgoing - old_up))
    day=$(date -d "@$ended" '+%Y-%m-%d') || exit 1
    if [ "$down_delta" -gt 0 ] || [ "$up_delta" -gt 0 ]; then
        printf '%s\t%s\t%s\t%s\n' \
            "$day" "$mac" "$down_delta" "$up_delta" >> "$LEDGER" || exit 1
    fi
fi

printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$ended" "$mac" "$incoming" "$outgoing" "$started" "$method" >> "$EVENTS"
