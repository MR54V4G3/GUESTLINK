# Free-window notes (included in the full dashboard update)

This file is retained as a pointer for users of the earlier accounting-only update.

The current bundle is the complete STARLINK Guest Portal Package + Policy Dashboard update. It includes assigned-package editing/removal, automatic request approval, temporary unassigned-device access, auto-authentication controls, activation policy and shared free-window accounting.

Use `README.md` for the complete behaviour, installation steps, supported renewal lifecycle and limitations. Do not install the older `install-free-window-update.sh` from an earlier bundle.
