#!/bin/sh
# Install Guest Policy v3.7 with state-aware openNDS deauthentication.
# Does not change accounts.tsv, cron schedule, firewall/network configuration, SQM,
# openNDS configuration, or restart any service.
set -eu

SRC="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
SRC_ACCT="$SRC/root/guest-portal-accounting"
SRC_DASH="$SRC/srv/guest-dashboard/cgi-bin"
DIR="${QUOTA_DIR:-/root/guest-portal-accounting}"
DASH="${GUEST_DASHBOARD_CGI:-/srv/guest-dashboard/cgi-bin}"
REQUEST_DIR="${REQUEST_MANAGER_DIR:-/root/guest-portal-requests}"
OPENNDS_LIB="${OPENNDS_LIB_DIR:-/usr/lib/opennds}"
INITD_DIR="${GUEST_INITD_DIR:-/etc/init.d}"
INIT_FILE="guest-return-auth"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$DIR/backups/guest-policy-dashboard-$STAMP"
WORK=""
V2_HEADER='# v2: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS'
EXPECTED_HEADER='# v3: MAC DAYS START_EPOCH EXPIRY_EPOCH UPLOAD_KBPS DOWNLOAD_KBPS RENEWAL_MODE FREE_ENABLED STATUS AFTER_UPLOAD_KBPS AFTER_DOWNLOAD_KBPS AFTER_QUOTA_ACTION'

fail() { echo "ERROR: $*" >&2; exit 1; }
cleanup() { [ -z "$WORK" ] || rm -rf "$WORK"; }
trap cleanup EXIT HUP INT TERM

[ -d "$DIR" ] || fail "Accounting directory not found: $DIR"
[ -f "$DIR/accounts.tsv" ] || fail "accounts.tsv is missing; no changes made"
[ -f "$DIR/packages.tsv" ] || fail "packages.tsv is missing; no changes made"
CURRENT_HEADER="$(sed -n '1p' "$DIR/packages.tsv")"
case "$CURRENT_HEADER" in
    "$V2_HEADER"|"$EXPECTED_HEADER") ;;
    *) fail "Unsupported packages.tsv schema; expected v2 or v3; no changes made" ;;
esac
[ -x "$DIR/poll-accounting.sh" ] || fail "poll-accounting.sh is missing or not executable"
[ -x "$DIR/session-end.sh" ] || fail "session-end.sh is missing or not executable"
[ -d "$DASH" ] || fail "Dashboard CGI directory not found: $DASH"

ACCOUNT_FILES='quota-manager.sh package-manager.sh package-shaper.sh free-enforcer.sh auto-renew.sh returning-auth.sh poll-accounting.sh policy-lib.sh session-policy.sh session-end.sh verify-free-window-runtime.sh'
DASH_FILES='requests packages quotas policy disconnect'
TEST_FILES='test-free-window.sh test-policy-dashboard.sh test-package-controls.sh test-after-quota.sh test-returning-device.sh test-ndsctl-retry.sh test-auto-renew.sh test-delete-device.sh test-device-inventory.sh test-auto-mac-enroll.sh test-returning-preemptive.sh'
REQUEST_FILES='live-manager.sh submit-request.sh'
THEME_FILE='theme_guest-approval-requests.sh'

for f in $ACCOUNT_FILES; do
    [ -f "$SRC_ACCT/$f" ] || fail "Source file missing: $SRC_ACCT/$f"
    /bin/sh -n "$SRC_ACCT/$f" || fail "Shell syntax check failed: $f"
done
for f in $TEST_FILES; do
    [ -f "$SRC_ACCT/tests/$f" ] || fail "Test file missing: tests/$f"
    /bin/sh -n "$SRC_ACCT/tests/$f" || fail "Shell syntax check failed: tests/$f"
done
for f in $REQUEST_FILES; do
    [ -f "$SRC/root/guest-portal-requests/$f" ] || fail "Request source missing: $f"
    /bin/sh -n "$SRC/root/guest-portal-requests/$f" || fail "Shell syntax check failed: request/$f"
done
[ -f "$SRC/usr/lib/opennds/$THEME_FILE" ] || fail "openNDS theme source missing"
/bin/sh -n "$SRC/usr/lib/opennds/$THEME_FILE" || fail "openNDS theme syntax check failed"
[ -f "$SRC/etc/init.d/$INIT_FILE" ] || fail "Returning-auth init service source missing"
/bin/sh -n "$SRC/etc/init.d/$INIT_FILE" || fail "Returning-auth init service syntax check failed"
for f in $DASH_FILES; do
    [ -f "$SRC_DASH/$f" ] || fail "Dashboard source missing: $f"
    /bin/sh -n "$SRC_DASH/$f" || fail "Dashboard syntax check failed: $f"
done
[ -f "$SRC_ACCT/policy.conf.example" ] || fail "Policy example file is missing"

# Run isolated functional tests before touching any live file.
# Test fixtures must not inherit the installer mock's target-path overrides.
# Each suite uses its own isolated QUOTA_DIR and temporary CGI locations.
(
    unset QUOTA_DIR GUEST_DASHBOARD_CGI REQUEST_MANAGER_DIR OPENNDS_LIB_DIR GUEST_INITD_DIR GUEST_POLICY_FILE TC_BIN
    /bin/sh "$SRC/run-guest-policy-tests.sh"
) || fail "Functional tests failed; no live files changed"

# Verify the live SQM/IFB layout before backing up or replacing anything.
# This is read-only; the shaper check never creates or changes qdiscs/classes.
TC_PREFLIGHT="$(QUOTA_DIR="$DIR" TC_BIN="${TC_BIN:-tc}" /bin/sh "$SRC_ACCT/package-shaper.sh" check 2>&1)" || fail "Traffic-control preflight failed; no live files changed: $TC_PREFLIGHT"
echo "Traffic-control preflight: $TC_PREFLIGHT"

mkdir -p "$DIR/backups" "$BACKUP/root/guest-portal-accounting/tests" \
    "$BACKUP/root/guest-portal-requests" "$BACKUP/usr/lib/opennds" \
    "$BACKUP/srv/guest-dashboard/cgi-bin" "$BACKUP/etc/init.d" || fail "Could not create backup directory"
WORK="$(mktemp -d "$DIR/.guest-policy-update.XXXXXX")" || fail "Could not create staging directory"

# Serialize package data migration with live package assignment/edit/remove.
# Hold the same lock used by package-manager.sh until the package table is
# safely migrated and the file swap has completed.
command -v flock >/dev/null 2>&1 || fail "flock is required to protect package metadata during installation"
exec 9>"$DIR/packages.lock"
flock -x 9 || fail "Could not lock package metadata; no package migration was performed"
# Match the package-manager lock order and pause the accounting poller while
# interdependent accounting scripts are being switched into place.
exec 8>"$DIR/accounting.lock"
flock -x 8 || fail "Could not lock accounting data; no files were replaced"
CURRENT_HEADER="$(sed -n '1p' "$DIR/packages.tsv")"
case "$CURRENT_HEADER" in
    "$V2_HEADER"|"$EXPECTED_HEADER") ;;
    *) fail "packages.tsv schema changed during preflight; no files were replaced" ;;
esac

# Back up all replaced executable/configuration files and the package data file
# before schema migration. accounts.tsv is intentionally never rewritten.
for f in $ACCOUNT_FILES; do
    [ ! -e "$DIR/$f" ] || cp -p "$DIR/$f" "$BACKUP/root/guest-portal-accounting/$f" || fail "Backup failed: $f"
    [ -e "$DIR/$f" ] || : > "$BACKUP/root/guest-portal-accounting/$f.absent"
done
for f in $TEST_FILES; do
    [ ! -e "$DIR/tests/$f" ] || cp -p "$DIR/tests/$f" "$BACKUP/root/guest-portal-accounting/tests/$f" || fail "Backup failed: tests/$f"
    [ -e "$DIR/tests/$f" ] || : > "$BACKUP/root/guest-portal-accounting/tests/$f.absent"
done
for f in $DASH_FILES; do
    [ ! -e "$DASH/$f" ] || cp -p "$DASH/$f" "$BACKUP/srv/guest-dashboard/cgi-bin/$f" || fail "Backup failed: dashboard/$f"
    [ -e "$DASH/$f" ] || : > "$BACKUP/srv/guest-dashboard/cgi-bin/$f.absent"
done
for f in $REQUEST_FILES; do
    [ ! -e "$REQUEST_DIR/$f" ] || cp -p "$REQUEST_DIR/$f" "$BACKUP/root/guest-portal-requests/$f" || fail "Backup failed: request/$f"
    [ -e "$REQUEST_DIR/$f" ] || : > "$BACKUP/root/guest-portal-requests/$f.absent"
done
[ ! -e "$OPENNDS_LIB/$THEME_FILE" ] || cp -p "$OPENNDS_LIB/$THEME_FILE" "$BACKUP/usr/lib/opennds/$THEME_FILE" || fail "Backup failed: openNDS theme"
[ -e "$OPENNDS_LIB/$THEME_FILE" ] || : > "$BACKUP/usr/lib/opennds/$THEME_FILE.absent"
[ ! -e "$INITD_DIR/$INIT_FILE" ] || cp -p "$INITD_DIR/$INIT_FILE" "$BACKUP/etc/init.d/$INIT_FILE" || fail "Backup failed: init.d/$INIT_FILE"
[ -e "$INITD_DIR/$INIT_FILE" ] || : > "$BACKUP/etc/init.d/$INIT_FILE.absent"
cp -p "$DIR/packages.tsv" "$BACKUP/root/guest-portal-accounting/packages.tsv" || fail "Could not back up packages.tsv"
if [ -e "$DIR/policy.conf" ]; then
    cp -p "$DIR/policy.conf" "$BACKUP/root/guest-portal-accounting/policy.conf" || fail "Could not back up policy.conf"
else
    : > "$BACKUP/root/guest-portal-accounting/policy.conf.absent"
fi
if [ -e "$DIR/policy.conf.example" ]; then
    cp -p "$DIR/policy.conf.example" "$BACKUP/root/guest-portal-accounting/policy.conf.example" || fail "Could not back up policy.conf.example"
else
    : > "$BACKUP/root/guest-portal-accounting/policy.conf.example.absent"
fi

restore() {
    for f in $ACCOUNT_FILES; do
        if [ -f "$BACKUP/root/guest-portal-accounting/$f" ]; then cp -p "$BACKUP/root/guest-portal-accounting/$f" "$DIR/$f"; else rm -f "$DIR/$f"; fi
    done
    for f in $TEST_FILES; do
        if [ -f "$BACKUP/root/guest-portal-accounting/tests/$f" ]; then cp -p "$BACKUP/root/guest-portal-accounting/tests/$f" "$DIR/tests/$f"; else rm -f "$DIR/tests/$f"; fi
    done
    for f in $DASH_FILES; do
        if [ -f "$BACKUP/srv/guest-dashboard/cgi-bin/$f" ]; then cp -p "$BACKUP/srv/guest-dashboard/cgi-bin/$f" "$DASH/$f"; else rm -f "$DASH/$f"; fi
    done
    for f in $REQUEST_FILES; do
        if [ -f "$BACKUP/root/guest-portal-requests/$f" ]; then cp -p "$BACKUP/root/guest-portal-requests/$f" "$REQUEST_DIR/$f"; else rm -f "$REQUEST_DIR/$f"; fi
    done
    if [ -f "$BACKUP/usr/lib/opennds/$THEME_FILE" ]; then cp -p "$BACKUP/usr/lib/opennds/$THEME_FILE" "$OPENNDS_LIB/$THEME_FILE"; else rm -f "$OPENNDS_LIB/$THEME_FILE"; fi
    if [ -f "$BACKUP/etc/init.d/$INIT_FILE" ]; then cp -p "$BACKUP/etc/init.d/$INIT_FILE" "$INITD_DIR/$INIT_FILE"; else rm -f "$INITD_DIR/$INIT_FILE"; fi
    cp -p "$BACKUP/root/guest-portal-accounting/packages.tsv" "$DIR/packages.tsv"
    if [ -f "$BACKUP/root/guest-portal-accounting/policy.conf" ]; then cp -p "$BACKUP/root/guest-portal-accounting/policy.conf" "$DIR/policy.conf"; else rm -f "$DIR/policy.conf"; fi
    if [ -f "$BACKUP/root/guest-portal-accounting/policy.conf.example" ]; then cp -p "$BACKUP/root/guest-portal-accounting/policy.conf.example" "$DIR/policy.conf.example"; else rm -f "$DIR/policy.conf.example"; fi
}

# Stage source files on destination filesystem before switching any live path.
mkdir -p "$DIR/tests" "$REQUEST_DIR" "$OPENNDS_LIB" "$INITD_DIR" || fail "Could not create required install directories"
for f in $ACCOUNT_FILES; do
    cp "$SRC_ACCT/$f" "$WORK/$f" || { restore; fail "Could not stage $f"; }
    chmod 700 "$WORK/$f"
    /bin/sh -n "$WORK/$f" || { restore; fail "Staged syntax check failed: $f"; }
done
for f in $TEST_FILES; do
    cp "$SRC_ACCT/tests/$f" "$WORK/$f" || { restore; fail "Could not stage tests/$f"; }
    chmod 700 "$WORK/$f"
done
for f in $DASH_FILES; do
    cp "$SRC_DASH/$f" "$WORK/dashboard-$f" || { restore; fail "Could not stage dashboard/$f"; }
    chmod 755 "$WORK/dashboard-$f"
    /bin/sh -n "$WORK/dashboard-$f" || { restore; fail "Staged dashboard syntax check failed: $f"; }
done
for f in $REQUEST_FILES; do
    cp "$SRC/root/guest-portal-requests/$f" "$WORK/request-$f" || { restore; fail "Could not stage request/$f"; }
    chmod 700 "$WORK/request-$f"
    /bin/sh -n "$WORK/request-$f" || { restore; fail "Staged request syntax check failed: $f"; }
done
cp "$SRC/usr/lib/opennds/$THEME_FILE" "$WORK/$THEME_FILE"
chmod 755 "$WORK/$THEME_FILE"
/bin/sh -n "$WORK/$THEME_FILE" || { restore; fail "Staged openNDS theme syntax check failed"; }
cp "$SRC/etc/init.d/$INIT_FILE" "$WORK/$INIT_FILE"
chmod 755 "$WORK/$INIT_FILE"
/bin/sh -n "$WORK/$INIT_FILE" || { restore; fail "Staged init service syntax check failed"; }
cp "$SRC_ACCT/policy.conf.example" "$WORK/policy.conf.example"
chmod 600 "$WORK/policy.conf.example"

# v2 rows contain nine columns. Append safe legacy defaults while preserving
# the first nine fields exactly: existing packages keep disconnect behaviour.
if [ "$CURRENT_HEADER" = "$V2_HEADER" ]; then
    awk -F '\t' -v OFS='\t' -v h="$EXPECTED_HEADER" '
        NR==1 { print h; next }
        /^#/ || NF==0 { print; next }
        NF==9 { print $0, 64, 64, "disconnect"; next }
        { print "Invalid v2 package row at line " NR > "/dev/stderr"; bad=1; exit 1 }
        END { if (bad) exit 1 }
    ' "$DIR/packages.tsv" > "$WORK/packages.tsv" || { restore; fail "Could not safely migrate packages.tsv; backups restored"; }
else
    awk -F '\t' 'NR==1 {next} /^#/ || NF==0 {next} NF!=12 {print "Invalid v3 package row at line " NR > "/dev/stderr"; bad=1; exit 1} END {if (bad) exit 1}' "$DIR/packages.tsv" || { restore; fail "Existing v3 packages.tsv failed validation; backups restored"; }
    cp "$DIR/packages.tsv" "$WORK/packages.tsv" || { restore; fail "Could not stage packages.tsv"; }
fi
chmod 600 "$WORK/packages.tsv"

# Prepare temporary destination names. Nothing is switched until every file
# and the migrated package table have been staged successfully.
for f in $ACCOUNT_FILES; do cp "$WORK/$f" "$DIR/$f.new-$STAMP"; chmod 700 "$DIR/$f.new-$STAMP"; done
for f in $TEST_FILES; do cp "$WORK/$f" "$DIR/tests/$f.new-$STAMP"; chmod 700 "$DIR/tests/$f.new-$STAMP"; done
for f in $DASH_FILES; do cp "$WORK/dashboard-$f" "$DASH/$f.new-$STAMP"; chmod 755 "$DASH/$f.new-$STAMP"; done
for f in $REQUEST_FILES; do cp "$WORK/request-$f" "$REQUEST_DIR/$f.new-$STAMP"; chmod 700 "$REQUEST_DIR/$f.new-$STAMP"; done
cp "$WORK/$THEME_FILE" "$OPENNDS_LIB/$THEME_FILE.new-$STAMP"; chmod 755 "$OPENNDS_LIB/$THEME_FILE.new-$STAMP"
cp "$WORK/$INIT_FILE" "$INITD_DIR/$INIT_FILE.new-$STAMP"; chmod 755 "$INITD_DIR/$INIT_FILE.new-$STAMP"
cp "$WORK/policy.conf.example" "$DIR/policy.conf.example.new-$STAMP"; chmod 600 "$DIR/policy.conf.example.new-$STAMP"
cp "$WORK/packages.tsv" "$DIR/packages.tsv.new-$STAMP"; chmod 600 "$DIR/packages.tsv.new-$STAMP"
if [ ! -f "$DIR/policy.conf" ]; then cp "$WORK/policy.conf.example" "$DIR/policy.conf.new-$STAMP"; chmod 600 "$DIR/policy.conf.new-$STAMP"; fi

# Atomic rename of each staged file. Rollback restores every prior target and
# the original package metadata if any rename or post-install check fails.
for f in $ACCOUNT_FILES; do mv "$DIR/$f.new-$STAMP" "$DIR/$f" || { restore; fail "Install failed for $f; restored backups"; }; done
for f in $TEST_FILES; do mv "$DIR/tests/$f.new-$STAMP" "$DIR/tests/$f" || { restore; fail "Install failed for tests/$f; restored backups"; }; done
for f in $DASH_FILES; do mv "$DASH/$f.new-$STAMP" "$DASH/$f" || { restore; fail "Install failed for dashboard/$f; restored backups"; }; done
for f in $REQUEST_FILES; do mv "$REQUEST_DIR/$f.new-$STAMP" "$REQUEST_DIR/$f" || { restore; fail "Install failed for request/$f; restored backups"; }; done
mv "$OPENNDS_LIB/$THEME_FILE.new-$STAMP" "$OPENNDS_LIB/$THEME_FILE" || { restore; fail "Install failed for openNDS theme; restored backups"; }
mv "$INITD_DIR/$INIT_FILE.new-$STAMP" "$INITD_DIR/$INIT_FILE" || { restore; fail "Install failed for returning-auth init service; restored backups"; }
mv "$DIR/policy.conf.example.new-$STAMP" "$DIR/policy.conf.example" || { restore; fail "Install failed for policy.conf.example; restored backups"; }
mv "$DIR/packages.tsv.new-$STAMP" "$DIR/packages.tsv" || { restore; fail "Install failed for packages.tsv migration; restored backups"; }
if [ -f "$DIR/policy.conf.new-$STAMP" ]; then mv "$DIR/policy.conf.new-$STAMP" "$DIR/policy.conf" || { restore; fail "Could not create default policy.conf; restored backups"; }; fi

for f in $ACCOUNT_FILES; do /bin/sh -n "$DIR/$f" || { restore; fail "Post-install syntax failure for $f; restored backups"; }; done
for f in $DASH_FILES; do /bin/sh -n "$DASH/$f" || { restore; fail "Post-install dashboard syntax failure for $f; restored backups"; }; done
for f in $REQUEST_FILES; do /bin/sh -n "$REQUEST_DIR/$f" || { restore; fail "Post-install request syntax failure for $f; restored backups"; }; done
/bin/sh -n "$OPENNDS_LIB/$THEME_FILE" || { restore; fail "Post-install theme syntax failure; restored backups"; }
[ -x "$DIR/returning-auth.sh" ] || { restore; fail "Returning-auth worker missing or not executable; restored backups"; }
[ -x "$INITD_DIR/$INIT_FILE" ] && /bin/sh -n "$INITD_DIR/$INIT_FILE" || { restore; fail "Returning-auth init service missing or invalid; restored backups"; }
[ "$(sed -n '1p' "$DIR/packages.tsv")" = "$EXPECTED_HEADER" ] || { restore; fail "Package schema changed unexpectedly; restored backups"; }
grep -q 'auto-renew.sh' "$DIR/poll-accounting.sh" && grep -q 'free-enforcer.sh' "$DIR/poll-accounting.sh" || { restore; fail "Accounting poller does not invoke auto-renew and free-enforcer in order; restored backups"; }
grep -q 'ACTION.*resume\|ACTION.*= resume' "$REQUEST_DIR/live-manager.sh" || { restore; fail "Returning-device resume handler missing; restored backups"; }
grep -q 'return_manager.*live-manager.sh' "$OPENNDS_LIB/$THEME_FILE" && grep -q 'resume' "$OPENNDS_LIB/$THEME_FILE" || { restore; fail "Returning-device portal integration missing; restored backups"; }
grep -q 'ACTION.*auto-enroll' "$REQUEST_DIR/live-manager.sh" && grep -q 'MAC_AUTO_ENROLL' "$DIR/policy-lib.sh" && grep -q 'auto-enroll' "$OPENNDS_LIB/$THEME_FILE" || { restore; fail "Automatic MAC enrollment integration missing; restored backups"; }
grep -q 'Connected device inventory' "$DASH/requests" && grep -q 'PREFILL_MAC' "$DASH/packages" || { restore; fail "Connected-device inventory or package preselection missing; restored backups"; }
grep -q 'resume-preemptive' "$REQUEST_DIR/live-manager.sh" && grep -q 'allow_preemptive_authentication\|Preemptive Authentication is Enabled' "$DIR/returning-auth.sh" || { restore; fail "Preemptive returning-device authorization path missing; restored backups"; }
grep -q 'rejected_request' "$REQUEST_DIR/live-manager.sh" || { restore; fail "Rejected-request return-auth suppression missing; restored backups"; }
grep -q 'policy_ndsctl()' "$DIR/policy-lib.sh" && grep -q 'policy_ndsctl_once json' "$DIR/poll-accounting.sh" || { restore; fail "Bounded ndsctl retry / accounting-lock single-shot handling missing; restored backups"; }
grep -q 'revoke-device' "$REQUEST_DIR/live-manager.sh" && grep -q 'restore-device' "$REQUEST_DIR/live-manager.sh" && grep -q 'REVOKED' "$DASH/requests" || { restore; fail "Preserve-history revoke/restore workflow missing; restored backups"; }
grep -q 'Permanently delete portal records' "$DASH/requests" && grep -q 'policy_return_auth_clear_attempt' "$REQUEST_DIR/live-manager.sh" && grep -q 'policy_return_auth_clear_denied' "$REQUEST_DIR/live-manager.sh" || { restore; fail "Portal-scoped permanent-delete cleanup missing; restored backups"; }
grep -q 'list-return-blocks' "$REQUEST_DIR/live-manager.sh" && grep -q 'forget-device' "$REQUEST_DIR/live-manager.sh" && grep -q 'panel-blocked' "$DASH/requests" || { restore; fail "Blocked Devices management is missing; restored backups"; }
grep -q 'Preauthenticated)' "$REQUEST_DIR/live-manager.sh" && grep -q 'no authenticated session' "$REQUEST_DIR/live-manager.sh" && grep -q 'STATE.*Authenticated' "$DIR/free-enforcer.sh" || { restore; fail "State-aware deauthentication guard is missing; restored backups"; }
grep -q 'already preauthenticated' "$DASH/disconnect" || { restore; fail "Standalone disconnect does not handle preauthenticated clients safely; restored backups"; }
grep -q 'Permanent deletion was not confirmed' "$DASH/requests" && grep -q 'name=\"confirm\" value=\"yes\"' "$DASH/requests" || { restore; fail "Server-side permanent-delete confirmation is missing; restored backups"; }
grep -q 'RETURN_ADMIN_BLOCKED' "$OPENNDS_LIB/$THEME_FILE" && grep -q 'Access temporarily disabled' "$OPENNDS_LIB/$THEME_FILE" || { restore; fail "Explicit administrator-block captive-portal message missing; restored backups"; }

rm -f "$DIR"/*.new-"$STAMP" "$DIR/tests"/*.new-"$STAMP" "$DASH"/*.new-"$STAMP" "$REQUEST_DIR"/*.new-"$STAMP" "$OPENNDS_LIB"/*.new-"$STAMP" "$INITD_DIR"/*.new-"$STAMP"
echo "Guest Policy v3.7 state-aware deauthentication and deletion fix installed."
echo "Backup directory: $BACKUP"
if [ "$CURRENT_HEADER" = "$V2_HEADER" ]; then
    echo "packages.tsv migrated from v2 to v3; existing package columns and data were preserved, with legacy after-quota action set to disconnect."
else
    echo "packages.tsv was already v3 and was preserved."
fi
[ -f "$BACKUP/root/guest-portal-accounting/policy.conf" ] && echo "Existing policy.conf was preserved."
echo "accounts.tsv, cron schedule, firewall, network interfaces, SQM and openNDS configuration were not changed. The existing poll-accounting.sh script still runs auto-renew before free-enforcer. No service was started, enabled or restarted."
echo "The guest-return-auth service file is updated but no running process is restarted. Restart it manually after installation so the new 5-second polling interval and retry handling take effect. The installer does not enable or disable the service."
