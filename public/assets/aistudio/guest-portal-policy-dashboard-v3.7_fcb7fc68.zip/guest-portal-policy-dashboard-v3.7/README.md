# STARLINK Guest Portal — Package and Policy Dashboard v3.7

## What this update adds

This update builds on the existing STARLINK guest portal and adds:

- Package creation, attachment to an existing account, activation, renewal, editing and removal.
- Separate normal package upload/download speed limits and after-quota upload/download speed limits.
- A per-package choice to keep a guest connected at reduced speeds (**Throttle**) or disconnect/block the guest when the allowance is exhausted (**Disconnect**).
- Per-account Free data On/Off, with the existing shared free-window schedule.
- Automatic request approval, automatic authentication, a configurable unassigned-device holding policy, and immediate/manual package activation controls.
- A promo-code path that uses the same package/unassigned access-policy handler instead of calling `auth_log` directly.
- A per-package automatic recurring renewal option that resets download and upload allowances independently.
- Separate guest-account lifecycle actions: revoke approval while retaining account/package/usage history, restore a revoked approval, or permanently delete only guest-portal records.
- A default Devices dashboard tab with live openNDS clients, DHCP hostname, MAC/IP, portal identity, browser hint, account status, session traffic, separate quota usage, package state/speeds and direct package assignment.
- An optional Policy-controlled automatic MAC enrollment mode that creates an account for a new MAC without asking for a name/mobile number; it is Off by default.
- A read-only runtime verifier and isolated mock-based tests.

- A preemptive returning-device watcher that can authorize known guest MACs before a phone or computer opens its captive-portal sign-in popup.
- Browser form URL decoding for the approved-device Disconnect and Delete actions, so percent-encoded MAC colons are validated correctly.
- Portal-scoped return-deny markers and returning-auth attempt-cache cleanup. Manual Disconnect, approval revocation and permanent Delete cannot be immediately undone by the background watcher or automatic MAC enrollment. Explicit approval/authentication or package assignment clears the marker.
- The approved-request list continues to retain approved guests who have not yet received a package; they remain visible and deletable while the watcher applies the configured temporary access policy on reconnect.

- Bounded retry handling for openNDS `ndsctl` exit code 4 (control interface busy), including a specific regression test for the exact portal resume path. The accounting poller uses a single-shot client-list query while holding `accounting.lock` to avoid sleeping through a possible lock-order cycle.

This is source code for your existing OpenWrt/openNDS environment. V3.7 has been tested offline with mocked `ndsctl` and `tc`; it has not been installed or tested against live guest traffic on STARLINK in this build session.

## The four package speed fields

The two existing speed fields keep their original meaning. They are **normal package speed caps while the package's data allowance remains**:

| Field | Applies when |
|---|---|
| Normal upload speed | The guest is within the upload allowance |
| Normal download speed | The guest is within the download allowance |
| After-quota upload speed | The upload allowance has been exhausted and the package action is Throttle |
| After-quota download speed | The download allowance has been exhausted and the package action is Throttle |

Each package also has an **After-quota action**:

- **Throttle:** keep the openNDS guest session authenticated and apply per-client upload/download traffic ceilings using Linux traffic control.
- **Disconnect:** deny further access when the relevant quota is exhausted. For non-free packages, openNDS's session volume quota remains the enforcement path. For Free data packages, the time-aware free-window enforcer performs the exhaustion check at the free-window boundary.

For an after-quota speed field, `0` means **keep the normal package rate in that direction**. For example, after-quota upload `32` and download `0` means cap upload at 32 kbps while download continues at the normal package download rate. Setting both after-quota fields to zero means no additional per-client speed ceiling is added after quota exhaustion; choose non-zero values when you want a real reduced-speed profile.

The example defaults for **new** packages are 32 kbps upload, 64 kbps download and Throttle. These are editable in the Policy page. Existing v2 package rows are migrated with 64/64 and Disconnect so their former disconnect-at-quota behaviour is preserved.

## How after-quota throttling is implemented

OpenNDS's built-in average-rate limits are retained for the two normal package speed fields. The extra after-quota rates are applied as per-client HTB classes and `flower` MAC filters:

- Guest download shaping is attached to `br-guest` and matches the destination MAC.
- Guest upload shaping is attached to the existing `ifb4br-guest` interface and matches the source MAC after the existing ingress redirect.
- Per-client classes use the private class-ID range `1:4000`–`1:4fff`; package filters use preference `0`. The script refuses a conflicting non-owned preference-zero filter.
- Classes are added as children of the existing SQM HTB parent class `1:1`. The script does not replace the SQM root qdiscs, existing classes, existing filters or packet marks. The aggregate SQM bandwidth cap remains in force.
- The `package-shaper.sh check` command is read-only. It checks for the expected HTB/IFB hierarchy and ingress redirect before a Throttle package can be assigned or edited.

This implementation is intentionally tailored to the SQM hierarchy that was inspected on STARLINK: `br-guest` with an HTB root/class `1:1`, and ingress redirected to `ifb4br-guest`, which also has an HTB root/class `1:1`. It must not be assumed compatible with a different SQM script, device name, or class hierarchy. If the read-only check fails, do not force the feature or manually replace the root qdisc.

The free-enforcer reconciles the per-client classes after the accounting poll. A throttle package keeps the openNDS volume counters unlimited so openNDS does not disconnect it at quota exhaustion; the accounting poller detects exhaustion and the enforcer adds the slower traffic-control profile. Because the existing poller runs once per minute, a guest may use some additional data between the exact quota crossing and the next poll/enforcement pass. This is polling-based enforcement, not packet-exact quota termination.

For a package with Free data On, traffic during the configured free window is excluded from the normal allowance. If a throttle package had already exhausted its billed allowance, the free-window enforcer removes its after-quota classes during free hours and restores the after-quota profile when the free window ends. Expiry and administrative disable still override free-window eligibility and block access.

If the per-client traffic shaper cannot be installed or reconciled, the enforcer fails closed by setting the quota block and deauthenticating the affected guest. This prioritizes preventing unintended unrestricted access over keeping the guest online.

## Policy page settings

The Policy page provides:

- **Auto-approve requests:** On automatically approves new requests; Off leaves them pending for an administrator.
- **Auto-authenticate:** On applies the applicable temporary or package session policy; Off leaves the guest unauthenticated until an administrator explicitly uses the Authenticate action.
- **Unassigned-device access:** Throttle grants the configurable temporary speed cap; Block leaves the guest captive with no Internet.
- **Temporary speed and session duration:** Defaults are 1 kbps in each direction and 1440 minutes.
- **Package activation:** Immediate starts validity at assignment; Manual leaves the package pending until Activate is pressed.
- **New-package defaults:** Download/upload allowance, validity, normal upload/download speed, after-quota upload/download speed, after-quota action and Free data On/Off.
- **Free-data schedule:** Editable shared start/end times in `HH:MM`; each package independently enables or disables the window.

The package page can override the after-quota values and action for each assigned package. Saving Policy defaults does not rewrite existing packages or reset usage counters.

## Requests and promo codes

The regular request flow and valid promo-code flow both call the shared request/session policy manager. A promo code does not create or assign a package. When a valid promo code is submitted:

- An active, unexpired package is applied through the package session policy.
- Without an active package, the configured unassigned-device policy applies.
- If Auto-authenticate is Off, the promo route does not grant Internet access.

The guest-facing theme no longer calls `auth_log` directly in its promo handler. This closes the direct-authentication bypass identified in the previous bundle.

Manual approval also respects the configured unassigned-device policy. The admin Authenticate action is an explicit per-client override of Auto-authenticate Off; it still applies the active package policy or the unassigned policy, rather than raw unrestricted authentication.

## Free-window accounting and time

- The schedule can cross midnight, for example 22:00–06:00. The end time is exclusive; equal start/end values are rejected.
- Free data Off charges traffic all day. Free data On uses the configured shared window.
- Scripts use the router's configured local clock (`unset TZ; date`). The STARLINK router inspected for this build reports Asia/Colombo and UTC+05:30. It does not have `/usr/share/zoneinfo/Asia/Colombo`, so the scripts avoid requiring that zoneinfo file.
- Traffic within each polling interval is apportioned proportionally between free and chargeable time. This is an estimate, not packet-level time attribution.
- The once-per-minute `poll-accounting.sh` schedule is required for accounting, automatic renewal and `free-enforcer.sh` quota/expiry enforcement. The installer updates the poller script but leaves the existing cron schedule unchanged.

## Package renewal and lifecycle

Each package offers two renewal modes:

- **One-time:** the package expires at the end of its configured validity period and requires an administrator to renew it.
- **Automatic recurring renewal:** the package remains assigned. At each validity boundary, the once-per-minute worker resets the guest's separate download and upload usage counters and advances the expiry by the configured number of days.

The period is **a number of days, not a calendar month**. For example, set Validity to 30 days for a repeating 30-day package. Renewal advances from the previous expiry boundary, rather than from the time the poller happens to run. If the router is offline across multiple periods, the worker skips missed periods, performs one quota reset when it returns, and advances expiry to the next future boundary. It does not repeatedly reset usage for every missed period.

Only active packages with active quota accounts renew automatically. Pending packages, disabled accounts and one-time packages are not auto-renewed. Existing one-time packages retain their current manual-renewal behaviour. Package expiry is otherwise **block until renewed**. Administrative disable always blocks access regardless of the free window.

Removing a package from Packages removes only its package assignment. The underlying quota account and recorded usage history remain, and the device returns to the configured unassigned policy. Editing an assigned package preserves usage counters. Changing validity days recalculates expiry from the original/current billing-period start; it does not restart validity. Use Renew to reset usage and start a new validity period manually.

## Revoke approval and permanently delete a guest

The Approved tab provides two separate account-management actions:

- **Revoke access — keep history:** adds a portal-owned return-auth block, disconnects the device when it is online, and marks every linked approved request for that MAC as `REVOKED`. It retains the quota account, package, usage counters, session records, request metadata and history. The administrator can use **Restore approval** to change linked `REVOKED` rows back to `APPROVED` and clear the portal block, or assign/activate a package through the normal administrator workflow.
- **Permanently delete portal records:** after an explicit browser confirmation, disconnects an online client, clears its portal package-shaper entry and removes that MAC's account/package rows, daily usage, session state/events, request rows, linked decision history, request metadata and its entry in the portal returning-auth attempt cache. A small portal-only `deleted_guest` marker containing the MAC remains to prevent automatic re-enrollment; an administrator can clear that marker through an explicit approval/package action.

Both operations are restricted to the guest-portal/accounting system. They do **not** modify nlbwmon databases or history, AdGuard Home query logs/statistics/configuration, DHCP leases, the shared neighbour table, firewall, global SQM, DNS, Tailscale, private Wi-Fi or general system logs. Records for unrelated guest MAC addresses are retained.

## Connected-device inventory

The Requests page opens on **Devices** by default. The inventory uses the live `ndsctl json` client list and joins each connected MAC to the router DHCP lease file, guest request metadata/history, `accounts.tsv` and `packages.tsv`. It displays the MAC and IP address, openNDS connection state, DHCP hostname and lease expiry when available, local OUI vendor when an OUI database is installed, guest name/mobile and browser/device hint when a portal request exists, account status/blocked flag, session start/duration and current-session traffic, separate download/upload quota usage and remaining allowance, package status/renewal/expiry, normal and after-quota speed settings, and Free data status.

An account without a package has an **Assign package** link. It opens Packages with that MAC's existing quota account preselected in the attach selector. A device with a package has a link to its assigned package. The list only includes clients currently present in openNDS; offline accounts remain available on the Packages and Quotas pages. Hostnames and vendor details depend on what DHCP/client information and local OUI databases are available. The dashboard shows Unknown rather than guessing when a value is unavailable.

## Optional automatic MAC enrollment

Policy includes **Automatic MAC enrollment**, default Off (`MAC_AUTO_ENROLL=0`). When Off, the existing name/mobile registration and request process remains unchanged. When On, a new client reaching the initial openNDS splash is automatically given an account keyed by its verified MAC; the name/mobile registration form is suppressed. The account starts with the Policy page's separate default download and upload allowances, and the normal unassigned-device policy still applies: for example, it can be held at the configured 1 kbps each way, blocked, or left for administrator action according to the other Policy controls. Returning MACs reuse their existing account and do not reset usage counters.

This mode does **not** disable the openNDS enforcement engine or add guests to an openNDS trusted-client list. A brief automatic status/connection splash can still appear while openNDS performs its normal client handling; the change removes the manual guest registration form, not the enforcement layer. Keeping openNDS active is important for package quotas, session accounting and speed enforcement. MAC randomization or spoofing can make one physical device appear as a different device, so use a stable private MAC for this guest SSID where possible. A MAC address is a device identifier, not strong identity verification.

## Package metadata migration

The installer accepts the existing v2 package file or an already-migrated v3 file.

For each valid v2 package row, it preserves the original first nine fields unchanged and appends:

- `AFTER_UPLOAD_KBPS=64`
- `AFTER_DOWNLOAD_KBPS=64`
- `AFTER_QUOTA_ACTION=disconnect`

This preserves the previous disconnect-on-quota behaviour of packages already assigned before this update. New package defaults use the current Policy settings instead. `accounts.tsv`, usage counters, request queue files and request history are not rewritten by the migration.

## Tests included

Run the functional test runner:

```sh
/bin/sh ./run-guest-policy-tests.sh
```

The V3.7 runner executes 120 isolated functional checks:

- 23 free-window/accounting/enforcer checks.
- 5 Policy dashboard checks.
- 20 package/request workflow checks.
- 8 after-quota and traffic-shaper checks.
- 12 portal returning-device checks.
- 5 `ndsctl` contention/retry and portal-resume regression checks.
- 4 automatic-renewal checks.
- 13 guest revocation, restoration, disconnect and permanent-deletion checks.
- 2 connected-device inventory and package-preselection checks.
- 5 automatic MAC-enrollment checks.
- 13 preemptive returning-device checks.

The separate installer mock test is:

```sh
/bin/sh ./root/guest-portal-accounting/tests/test-installer-mock.sh
```

It checks v2-to-v3 package migration, preservation of account/policy data, deployment of the updated poller and renewal worker, connected-device inventory, automatic MAC-enrollment deployment, `ndsctl` retry support, revoke/restore/delete actions, backup contents and the read-only SQM/IFB preflight in temporary directories. The mock suite does not alter the real router.

These tests use temporary directories and mocked `ndsctl`/`tc` commands. They validate shell logic and expected command construction; they do **not** prove that the router's live kernel accepts every traffic-control command or that real guest traffic is shaped at the requested rates.

## Pre-install checks on STARLINK

After transferring and extracting this bundle, first run the read-only SQM compatibility check from the extracted bundle:

```sh
QUOTA_DIR=/root/guest-portal-accounting /bin/sh ./root/guest-portal-accounting/package-shaper.sh check
```

It should report that the SQM HTB/IFB hierarchy is compatible. If it fails, stop and do not install or alter SQM to make it pass without reviewing the output.

Then run both test commands above. The installer itself reruns the functional suite and repeats the read-only SQM/IFB compatibility check before backing up or replacing live files.

## What the installer changes — and what it leaves alone

The installer:

- Backs up every file it replaces, including the existing `packages.tsv`, `policy.conf` and `policy.conf.example`.
- Migrates v2 package metadata to v3 under `packages.lock`, using a temporary file and atomic rename.
- Installs the accounting/session scripts, including `auto-renew.sh`, `package-shaper.sh` and the updated `session-end.sh` callback logic.
- Updates the existing `poll-accounting.sh` to run `auto-renew.sh` after releasing `accounting.lock` and before `free-enforcer.sh` evaluates package expiry.
- Installs all four dashboard CGI pages, the request-manager scripts and the updated guest portal theme, including preserve-history revoke/restore and portal-only permanent deletion.
- Runs syntax/schema checks after switching files and restores the backups if a post-install check fails.

The installer takes `packages.lock` and then `accounting.lock` while it updates the interdependent scripts and package metadata, matching the package manager's lock order. This briefly pauses accounting while files are switched. It backs up and replaces `poll-accounting.sh` so the recurring-renewal worker is integrated at the safe point between accounting and expiry enforcement. The new shared `policy_ndsctl()` helper retries only exit code 4, which openNDS uses for a busy control interface. The accounting poller deliberately uses a one-shot query while holding `accounting.lock`, then exits promptly on a busy response so it cannot sleep while a BinAuth callback may need that lock. The installer leaves `accounts.tsv`, `policy.conf`, the existing cron schedule, firewall, network interfaces, SQM configuration, openNDS configuration/BinAuth configuration and service enabled/running state untouched. It does not restart openNDS or reboot the router.

The installer prints a timestamped backup directory. Keep it until the new system has passed runtime verification and real-client testing.

## Post-install verification and live testing

After installation, run:

```sh
/root/guest-portal-accounting/verify-free-window-runtime.sh
```

This is read-only and checks the package schema, scripts, poller integration, SQM/IFB compatibility, BinAuth integration, policy pages and promo-code routing. A successful result still is not a complete live traffic test.

Before using paid/real guest accounts, test with a dedicated guest account and small allowance. Verify normal speeds in both directions, quota crossing, after-quota speeds in both directions, disconnect mode, the 00:00/07:00 free-window transitions for Free data On, automatic renewal at a controlled expiry, and both package removal and approved-device deletion. Check the class counters with `tc -s class show dev br-guest` and `tc -s class show dev ifb4br-guest`; the per-client classes should appear only for exhausted throttle packages. If behaviour differs from the configured caps, stop and share the outputs rather than changing the SQM roots manually.

## Rollback

If installation reports a failure, the installer attempts to restore the backed-up files automatically. If installation succeeds but post-install verification fails, stop before enabling new packages and retain the printed backup folder. Share the verifier output and backup path before attempting a rollback; this avoids restoring only part of the interdependent scripts or package schema.


## Returning-device login (v3.1 update)

When openNDS redirects a client to the initial splash, the theme asks the request manager to look up the client's current MAC address in `accounts.tsv`. If a saved account exists, it applies the same package or unassigned-device policy through `session-policy.sh` and does not ask for name/mobile details again. Active packages are reapplied; accounts without a package receive the configured unassigned policy. Pending/expired packages and disabled accounts remain blocked. When `AUTO_AUTHENTICATE=0`, the portal identifies the account but leaves it for administrator action. Devices without an account continue to see the registration form.

This is MAC-based recognition. A device that changes its private/randomized MAC address will appear as a new device and will need account recovery/registration; use the stable private Wi-Fi address for this SSID on the device. Do not add guest devices to openNDS trustedmac lists, because that would bypass package accounting. The returning-device path does not edit request, account, package or history records.


## V3.4 baseline — seamless returning-device authorization and action fixes

The optional `guest-return-auth` procd service runs a small watcher against the interface reported by `ndsctl status` (on STARLINK this is `br-guest`). It does not inspect or configure the separate guest access point's Wi-Fi radios. It reads neighbour entries from the OpenWrt guest bridge, matches the MAC against the existing account and package tables, and uses openNDS preemptive `ndsctl auth` only after verifying the neighbour belongs to openNDS's managed interface.

The installer preserves the watcher service's existing enabled/running state and does not start, stop, enable, disable or restart it. After the live runtime verifier passes, if the watcher is already running, manually stop and start it so it loads the new code. If it is not running, start it for a controlled reconnect test:

```sh
/etc/init.d/guest-return-auth start
```

When the test succeeds, enable it at boot only if it is not already enabled:

```sh
/etc/init.d/guest-return-auth enable
```

To stop it while troubleshooting:

```sh
/etc/init.d/guest-return-auth stop
```

It does not add guests to `trustedmac`. Known active accounts with no package receive the configured temporary throttle (or remain blocked under Block mode), but only after any linked request is Approved; a still-PENDING manual request is never bypassed. Active packages use their existing quota, expiry, speed and after-quota policy. Disabled accounts, pending/expired packages and unknown MACs (when automatic enrollment is Off) are not authorized. When automatic MAC enrollment is On, a new account is created only when a live DHCP lease matches the MAC and IP.

openNDS preemptive authentication is supported by this openNDS 10.3.1 configuration when enabled. This can make internet access available before the device's captive-network popup is manually tapped. The operating system may still briefly display its own captive-network status/popup; The portal update does not disable the captive portal service or bypass openNDS accounting.

The `return-auth-deny.tsv` marker prevents the watcher from undoing an administrator Disconnect or from recreating a permanently deleted guest while automatic MAC enrollment is enabled. An explicit Authenticate / Apply package action, approval, or package assignment clears that marker. This makes Disconnect intentional rather than a short-lived deauthentication.

The Requests CGI now URL-decodes browser form values before validating MAC addresses, fixing browser submissions for Disconnect and Delete. Approved requests without a package remain listed with their Delete action; after approval, the watcher gives those accounts the configured temporary access policy without requiring another registration form. A pending manual request remains blocked from preemptive login until its status changes to Approved.

The V3.4 baseline verification covers preemptive reconnection, package and quota policy enforcement, unknown-MAC enrollment gating, pending-request approval gating, manual disconnect/delete suppression, browser-encoded MAC form handling, and approved-no-package list retention.


## V3.7 — `ndsctl` contention and guest-account lifecycle

openNDS 10.3.1 returns exit code 4 when the `ndsctl` control lock is already held by another command. This is a transient busy condition, not proof that the client is absent. V3.7 retries only rc=4 (five attempts by default, one second between attempts), preserves other command errors, and displays a distinct busy message if the retry limit is exhausted. The returning-device watcher skips that scan rather than making a false missing-client decision. Its normal polling interval is five seconds.

The accounting poller uses `policy_ndsctl_once` for its client-list snapshot because it already holds `accounting.lock`. It does not sleep/retry while holding that lock; a busy result makes that poll exit promptly without replacing the accounting snapshot. This avoids waiting on the openNDS command lock while a deauthentication BinAuth callback may be waiting for the accounting lock.

The Approved dashboard now has **Revoke access — keep history**, **Restore approval**, and **Permanently delete portal records**. Revocation updates all linked approved request entries to `REVOKED`, blocks returning authentication and disconnects an online device, while preserving account, package, quota, usage, session and history data. Restore returns linked revoked rows to approved and removes the portal-only block. Permanent deletion removes only the portal's account/package/usage/session/request/history/metadata/cache records for that MAC, while retaining a small `deleted_guest` tombstone. It never removes nlbwmon, AdGuard Home, DHCP, shared neighbour, global SQM, firewall, DNS, Tailscale, Wi-Fi or system-log data.

V3.7 tests include regression coverage for the actual `live-manager.sh resume` path under `set -e`, not just the retry helper in isolation. All local validation remains mock-based; real captive-portal reconnect and traffic-shaping tests on STARLINK are still required after deployment.


## V3.7 — state-aware openNDS deauthentication

openNDS 10.3.1 documents `ndsctl deauth IP|MAC` for a currently authenticated client. A client already in `Preauthenticated` state has no authorized Internet session, and a redundant deauth command can fail. V3.7 therefore invokes deauth only for `Authenticated` clients in manual disconnect, approval revoke and permanent deletion. Preauthenticated clients are already unauthenticated and do not need a deauth command. A live authenticated client's deauth failure still stops destructive deletion, leaves the portal tombstone in place and reports the actual ndsctl failure.

The same state rule is applied to free-enforcer and the standalone Disconnect CGI. The installer now includes `disconnect` in the set of dashboard files it backs up, stages and deploys. Regression tests use a mock that deliberately rejects deauth for Preauthenticated clients, proving that the portal skips that invalid operation while still deauthenticating Authenticated clients.

This fixes the V3.6 deletion error seen when a device was already Preauthenticated. It does not by itself resolve the separate intermittent `ndsctl` busy (exit 4) contention in the accounting poller; the poller retains its single-shot behaviour under `accounting.lock` to avoid lock-order deadlocks.
