#!/bin/sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TESTS="$HERE/root/guest-portal-accounting/tests"
/bin/sh "$TESTS/test-free-window.sh"
/bin/sh "$TESTS/test-policy-dashboard.sh"
/bin/sh "$TESTS/test-package-controls.sh"
/bin/sh "$TESTS/test-after-quota.sh"
/bin/sh "$TESTS/test-returning-device.sh"
/bin/sh "$TESTS/test-ndsctl-retry.sh"
/bin/sh "$TESTS/test-auto-renew.sh"
/bin/sh "$TESTS/test-delete-device.sh"
/bin/sh "$TESTS/test-device-inventory.sh"
/bin/sh "$TESTS/test-auto-mac-enroll.sh"
/bin/sh "$TESTS/test-returning-preemptive.sh"
echo 'ALL GUEST POLICY V3.7 FUNCTIONAL CHECKS PASSED (see per-suite totals above)'
