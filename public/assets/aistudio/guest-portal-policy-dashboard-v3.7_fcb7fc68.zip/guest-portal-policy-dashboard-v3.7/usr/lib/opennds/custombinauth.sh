#!/bin/sh

case "$1" in
    *_deauth)
        logger -t guest-accounting "custom_hook_skipped method=$1 mac=$2; direct handler owns accounting"
        ;;
    *)
        logger -t guest-accounting "non_deauth_callback method=$1 mac=$2"
        ;;
esac

return 0
