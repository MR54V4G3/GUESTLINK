#!/bin/sh
#Copyright (C) The openNDS Contributors 2004-2022
#Copyright (C) BlueWave Projects and Services 2015-2025
#This software is released under the GNU GPL license.
#
# Warning - shebang sh is for compatibliity with busybox ash (eg on OpenWrt)
# This is changed to bash automatically by Makefile for generic Linux
#

# Title of this theme:
title="theme_user-email-login-custom-placeholders"

# functions:

download_image_files() {
	# The list of images to be downloaded is defined in $ndscustomimages ( see near the end of this file )
	# The source of the images is defined in the openNDS config

	for nameofimage in $ndscustomimages; do
		get_image_file "$nameofimage"
	done
}

download_data_files() {
	# The list of files to be downloaded is defined in $ndscustomfiles ( see near the end of this file )
	# The source of the files is defined in the openNDS config

	for nameoffile in $ndscustomfiles; do
		get_data_file "$nameoffile"
	done
}


generate_splash_sequence() {
	name_email_login
}

header() {
# Define a common header html for every page served
	gatewayurl=$(printf "${gatewayurl//%/\\x}")
	htmlentitydecode "$logo_message"
	urldecode "$entitydecoded"
	logo_message="$urldecoded"

	echo "<!DOCTYPE html>
		<html>
		<head>
		<meta http-equiv=\"Cache-Control\" content=\"no-cache, no-store, must-revalidate\">
		<meta http-equiv=\"Pragma\" content=\"no-cache\">
		<meta http-equiv=\"Expires\" content=\"0\">
		<meta charset=\"utf-8\">
		<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
                <style>
                body { background: #0b1220; color: #172033; font-family: Arial, sans-serif; margin: 0; padding: 16px 10px; }
                .offset { width: 100%; }
                .brand { text-align: center; max-width: 460px; margin: 10px auto 24px; color: #ffffff; }
                .brand h2 { color: #ffffff; font-size: 28px; margin: 18px 0 8px; }
                .brand p { color: #ffffff; margin: 5px 0; line-height: 1.5; }
                .insert { box-sizing: border-box; width: 100%; max-width: 460px !important; margin: 18px auto; padding: 26px 22px; background: transparent; color: #ffffff; border-radius: 18px; box-shadow: 0 12px 32px rgba(0,0,0,0.28); text-align: center; }
                p, b, label { color: #ffffff; line-height: 1.5; }
                input[type=text], input[type=tel] { box-sizing: border-box; width: 100%; padding: 13px; margin: 8px 0; border: 1px solid #cbd5e1; border-radius: 8px; background: #f8fafc; color: #111827; font-size: 16px; }
                button, input[type=submit], input[type=button] { box-sizing: border-box; max-width: 100%; padding: 13px 18px; margin: 8px 0; border: 0; border-radius: 9px; background: #1769e0; color: #ffffff; font-size: 16px; font-weight: bold; cursor: pointer; }
                hr { border: 0; border-top: 1px solid #dbe3ef; margin: 24px 0; }
                img { max-width: 100%; height: auto; }
                </style>
		<link rel=\"shortcut icon\" href=\"$gatewayurl/images/splash.jpg\" type=\"image/x-icon\">
		<link rel=\"stylesheet\" type=\"text/css\" href=\"$gatewayurl/splash.css\">
		<title>$gatewayname</title>
		</head>
		<body>
		<div class=\"offset\">
		</med-blue>
                <div class="brand">
                <img src="$gatewayurl$logo" alt="STARLINK Logo."><br>
                <h2>STARLINK</h2>
                <p><b style="color:#ffffff;">Sponsored by Aegis Vector</b><br>An Advanced Technology and Defense Company</p>
                </div>
                <div class="insert">
	"
}

footer() {
	# Define a common footer html for every page served
	year=$(date +'%Y')
	echo "
			<br>
			<br>
			<br><br><br><br>
		</div>
		</div>
		</div>
		</body>
		</html>
	"

	exit 0
}

name_email_login() {
        # Returning devices are recognized by their existing account MAC and
        # sent through the shared package/unassigned policy engine. New devices
        # still receive the normal name/mobile registration form.
        if [ -n "${clientmac:-}" ]; then
                return_manager="${GUEST_RETURN_MANAGER:-/root/guest-portal-requests/live-manager.sh}"
                if [ ! -x "$return_manager" ]; then
                        logger -t guest-portal "returning_device_manager_missing mac=$clientmac"
                        echo "<h2>Welcome back</h2><p>We could not verify your saved guest account. No new access was granted. Please contact the administrator.</p>"
                        read_terms
                        footer
                        return
                fi
                if return_result=$("$return_manager" resume "$clientmac" 2>&1); then
                        case "$return_result" in
                                *RETURN_NEW_DEVICE*)
                                        # MAC auto-enrollment suppresses the guest name/mobile form.
                                        # openNDS remains active; the new account is passed through
                                        # the ordinary unassigned hold/block policy before access.
                                        policy_lib="${GUEST_POLICY_LIB:-/root/guest-portal-accounting/policy-lib.sh}"
                                        if [ -r "$policy_lib" ]; then
                                                . "$policy_lib"
                                                policy_load
                                        else
                                                MAC_AUTO_ENROLL=0
                                        fi
                                        if [ "${MAC_AUTO_ENROLL:-0}" = 1 ]; then
                                                if auto_result=$("$return_manager" auto-enroll "$clientmac" 2>&1); then
                                                        case "$auto_result" in
                                                                *AUTO_MAC_ENROLLED_LIMITED*)
                                                                        echo "<h2>Device registered</h2><p>Your device has been registered automatically. Temporary access is enabled at the administrator's holding speed until a package is assigned.</p>" ;;
                                                                *AUTO_MAC_ENROLLED_BLOCKED*)
                                                                        echo "<h2>Device registered</h2><p>Your device has been registered. Internet access will be enabled after the administrator assigns a package.</p>" ;;
                                                                *AUTO_MAC_ENROLLED_ADMIN*)
                                                                        echo "<h2>Device registered</h2><p>Your device has been registered. Please wait for the administrator to activate access.</p>" ;;
                                                                *)
                                                                        logger -t guest-portal "auto_mac_unexpected_result mac=$clientmac result=$auto_result"
                                                                        echo "<h2>Device registered</h2><p>Automatic registration completed, but access could not be confirmed. Please contact the administrator.</p>" ;;
                                                        esac
                                                else
                                                        logger -t guest-portal "auto_mac_enroll_failed mac=$clientmac detail=$auto_result"
                                                        echo "<h2>Automatic registration failed</h2><p>No access was granted. Please contact the administrator.</p>"
                                                fi
                                                read_terms
                                                footer
                                                return
                                        fi
                                        login_form
                                        return
                                        ;;
                                *RETURN_PACKAGE_AUTHENTICATED*)
                                        echo "<h2>Welcome back</h2><p>Your existing account was recognized and your active package has been applied. You do not need to register again.</p>"
                                        ;;
                                *RETURN_HOLD_AUTHENTICATED*)
                                        echo "<h2>Welcome back</h2><p>Your existing account was recognized. Your temporary access policy is active until a package is assigned.</p>"
                                        ;;
                                *RETURN_ADMIN_ACTION*)
                                        echo "<h2>Welcome back</h2><p>Your existing account was recognized, but automatic authentication is disabled. Please wait for the administrator to apply access.</p>"
                                        ;;
                                *RETURN_ADMIN_BLOCKED*)
                                        logger -t guest-portal "returning_device_admin_blocked mac=$clientmac"
                                        echo "<h2>Access temporarily disabled</h2><p>An administrator has disabled saved-account access for this device. Your account and package may still exist, but this device is blocked from automatic login. Please contact the administrator and ask them to restore approval or clear the device block.</p>"
                                        ;;
                                *RETURN_NO_INTERNET*)
                                        echo "<h2>Account recognized</h2><p>Your account or package is not currently eligible for internet access. Please contact the administrator or renew your package.</p>"
                                        ;;
                                *)
                                        logger -t guest-portal "returning_device_unexpected_result mac=$clientmac result=$return_result"
                                        echo "<h2>Welcome back</h2><p>We could not safely apply your saved account policy. No new access was granted. Please contact the administrator.</p>"
                                        ;;
                        esac
                else
                        logger -t guest-portal "returning_device_policy_failed mac=$clientmac detail=$return_result"
                        echo "<h2>Welcome back</h2><p>We could not safely apply your saved account policy. No new access was granted. Please contact the administrator.</p>"
                fi
                read_terms
                footer
                return
        fi

        login_form
        footer
}

login_form() {
        htmlentitydecode "$banner1_message"
        urldecode "$entitydecoded"
        banner1_message="$urldecoded"
        echo "
                <p>Request access and wait for approval, or enter a promo code.</p>
                <form action=\"/opennds_preauth/\" method=\"get\">
                        <input type=\"hidden\" name=\"fas\" value=\"$fas\">
                        <input type=\"hidden\" name=\"landing\" value=\"yes\">
                        <input type=\"text\" name=\"username\" value=\"$username\" required><br><b>Name</b><br>
                        <input type=\"tel\" name=\"emailaddress\" value=\"$emailaddress\" required><br><b>Mobile Number</b><br>
                        <button type=\"submit\" name=\"portal_action\" value=\"request\">Request Access</button>
                </form>
                <hr><p>Enter code for 10 GB per day</p>
                <form action=\"/opennds_preauth/\" method=\"get\">
                        <input type=\"hidden\" name=\"fas\" value=\"$fas\">
                        <input type=\"hidden\" name=\"landing\" value=\"yes\">
                        <input type=\"text\" name=\"promo_code\" value=\"$promo_code\" required>
                        <button type=\"submit\" name=\"portal_action\" value=\"promo\">Enter Promo Code</button>
                </form>
        "
        read_terms
        footer
}
thankyou_page () {
	# If we got here, we have both the username and emailaddress fields as completed on the login page on the client,
	# or Continue has been clicked on the "Click to Continue" page
	# No further validation is required so we can grant access to the client. The token is not actually required.

	# We now output the "Thankyou page" with a "Continue" button.

	# This is the place to include information or advertising on this page,
	# as this page will stay open until the client user taps or clicks "Continue"

	# Be aware that many devices will close the login browser as soon as
	# the client user continues, so now is the time to deliver your message.

	htmlentitydecode "$banner2_message"
	urldecode "$entitydecoded"
	banner2_message="$urldecoded"

urldecode "$test_variable2"
test_variable2="$urldecoded"
	echo "
		<big-red>
			Thankyou for using this service.<br>Please click Continue for access.
		</big-red>
		<br>
		<b>Welcome $username</b>
		<br>
	"

	# Add your message here:
	# You could retrieve text or images from a remote server using wget or curl
	# as this router has Internet access whilst the client device does not (yet).

	if [ -e "$mountpoint/ndsdata/advert1.htm" ]; then
		advert1=$(cat "$mountpoint/ndsdata/advert1.htm")
	else
		advert1="Your News or Advertising could be here, contact the owners of this Hotspot to find out how!"
	fi

	echo "
		<br>
			<b>$banner2_message</b><br>
			$advert1
	"

	binauth_custom="username=$username emailaddress=$emailaddress"
	encode_custom

        if [ -z "$custom" ]; then
                customhtml=""
        else
                customhtml="<input type=\"hidden\" name=\"custom\" value=\"$custom\">"
        fi

	# Continue to the landing page, the client is authenticated there
	echo "
		<form action=\"/opennds_preauth/\" method=\"get\">
			<input type=\"hidden\" name=\"fas\" value=\"$fas\">
			<input type=\"hidden\" name=\"username\" value=\"$username\">
			<input type=\"hidden\" name=\"emailaddress\" value=\"$emailaddress\">
			$customhtml
			$custom_passthrough
			<input type=\"hidden\" name=\"landing\" value=\"yes\">
			<input type=\"submit\" value=\"Continue\" >
		</form>
		<br>
	"

	# Serve the rest of the page:
	read_terms
	footer
}

landing_page() {
        originurl=$(printf "${originurl//%/\\x}")
        gatewayurl=$(printf "${gatewayurl//%/\\x}")

        configure_log_location
        . "$mountpoint/ndscids/ndsinfo"

        case "$portal_action" in
        request)
                if [ -z "$username" ] || [ -z "$emailaddress" ]; then
                        echo "<h2>Both name and mobile number are required.</h2>"
                        read_terms
                        footer
                        return
                fi

                rhid=$(printf '%s' "$hid$key" | sha256sum | awk '{print $1}')
                binauth_custom="username=$username emailaddress=$emailaddress"
                encode_custom
                if [ -z "$custom" ]; then
                        echo "<h2>Unable to process request</h2><p>No access has been granted.</p>"
                        read_terms
                        footer
                        return
                fi

        if [ -z "$custom" ]; then
                customhtml=""
        else
                customhtml="<input type=\"hidden\" name=\"custom\" value=\"$custom\">"
        fi

                unset REQUEST_TEST_QUEUE
                if request_result=$(
                        /root/guest-portal-requests/submit-request.sh \
                        "$rhid" "$username" "$emailaddress" "$custom" \
                        "$session_length" "$upload_rate" "$download_rate" \
                        "$upload_quota" "$download_quota" \
                        "${clientip:-}" "${clientmac:-}" "${user_agent:-}" "${hid:-}" 2>&1
                ); then
                        case "$request_result" in
                            *AUTO_APPROVED_LIMITED*)
                                hold_rate=$(printf '%s' "$request_result" | sed -n 's/.*temporary speed cap is \([0-9][0-9]*\) kbps each way.*/\1/p')
                                [ -n "$hold_rate" ] || hold_rate=1
                                echo "<h2>Request approved automatically</h2>
                                      <p>Temporary internet access is enabled with a ${hold_rate} kbps speed cap in both directions until the administrator assigns an active package.</p>" ;;
                            *AUTO_APPROVED_NO_INTERNET*)
                                echo "<h2>Request approved</h2>
                                      <p>Internet access remains blocked until an active package is assigned and authentication is enabled by the administrator.</p>" ;;
                            *AUTO_PENDING*)
                                echo "<h2>Access request received</h2>
                                      <p>Your request is waiting for administrator approval.</p>" ;;
                            *AUTO_PROCESS_ERROR*)
                                echo "<h2>Request received for review</h2>
                                      <p>Automatic processing did not complete. Your request has been left for administrator review.</p>" ;;
                            *)
                                echo "<h2>Access request received</h2>
                                      <p>Your request was received. Access is controlled by the hotspot administrator's current policy.</p>" ;;
                        esac
                else
                        echo "<h2>Unable to submit your request</h2>
                              <p>Please try again. No access has been granted.</p>"
                fi
                read_terms
                footer
                return
                ;;

        promo)
                expected_code=""
                if [ -r /root/guest-portal-requests/settings ]; then
                        IFS= read -r expected_code < /root/guest-portal-requests/settings || :
                fi

                if [ -z "$promo_code" ] || [ -z "$expected_code" ] || [ "$promo_code" != "$expected_code" ]; then
                        echo "<h2>Invalid promo code</h2>
                              <p>No access has been granted. Please check the code and try again.</p>"
                        read_terms
                        footer
                        return
                fi

                promo_result=""
                if promo_result=$(/root/guest-portal-requests/live-manager.sh promo "${clientmac:-}" 2>&1); then
                        case "$promo_result" in
                                PROMO_PACKAGE*)
                                        echo "<h2>Promo code accepted</h2>
                                              <p>Your active package has been applied. Its data allowance, validity and speed policy remain in force.</p>" ;;
                                PROMO_LIMITED*)
                                        echo "<h2>Promo code accepted</h2>
                                              <p>Your configured temporary access limit is active until an administrator assigns a package.</p>" ;;
                                PROMO_NO_INTERNET*)
                                        echo "<h2>Promo code accepted</h2>
                                              <p>The current administrator policy does not grant internet access yet. Please contact the administrator.</p>" ;;
                                *)
                                        echo "<h2>Promo code accepted</h2>
                                              <p>Your access is subject to the hotspot administrator's current package and access policy.</p>" ;;
                        esac
                else
                        logger -t guest-portal "promo_policy_failed mac=${clientmac:-unknown}"
                        echo "<h2>Unable to apply promo access</h2>
                              <p>The code was accepted, but the access policy could not be applied. No unrestricted access was granted.</p>"
                fi
                read_terms
                footer
                return
                ;;

        *)
                echo "<h2>Invalid portal action</h2>
                      <p>No access has been granted.</p>"
                read_terms
                footer
                return
                ;;
        esac
}
read_terms() {
	#terms of service button
	echo "
		<form action=\"/opennds_preauth/\" method=\"get\">
			<input type=\"hidden\" name=\"fas\" value=\"$fas\">
			$custom_passthrough
			<input type=\"hidden\" name=\"terms\" value=\"yes\">
			<input type=\"submit\" value=\"Read Terms of Service   \" >
		</form>
	"
}

display_terms() {
	# This is the all important "Terms of service"
	# Edit this long winded generic version to suit your requirements.
	####
	# WARNING #
	# It is your responsibility to ensure these "Terms of Service" are compliant with the REGULATIONS and LAWS of your Country or State.
	# In most locations, a Privacy Statement is an essential part of the Terms of Service.
	####

	#Privacy
	echo "
		<b style=\"color:red;\">Privacy.</b><br>
		<b>
			By logging in to the system, you grant your permission for this system to store any data you provide for
			the purposes of logging in, along with the networking parameters of your device that the system requires to function.<br>
			All information is stored for your convenience and for the protection of both yourself and us.<br>
			All information collected by this system is stored in a secure manner and is not accessible by third parties.<br>
			In return, we grant you FREE Internet access.
	"

	# Terms of Service
	echo "
		<b style=\"color:red;\">Terms of Service for this Hotspot.</b> <br>


		<b>Please scroll down to read the Terms of Service in full or click the Continue button to return to the Acceptance Page</b>

		<form>
			<input type=\"button\" VALUE=\"Continue\" onClick=\"history.go(-1);return true;\">
		</form>
	"

	# Proper Use
	echo "
		<b>Proper Use</b>

		<p>
			This Hotspot provides a wireless network that allows you to connect to the Internet. <br>
			<b>Use of this Internet connection is provided in return for your FULL acceptance of these Terms Of Service.</b>
		</p>

		<p>
			<b>You agree</b> that you are responsible for providing security measures that are suited for your intended use of the Service.
			For example, you shall take full responsibility for taking adequate measures to safeguard your data from loss.
		</p>

		<p>
			While the Hotspot uses commercially reasonable efforts to provide a secure service,
			the effectiveness of those efforts cannot be guaranteed.
		</p>

		<p>
			<b>You may</b> use the technology provided to you by this Hotspot for the sole purpose
			of using the Service as described here.
			You must immediately notify the Owner of any unauthorized use of the Service or any other security breach.<br><br>
			We will give you an IP address each time you access the Hotspot, and it may change.
			<br>
			<b>You shall not</b> program any other IP or MAC address into your device that accesses the Hotspot.
			You may not use the Service for any other reason, including reselling any aspect of the Service.
			Other examples of improper activities include, without limitation:
		</p>

			<ol>
				<li>
					downloading or uploading such large volumes of data that the performance of the Service becomes
					noticeably degraded for other users for a significant period;
				</li>

				<li>
					attempting to break security, access, tamper with or use any unauthorized areas of the Service;
				</li>

				<li>
					removing any copyright, trademark or other proprietary rights notices contained in or on the Service;
				</li>

				<li>
					attempting to collect or maintain any information about other users of the Service
					(including usernames and/or email addresses) or other third parties for unauthorized purposes;
				</li>

				<li>
					logging onto the Service under false or fraudulent pretenses;
				</li>

				<li>
					creating or transmitting unwanted electronic communications such as SPAM or chain letters to other users
					or otherwise interfering with other user's enjoyment of the service;
				</li>

				<li>
					transmitting any viruses, worms, defects, Trojan Horses or other items of a destructive nature; or
				</li>

				<li>
					using the Service for any unlawful, harassing, abusive, criminal or fraudulent purpose.
				</li>
			</ol>
	"

	# Content Disclaimer
	echo "
		<b>Content Disclaimer</b>

		<p>
			The Hotspot Owners do not control and are not responsible for data, content, services, or products
			that are accessed or downloaded through the Service.
			The Owners may, but are not obliged to, block data transmissions to protect the Owner and the Public.
		</p>

		The Owners, their suppliers and their licensors expressly disclaim to the fullest extent permitted by law,
		all express, implied, and statutary warranties, including, without limitation, the warranties of merchantability
		or fitness for a particular purpose.
		<br><br>
		The Owners, their suppliers and their licensors expressly disclaim to the fullest extent permitted by law
		any liability for infringement of proprietory rights and/or infringement of Copyright by any user of the system.
		Login details and device identities may be stored and be used as evidence in a Court of Law against such users.
		<br>
	"

	# Limitation of Liability
	echo "


		<p>
			Under no circumstances shall the Owners, their suppliers or their licensors be liable to any user or
			any third party on account of that party's use or misuse of or reliance on the Service.
		</p>


		<p>
			We may modify or terminate the Service and these Terms of Service and any accompanying policies,
			for any reason, and without notice, including the right to terminate with or without notice,
			without liability to you, any user or any third party. Please review these Terms of Service
			from time to time so that you will be apprised of any changes.
		</p>

		<p>
			We reserve the right to terminate your use of the Service, for any reason, and without notice.
			Upon any such termination, any and all rights granted to you by this Hotspot Owner shall terminate.
		</p>
	"

	# Indemnity
	echo "

		<p>
			<b>You agree</b> to hold harmless and indemnify the Owners of this Hotspot,
			their suppliers and licensors from and against any third party claim arising from
			or in any way related to your use of the Service, including any liability or expense arising from all claims,
			losses, damages (actual and consequential), suits, judgments, litigation costs and legal fees, of every kind and nature.
		</p>

		<form>
			<input type=\"button\" VALUE=\"Continue\" onClick=\"history.go(-1);return true;\">
		</form>
	"
	footer
}

#### end of functions ####


#################################################
#						#
#  Start - Main entry point for this Theme	#
#						#
#  Parameters set here overide those		#
#  set in libopennds.sh			#
#						#
#################################################

# Quotas and Data Rates
#########################################
# Set length of session in minutes (eg 24 hours is 1440 minutes - if set to 0 then defaults to global sessiontimeout value):
# eg for 100 mins:
# session_length="100"
#
# eg for 20 hours:
# session_length=$((20*60))
#
# eg for 20 hours and 30 minutes:
# session_length=$((20*60+30))
session_length="0"

# Set Rate and Quota values for the client
# The session length, rate and quota values could be determined by this script, on a per client basis.
# rates are in kb/s, quotas are in kB. - if set to 0 then defaults to global value).
upload_rate="0"
download_rate="0"
upload_quota="0"
download_quota="0"

quotas="$session_length $upload_rate $download_rate $upload_quota $download_quota"

# Define the list of Parameters we expect to be sent sent from openNDS ($ndsparamlist):
# Note you can add custom parameters to the config file and to read them you must also add them here.
# Custom parameters are "Portal" information and are the same for all clients eg "admin_email" and "location" 
ndscustomparams="input logo_message banner1_message banner2_message banner3_message"
ndscustomimages="logo_png banner1_jpg banner2_jpg banner3_jpg"
ndscustomfiles="advert1_htm"

ndsparamlist="$ndsparamlist $ndscustomparams $ndscustomimages $ndscustomfiles"

# The list of FAS Variables used in the Login Dialogue generated by this script is $fasvarlist and defined in libopennds.sh
#
# Additional FAS defined variables (defined in this theme) should be added to $fasvarlist here.
additionalthemevars="username emailaddress portal_action promo_code"

fasvarlist="$fasvarlist $additionalthemevars"

# You can choose to define a custom string. This will be b64 encoded and sent to openNDS.
# There it will be made available to be displayed in the output of ndsctl json as well as being sent
#	to the BinAuth post authentication processing script if enabled.
# Set the variable $binauth_custom to the desired value.
# Values set here can be overridden by the themespec file

#binauth_custom="This is sample text sent from \"$title\" to \"BinAuth\" for post authentication processing."

# Encode and activate the custom string
#encode_custom

# Set the user info string for logs (this can contain any useful information)
userinfo="$title"

# Customise the Logfile location. Note: the default uses the tmpfs "temporary" directory to prevent flash wear.
# Override the defaults to a custom location eg a mounted USB stick.
#mountpoint="/mylogdrivemountpoint"
#logdir="$mountpoint/ndslog/"
#logname="ndslog.log"



